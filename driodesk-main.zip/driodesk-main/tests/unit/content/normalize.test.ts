import { describe, expect, it } from "vitest";

import {
  contentRecords,
  type ContentRecords,
} from "../../../src/content/records";
import {
  ContentRelationshipError,
  normalizeContent,
} from "../../../src/lib/content/normalize";

const copyRecords = (): ContentRecords => structuredClone(contentRecords);

describe("canonical portfolio content", () => {
  it("validates the approved factual fixtures and keeps incomplete records unpublished", () => {
    const result = normalizeContent();

    expect(
      result.all.experience.map(({ employer, start, end }) => ({
        employer,
        start,
        end,
      })),
    ).toEqual([
      { employer: "Babel", start: "2022-07", end: "present" },
      { employer: "NTT DATA", start: "2014-12", end: "2022-07" },
      { employer: "NEOSISTEC", start: "2014-04", end: "2014-06" },
    ]);
    expect(result.all.experience[0]?.clients).toEqual(["ING"]);
    expect(result.all.caseStudies[0]).toMatchObject({
      sourceVisibility: "private",
      approach: ["AWS Amplify Gen 1"],
    });
    expect(result.published.profile).toHaveLength(1);
    expect(result.published.profile[0]).toMatchObject({
      publicName: "Danny Riofrio",
      professionalTitle: "Senior Software Engineer",
      minimumYearsExperience: 10,
      location: "Murcia, Spain",
      avatarAssetId: "profile-avatar",
      cvAssetId: "spanish-cv",
    });
    expect(result.published.assets.map(({ id }) => id)).toContain(
      "profile-avatar",
    );
    expect(result.published.assets.map(({ id }) => id)).not.toContain(
      "spanish-cv",
    );
    expect(result.published.repositories).toEqual([]);
  });

  it("encodes pending and excluded repository decisions", () => {
    expect(
      contentRecords.repositories.map(({ id, inclusion }) => [id, inclusion]),
    ).toEqual([
      ["reimbursement-tracker", "included"],
      ["estate-hub-prototype", "pending"],
      ["python-utilities", "excluded"],
    ]);
  });

  it("rejects missing relationships", () => {
    const records = copyRecords();
    records.navigation[0].routeKey = "missing-route";

    expect(() => normalizeContent(records)).toThrow(ContentRelationshipError);
  });

  it("rejects duplicate route ownership", () => {
    const records = copyRecords();
    records.navigation[1].routeKey = "about";

    expect(() => normalizeContent(records)).toThrow(
      "duplicate route ownership",
    );
  });

  it("rejects records marked approved while required editorial values remain pending", () => {
    const records = copyRecords();
    Object.assign(records.profile[0], { summary: null });

    expect(() => normalizeContent(records)).toThrow(
      "Profile site-profile cannot publish without summary",
    );
  });
});
