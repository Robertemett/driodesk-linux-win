import { describe, expect, it } from "vitest";

import { portfolioContent } from "../../../src/lib/content/normalize";
import {
  getCoreRouteProjection,
  getPublishableCaseStudyProjections,
  routeDirectory,
  validateRouteProjections,
} from "../../../src/lib/routes/projections";

describe("stable route projections", () => {
  it("owns the exact Spanish core routes with unique baseline metadata", () => {
    const routes = validateRouteProjections();

    expect(routes.map(({ path }) => path)).toEqual([
      "/",
      "/about/",
      "/experience/",
      "/projects/",
      "/github/",
    ]);
    expect(new Set(routes.map(({ title }) => title)).size).toBe(routes.length);
    expect(new Set(routes.map(({ description }) => description)).size).toBe(
      routes.length,
    );
    expect(routes.every(({ title, description }) => title && description)).toBe(
      true,
    );
  });

  it("builds native directory links from canonical route records", () => {
    expect(routeDirectory).toEqual([
      { key: "about", label: "About", href: "/about/" },
      { key: "experience", label: "Experience", href: "/experience/" },
      { key: "projects", label: "Projects", href: "/projects/" },
      { key: "github", label: "GitHub", href: "/github/" },
    ]);
  });

  it("publishes the approved About facts without inventing a CV download", () => {
    const routes = validateRouteProjections();
    const about = getCoreRouteProjection("about");
    const profile = about.sections.find(({ heading }) => heading === "Perfil")
      ?.entries[0];

    expect(getPublishableCaseStudyProjections()).toEqual([]);
    expect(routes.some(({ path }) => path.startsWith("/en/"))).toBe(false);
    expect(profile).toMatchObject({
      title: "Danny Riofrio — Senior Software Engineer",
      details: [
        expect.stringContaining("Java, Spring, Kafka, APIs"),
        "10+ años de experiencia",
        "Murcia, Spain",
      ],
      image: {
        src: "/assets/profile/danny-riofrio-avatar.png",
        alt: "Avatar actual del perfil público de GitHub de Danny Riofrio",
      },
    });
    expect(profile?.details[0]).toContain("TypeScript, Python, cloud");
    expect(profile?.details[0]).toContain(
      "requisitos, hoja de ruta, implementación y verificación",
    );
    expect(profile?.links).toEqual([
      { label: "Ver experiencia", href: "/experience/" },
      { label: "Ver proyectos", href: "/projects/" },
      {
        label: "LinkedIn",
        href: "https://www.linkedin.com/in/danny-riofrio-jimenez",
      },
      {
        label: "Correo profesional",
        href: "mailto:dannyriofriojimenez@gmail.com",
      },
    ]);
    expect(about.pendingMessage).toContain("pendiente de publicación");
    expect(JSON.stringify(about)).not.toContain("Danny_Riofrio_CV_ES.pdf");
    expect(portfolioContent.published.assets.map(({ id }) => id)).toEqual([
      "portfolio-mark",
      "profile-avatar",
    ]);
    expect(portfolioContent.published.profile).toHaveLength(1);
    expect(portfolioContent.published.skills).toHaveLength(6);
    expect(portfolioContent.published.experience).toHaveLength(0);
    expect(
      portfolioContent.all.seo.every(({ locale }) => locale === "es"),
    ).toBe(true);
  });

  it("keeps navigation and SEO references internally valid", () => {
    const seoKeys = new Set(
      portfolioContent.all.seo.map(({ routeKey }) => routeKey),
    );
    const ownedKeys = portfolioContent.all.navigation.flatMap(({ routeKey }) =>
      routeKey ? [routeKey] : [],
    );

    expect(ownedKeys.every((key) => seoKeys.has(key))).toBe(true);
    expect(new Set(ownedKeys).size).toBe(ownedKeys.length);
  });
});
