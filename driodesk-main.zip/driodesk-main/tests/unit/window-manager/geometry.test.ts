import { describe, expect, it } from "vitest";

import {
  defaultGeometryConstraints,
  getMaximizedRect,
  moveWindowRect,
  recoverWindowRect,
  resizeWindowRect,
  restoreWindowRect,
  type ResizeEdge,
} from "../../../src/lib/window-manager/geometry";

const workspace = { width: 1000, height: 700 };
const start = { x: 200, y: 150, width: 500, height: 300 };

describe("desktop window geometry", () => {
  it("moves within the workspace and clamps every boundary", () => {
    expect(moveWindowRect(start, { x: 40, y: 30 }, workspace)).toEqual({
      x: 240,
      y: 180,
      width: 500,
      height: 300,
    });
    expect(moveWindowRect(start, { x: -1000, y: -1000 }, workspace)).toEqual({
      x: 0,
      y: 0,
      width: 500,
      height: 300,
    });
    expect(moveWindowRect(start, { x: 1000, y: 1000 }, workspace)).toEqual({
      x: 500,
      y: 400,
      width: 500,
      height: 300,
    });
  });

  it("resizes from every edge and corner while preserving opposite edges", () => {
    const expected: Record<ResizeEdge, typeof start> = {
      n: { x: 200, y: 180, width: 500, height: 270 },
      ne: { x: 200, y: 180, width: 540, height: 270 },
      e: { x: 200, y: 150, width: 540, height: 300 },
      se: { x: 200, y: 150, width: 540, height: 330 },
      s: { x: 200, y: 150, width: 500, height: 330 },
      sw: { x: 240, y: 150, width: 460, height: 330 },
      w: { x: 240, y: 150, width: 460, height: 300 },
      nw: { x: 240, y: 180, width: 460, height: 270 },
    };

    for (const edge of Object.keys(expected) as ResizeEdge[]) {
      expect(
        resizeWindowRect(start, edge, { x: 40, y: 30 }, workspace),
      ).toEqual(expected[edge]);
    }
  });

  it("enforces minimum dimensions from every shrinking direction", () => {
    const { minWidth, minHeight } = defaultGeometryConstraints;
    expect(
      resizeWindowRect(start, "e", { x: -1000, y: 0 }, workspace).width,
    ).toBe(minWidth);
    expect(
      resizeWindowRect(start, "w", { x: 1000, y: 0 }, workspace),
    ).toMatchObject({ x: 380, width: minWidth });
    expect(
      resizeWindowRect(start, "s", { x: 0, y: -1000 }, workspace).height,
    ).toBe(minHeight);
    expect(
      resizeWindowRect(start, "n", { x: 0, y: 1000 }, workspace),
    ).toMatchObject({ y: 270, height: minHeight });
  });

  it("recovers stale off-screen rectangles with title controls above the taskbar", () => {
    const recovered = recoverWindowRect(
      { x: 5000, y: 4000, width: 500, height: 300 },
      workspace,
    );
    expect(recovered).toEqual({ x: 500, y: 400, width: 500, height: 300 });
    expect(recovered.y + recovered.height).toBeLessThanOrEqual(
      workspace.height,
    );

    const tinyWorkspace = { width: 240, height: 140 };
    const oversized = recoverWindowRect(start, tinyWorkspace);
    expect(oversized).toEqual({ x: -80, y: 0, width: 320, height: 180 });
    expect(oversized.x + oversized.width).toBe(tinyWorkspace.width);
    expect(oversized.y).toBe(0);
  });

  it("recalculates maximize and restore geometry after viewport changes", () => {
    expect(getMaximizedRect(workspace)).toEqual({
      x: 0,
      y: 0,
      width: 1000,
      height: 700,
    });
    const portrait = { width: 700, height: 1000 };
    expect(restoreWindowRect(start, start, portrait)).toEqual({
      x: 200,
      y: 150,
      width: 500,
      height: 300,
    });
    expect(
      restoreWindowRect(
        { x: 900, y: 600, width: 500, height: 300 },
        start,
        portrait,
      ),
    ).toEqual({ x: 200, y: 600, width: 500, height: 300 });
  });
});
