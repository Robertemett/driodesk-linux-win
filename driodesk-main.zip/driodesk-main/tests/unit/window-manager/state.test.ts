import { describe, expect, it } from "vitest";

import {
  createWindowManagerState,
  getWindowManagerInvariantErrors,
  reduceWindowCommand,
  type WindowCommand,
  type WindowManagerState,
} from "../../../src/lib/window-manager/state";

const definitions = ["about", "projects", "github"].map((id, index) => ({
  id,
  initialRect: {
    x: 24 + index * 32,
    y: 20 + index * 28,
    width: 720,
    height: 520,
  },
}));

const transition = (state: WindowManagerState, command: WindowCommand) =>
  reduceWindowCommand(state, command);

describe("window manager state", () => {
  it("creates one serializable registry record with About active by default", () => {
    const state = createWindowManagerState(definitions, "about");

    expect(state.order).toEqual(["about", "projects", "github"]);
    expect(Object.keys(state.windows)).toEqual(state.order);
    expect(state.windows.about).toMatchObject({
      lifecycle: "open",
      zOrder: 1,
    });
    expect(state.windows.projects.lifecycle).toBe("closed");
    expect(JSON.parse(JSON.stringify(state))).toEqual(state);
    expect(getWindowManagerInvariantErrors(state)).toEqual([]);
    expect(() =>
      createWindowManagerState([...definitions, definitions[0]], "about"),
    ).toThrow(/duplicate/);
  });

  it("opens separate singleton windows and normalizes deterministic z-order", () => {
    let state = createWindowManagerState(definitions, "about");
    state = transition(state, { type: "open", id: "projects" }).state;
    state = transition(state, { type: "open", id: "github" }).state;

    expect(state.activeWindowId).toBe("github");
    expect(state.order.map((id) => state.windows[id].zOrder)).toEqual([
      1, 2, 3,
    ]);

    const raised = transition(state, { type: "open", id: "about" });
    expect(raised.result).toMatchObject({ status: "applied", command: "open" });
    expect(raised.state.activeWindowId).toBe("about");
    expect(
      raised.state.order.map((id) => raised.state.windows[id].zOrder),
    ).toEqual([3, 1, 2]);
    expect(Object.keys(raised.state.windows)).toHaveLength(3);
    expect(getWindowManagerInvariantErrors(raised.state)).toEqual([]);

    const repeated = transition(raised.state, { type: "open", id: "about" });
    expect(repeated.result).toMatchObject({
      status: "noop",
      reason: "already-active",
    });
    expect(repeated.state).toBe(raised.state);
  });

  it("focuses only eligible visible windows", () => {
    let state = createWindowManagerState(definitions, "about");
    const hidden = transition(state, { type: "focus", id: "projects" });
    expect(hidden.result).toMatchObject({
      status: "rejected",
      reason: "not-visible",
    });

    state = transition(state, { type: "open", id: "projects" }).state;
    const focused = transition(state, { type: "focus", id: "about" });
    expect(focused.state.activeWindowId).toBe("about");
    expect(focused.result).toMatchObject({
      status: "applied",
      focus: { type: "window", targetId: "about" },
    });
    expect(getWindowManagerInvariantErrors(focused.state)).toEqual([]);
  });

  it("closes active windows predictably and reopens a fresh instance", () => {
    let state = createWindowManagerState(definitions, "about");
    state = transition(state, { type: "open", id: "projects" }).state;
    state = transition(state, { type: "maximize", id: "projects" }).state;

    const closed = transition(state, {
      type: "close",
      id: "projects",
      returnTargetId: "icon-projects",
    });
    expect(closed.state.activeWindowId).toBe("about");
    expect(closed.state.windows.projects).toMatchObject({
      lifecycle: "closed",
      displayMode: "normal",
      zOrder: null,
      restoreRect: null,
      currentRect: definitions[1].initialRect,
    });
    expect(closed.result).toMatchObject({
      focus: { type: "return", targetId: "icon-projects" },
    });

    const reopened = transition(closed.state, { type: "open", id: "projects" });
    expect(reopened.state.windows.projects).toMatchObject({
      lifecycle: "open",
      displayMode: "normal",
      currentRect: definitions[1].initialRect,
    });
    expect(Object.keys(reopened.state.windows)).toHaveLength(3);
    expect(getWindowManagerInvariantErrors(reopened.state)).toEqual([]);
  });

  it("minimizes, selects the next active window, and restores via taskbar", () => {
    let state = createWindowManagerState(definitions, "about");
    state = transition(state, { type: "open", id: "projects" }).state;
    const minimized = transition(state, {
      type: "minimize",
      id: "projects",
      returnTargetId: "task-projects",
    });

    expect(minimized.state.activeWindowId).toBe("about");
    expect(minimized.state.windows.projects).toMatchObject({
      lifecycle: "minimized",
      zOrder: null,
    });
    expect(minimized.result).toMatchObject({
      focus: { type: "return", targetId: "task-projects" },
    });

    const restored = transition(minimized.state, {
      type: "restore-from-taskbar",
      id: "projects",
    });
    expect(restored.state.activeWindowId).toBe("projects");
    expect(restored.state.windows.projects.lifecycle).toBe("open");
    expect(restored.result).toMatchObject({
      focus: { type: "window", targetId: "projects" },
    });
    expect(getWindowManagerInvariantErrors(restored.state)).toEqual([]);
  });

  it("has no active window when no eligible window remains", () => {
    const state = createWindowManagerState(definitions, "about");
    const minimized = transition(state, { type: "minimize", id: "about" });
    expect(minimized.state.activeWindowId).toBeNull();
    expect(getWindowManagerInvariantErrors(minimized.state)).toEqual([]);

    const closed = transition(state, { type: "close", id: "about" });
    expect(closed.state.activeWindowId).toBeNull();
    expect(getWindowManagerInvariantErrors(closed.state)).toEqual([]);
  });

  it("maximizes once, preserves restore geometry, and restores size", () => {
    const state = createWindowManagerState(definitions, "about");
    const maximized = transition(state, { type: "maximize", id: "about" });
    expect(maximized.state.windows.about).toMatchObject({
      displayMode: "maximized",
      restoreRect: definitions[0].initialRect,
    });

    const repeated = transition(maximized.state, {
      type: "maximize",
      id: "about",
    });
    expect(repeated.result).toMatchObject({
      status: "noop",
      reason: "already-maximized",
    });

    const restored = transition(maximized.state, {
      type: "restore-size",
      id: "about",
    });
    expect(restored.state.windows.about).toMatchObject({
      displayMode: "normal",
      restoreRect: null,
      currentRect: definitions[0].initialRect,
    });
    expect(getWindowManagerInvariantErrors(restored.state)).toEqual([]);
  });

  it("retains maximized mode through minimize and taskbar restore", () => {
    let state = createWindowManagerState(definitions, "about");
    state = transition(state, { type: "maximize", id: "about" }).state;
    state = transition(state, { type: "minimize", id: "about" }).state;
    state = transition(state, {
      type: "restore-from-taskbar",
      id: "about",
    }).state;
    expect(state.windows.about.displayMode).toBe("maximized");
    expect(state.windows.about.restoreRect).toEqual(definitions[0].initialRect);
  });

  it("updates geometry only for visible normal windows", () => {
    const state = createWindowManagerState(definitions, "about");
    const rect = { x: 80, y: 70, width: 640, height: 440 };
    const moved = transition(state, { type: "set-rect", id: "about", rect });
    expect(moved.state.windows.about.currentRect).toEqual(rect);
    expect(moved.result).toMatchObject({ status: "applied", focus: null });

    const maximized = transition(moved.state, {
      type: "maximize",
      id: "about",
    }).state;
    expect(
      transition(maximized, { type: "set-rect", id: "about", rect }).result,
    ).toMatchObject({ status: "rejected", reason: "not-normal" });
    expect(
      transition(state, { type: "set-rect", id: "projects", rect }).result,
    ).toMatchObject({ status: "rejected", reason: "not-visible" });
    const minimized = transition(state, { type: "minimize", id: "about" });
    expect(
      transition(minimized.state, {
        type: "set-rect",
        id: "about",
        rect,
      }).result,
    ).toMatchObject({ status: "rejected", reason: "not-visible" });
    expect(
      transition(state, {
        type: "set-rect",
        id: "about",
        rect: { ...rect, width: Number.NaN },
      }).result,
    ).toMatchObject({ status: "rejected", reason: "invalid-geometry" });
  });

  it("recovers current and maximized restore rectangles for a changed workspace", () => {
    let state = createWindowManagerState(definitions, "about");
    state = transition(state, {
      type: "set-rect",
      id: "about",
      rect: { x: 900, y: 700, width: 720, height: 520 },
    }).state;
    state = transition(state, { type: "maximize", id: "about" }).state;
    const recovered = transition(state, {
      type: "recover-workspace",
      workspace: { width: 800, height: 600 },
    });

    expect(recovered.state.windows.about.currentRect).toEqual({
      x: 80,
      y: 80,
      width: 720,
      height: 520,
    });
    expect(recovered.state.windows.about.restoreRect).toEqual({
      x: 80,
      y: 80,
      width: 720,
      height: 520,
    });
    const restored = transition(recovered.state, {
      type: "restore-size",
      id: "about",
    });
    expect(restored.state.windows.about.currentRect).toEqual({
      x: 80,
      y: 80,
      width: 720,
      height: 520,
    });
    expect(getWindowManagerInvariantErrors(restored.state)).toEqual([]);
  });

  it("returns exhaustive safe results for repeated and invalid commands", () => {
    const state = createWindowManagerState(definitions, "about");
    const cases: Array<[WindowCommand, string, string]> = [
      [{ type: "close", id: "projects" }, "noop", "already-closed"],
      [{ type: "restore-from-taskbar", id: "about" }, "noop", "not-minimized"],
      [{ type: "restore-size", id: "about" }, "noop", "already-normal"],
      [{ type: "open", id: "missing" }, "rejected", "invalid-id"],
      [{ type: "maximize", id: "projects" }, "rejected", "not-visible"],
    ];

    for (const [command, status, reason] of cases) {
      const result = transition(state, command);
      expect(result.state).toBe(state);
      expect(result.result).toMatchObject({ status, reason });
    }

    const unsupported = createWindowManagerState(
      [{ ...definitions[0], canMaximize: false }],
      "about",
    );
    expect(
      transition(unsupported, { type: "maximize", id: "about" }).result,
    ).toMatchObject({ status: "rejected", reason: "unsupported" });
  });
});
