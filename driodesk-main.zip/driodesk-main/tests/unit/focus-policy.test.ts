import { describe, expect, it } from "vitest";

import {
  getFocusCandidates,
  selectFocusCandidate,
  type FocusCandidate,
} from "../../src/lib/focus-policy";

const label = (candidate: FocusCandidate) =>
  candidate.type === "id" ? `id:${candidate.id}` : candidate.type;

describe("focus policy", () => {
  it("orders a requested return target before the active window and stable fallbacks", () => {
    expect(
      getFocusCandidates(
        { type: "return", targetId: "desktop-icon-projects" },
        "about",
      ).map(label),
    ).toEqual([
      "id:desktop-icon-projects",
      "active-window",
      "start-trigger",
      "desktop-launcher",
      "desktop-root",
    ]);
  });

  it("omits the active-window candidate when no eligible active window exists", () => {
    expect(
      getFocusCandidates({ type: "return", targetId: "missing" }, null).map(
        label,
      ),
    ).toEqual([
      "id:missing",
      "start-trigger",
      "desktop-launcher",
      "desktop-root",
    ]);
  });

  it("skips missing and disconnected targets deterministically", () => {
    const connected = new Map([
      ["id:return-target", { name: "return", connected: false }],
      ["active-window", { name: "active", connected: false }],
      ["start-trigger", { name: "start", connected: true }],
    ]);
    const candidates = getFocusCandidates(
      { type: "return", targetId: "return-target" },
      "about",
    );

    expect(
      selectFocusCandidate(
        candidates,
        (candidate) => connected.get(label(candidate)) ?? null,
        (target) => target.connected,
      ),
    ).toEqual({ name: "start", connected: true });
  });
});
