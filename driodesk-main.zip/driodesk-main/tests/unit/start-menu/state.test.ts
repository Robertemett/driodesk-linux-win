import { describe, expect, it } from "vitest";

import {
  createStartMenuState,
  reduceStartMenu,
} from "../../../src/lib/start-menu/state";

describe("Start menu state", () => {
  it("validates item counts and normalizes an invalid current item", () => {
    expect(() => createStartMenuState(0)).toThrow(/at least one item/);
    expect(createStartMenuState(4, 8)).toEqual({
      open: false,
      activeIndex: 0,
      itemCount: 4,
    });
  });

  it("opens at current, first, or last and closes without losing position", () => {
    let state = createStartMenuState(4, 2);
    state = reduceStartMenu(state, { type: "open" });
    expect(state).toMatchObject({ open: true, activeIndex: 2 });
    state = reduceStartMenu(state, { type: "close" });
    expect(state).toMatchObject({ open: false, activeIndex: 2 });
    expect(
      reduceStartMenu(state, { type: "open", placement: "first" }).activeIndex,
    ).toBe(0);
    expect(
      reduceStartMenu(state, { type: "open", placement: "last" }).activeIndex,
    ).toBe(3);
  });

  it("moves, wraps, and supports Home and End transitions", () => {
    let state = { ...createStartMenuState(4), open: true };
    state = reduceStartMenu(state, { type: "previous" });
    expect(state.activeIndex).toBe(3);
    state = reduceStartMenu(state, { type: "next" });
    expect(state.activeIndex).toBe(0);
    state = reduceStartMenu(state, { type: "last" });
    expect(state.activeIndex).toBe(3);
    state = reduceStartMenu(state, { type: "first" });
    expect(state.activeIndex).toBe(0);
  });
});
