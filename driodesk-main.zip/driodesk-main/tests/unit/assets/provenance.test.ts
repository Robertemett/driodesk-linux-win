import { describe, expect, it } from "vitest";

import provenance from "../../../src/content/assets/provenance.json";
import { portfolioContent } from "../../../src/lib/content/normalize";

describe("published asset provenance", () => {
  it("matches every approved content asset to its auditable manifest identity", () => {
    const approvedAssets = portfolioContent.published.assets;

    expect(provenance).toHaveLength(approvedAssets.length);
    for (const asset of approvedAssets) {
      const record = provenance.find(({ id }) => id === asset.id);
      expect(record).toMatchObject({
        localPath: asset.localPath,
        sourcePath: asset.sourcePath,
        outputPath: asset.outputPath,
        origin: asset.origin,
        creator: asset.creator,
        permission: asset.permission,
        license: asset.license,
        sanitization: asset.sanitization,
        sourceSha256: asset.sourceSha256,
        outputSha256: asset.outputSha256,
      });
    }
  });

  it("gives every asset one explicit accessible treatment", () => {
    expect(
      provenance.every(({ altTreatment }) =>
        /^(Decorative|Informative):/.test(altTreatment),
      ),
    ).toBe(true);
  });

  it("records the temporary GitHub avatar source and sanitized identity", () => {
    expect(provenance.find(({ id }) => id === "profile-avatar")).toMatchObject({
      localPath: "/assets/profile/danny-riofrio-avatar.png",
      origin: expect.stringContaining(
        "https://avatars.githubusercontent.com/u/6634090?v=4",
      ),
      permission: "approved",
      sanitization: "approved",
      sourceSha256:
        "6719dd868e19f6e1fd4a9cbce99bfd3d4e8bfbf57f6013ac398b2cf1581278fe",
      outputSha256:
        "6719dd868e19f6e1fd4a9cbce99bfd3d4e8bfbf57f6013ac398b2cf1581278fe",
    });
  });
});
