import { expect, test } from "@playwright/test";

const stableRoutes = ["/", "/about/", "/experience/", "/projects/", "/github/"];

function luminance(rgb: string) {
  const channels = rgb
    .match(/[\d.]+/g)
    ?.slice(0, 3)
    .map(Number)
    .map((channel) => {
      const normalized = channel / 255;
      return normalized <= 0.04045
        ? normalized / 12.92
        : ((normalized + 0.055) / 1.055) ** 2.4;
    });
  if (!channels || channels.length !== 3)
    throw new Error(`Invalid color: ${rgb}`);
  return channels[0] * 0.2126 + channels[1] * 0.7152 + channels[2] * 0.0722;
}

function contrastRatio(foreground: string, background: string) {
  const values = [luminance(foreground), luminance(background)].sort(
    (a, b) => b - a,
  );
  return (values[0] + 0.05) / (values[1] + 0.05);
}

test("navigates every stable route without JavaScript", async ({ page }) => {
  const applicationRequests: string[] = [];

  page.on("request", (request) => {
    if (new URL(request.url()).pathname.startsWith("/api/")) {
      applicationRequests.push(request.url());
    }
  });

  await page.goto("/");

  await expect(page.locator("html")).toHaveAttribute("lang", "es");
  await expect(
    page.getByRole("heading", {
      level: 1,
      name: "About",
    }),
  ).toBeVisible();
  await expect(page.getByRole("main")).toBeVisible();
  await expect(page.getByRole("contentinfo")).toBeVisible();

  const directory = page.getByRole("navigation", {
    name: "Aplicaciones del escritorio",
  });
  await directory.getByRole("link", { name: "About" }).click();
  await expect(page).toHaveURL(/\/about\/$/);
  await expect(
    page.getByRole("heading", { level: 1, name: "About" }),
  ).toBeVisible();
  await expect(page.getByText(/CV general en español/)).toBeVisible();

  await page.getByRole("link", { name: "Experience" }).first().click();
  await expect(page).toHaveURL(/\/experience\/$/);
  await expect(
    page.getByRole("heading", { level: 1, name: "Experience" }),
  ).toBeVisible();

  await page.getByRole("link", { name: "Projects" }).first().click();
  await expect(page).toHaveURL(/\/projects\/$/);
  await expect(
    page.getByRole("heading", { level: 1, name: "Projects" }),
  ).toBeVisible();

  await page.getByRole("link", { name: "GitHub" }).first().click();
  await expect(page).toHaveURL(/\/github\/$/);
  await expect(
    page.getByRole("heading", { level: 1, name: "GitHub" }),
  ).toBeVisible();
  await expect(page.locator("select")).toHaveCount(0);
  await expect(page.locator('a[href^="/en/"]')).toHaveCount(0);
  expect(applicationRequests).toEqual([]);
});

test("does not expose unpublished case-study routes", async ({ request }) => {
  for (const path of [
    "/projects/harunna-investments/",
    "/projects/reimbursement-tracker/",
  ]) {
    const response = await request.get(path);
    expect(response.status()).toBe(404);
  }
});

test("renders the retro vocabulary at desktop and narrow widths", async ({
  page,
}) => {
  for (const viewport of [
    { width: 1280, height: 800 },
    { width: 360, height: 800 },
  ]) {
    await page.setViewportSize(viewport);
    for (const path of stableRoutes) {
      await page.goto(path);
      await expect(page.locator("main.retro-window:visible")).toHaveCount(1);
      await expect(page.locator("[data-static-desktop]")).toBeVisible();
      const geometry = await page.evaluate(() => {
        const taskbar = document.querySelector("footer.desktop-taskbar");
        if (!(taskbar instanceof HTMLElement))
          throw new Error("Missing taskbar");
        const bounds = taskbar.getBoundingClientRect();
        return {
          documentHeight: document.documentElement.scrollHeight,
          documentWidth: document.documentElement.scrollWidth,
          taskbarBottom: bounds.bottom,
          viewportHeight: window.innerHeight,
          viewportWidth: window.innerWidth,
        };
      });
      expect(geometry.documentWidth).toBeLessThanOrEqual(
        geometry.viewportWidth,
      );
      expect(geometry.documentHeight).toBeLessThanOrEqual(
        geometry.viewportHeight,
      );
      expect(geometry.taskbarBottom).toBeCloseTo(geometry.viewportHeight, 0);
    }
  }
});

test("scrolls oversized route content inside the open window", async ({
  page,
}) => {
  await page.setViewportSize({ width: 360, height: 640 });
  await page.goto("/about/");

  const body = page.locator(".about-window__body");
  const titleBar = page.locator(".about-window__title-bar");
  const taskbar = page.locator(".desktop-taskbar");
  const titleTop = (await titleBar.boundingBox())?.y;

  await body.evaluate((element) => {
    const fixture = document.createElement("div");
    fixture.style.height = "1600px";
    fixture.setAttribute("data-overflow-fixture", "");
    element.append(fixture);
    element.scrollTop = 800;
  });

  const state = await body.evaluate((element) => ({
    clientHeight: element.clientHeight,
    scrollHeight: element.scrollHeight,
    scrollTop: element.scrollTop,
    documentHeight: document.documentElement.scrollHeight,
    viewportHeight: window.innerHeight,
  }));
  expect(state.scrollHeight).toBeGreaterThan(state.clientHeight);
  expect(state.scrollTop).toBeGreaterThan(0);
  expect(state.documentHeight).toBeLessThanOrEqual(state.viewportHeight);
  expect((await titleBar.boundingBox())?.y).toBe(titleTop);
  expect((await taskbar.boundingBox())?.y).toBeGreaterThan(
    state.viewportHeight - 60,
  );
});

test("renders the static desktop, shared About view, and truthful affordances", async ({
  page,
}) => {
  await page.goto("/");

  const apps = page.getByRole("navigation", {
    name: "Aplicaciones del escritorio",
  });
  await expect(apps.getByRole("link")).toHaveCount(4);
  for (const [name, href] of [
    ["About", "/about/"],
    ["Experience", "/experience/"],
    ["Projects", "/projects/"],
    ["GitHub", "/github/"],
  ]) {
    await expect(apps.getByRole("link", { name })).toHaveAttribute(
      "href",
      href,
    );
  }
  await expect(
    page.getByRole("heading", { name: "My Documents" }),
  ).toBeVisible();
  await expect(
    page.getByText(/disponible en una unidad posterior/),
  ).toBeVisible();
  await expect(page.getByRole("link", { name: "My Documents" })).toHaveCount(0);
  const startTrigger = page.getByRole("button", { name: "Inicio" });
  await expect(startTrigger).toBeHidden();
  await expect(page.locator("[data-start-item]")).toHaveCount(4);
  await expect(page.locator("[data-start-item]").first()).toHaveAttribute(
    "href",
    "/about/",
  );
  await expect(page.locator(".about-window__static-label")).toHaveText(
    "Vista estática",
  );
  await expect(
    page.locator("main[data-about-projection='about']"),
  ).toBeVisible();
  await expect(
    page.locator('img[src="/assets/icons/portfolio-mark.svg"]'),
  ).toHaveCount(4);
  await expect(
    page.locator('img[src="/assets/profile/danny-riofrio-avatar.png"]'),
  ).toHaveAttribute(
    "alt",
    "Avatar actual del perfil público de GitHub de Danny Riofrio",
  );

  const response = await page.request.get(
    "/assets/profile/danny-riofrio-avatar.png",
  );
  expect(response.status()).toBe(200);
  expect(response.headers()["content-type"]).toContain("image/png");
});

test("communicates the five success signals and real evidence paths before enhancement", async ({
  page,
}) => {
  await page.goto("/");

  const about = page.locator("main[data-about-projection='about']");
  await expect(
    about.getByText("Danny Riofrio", { exact: false }),
  ).toBeVisible();
  await expect(
    about.getByText("Senior Software Engineer", { exact: false }),
  ).toBeVisible();
  await expect(about.getByText("10+ años de experiencia")).toBeVisible();
  await expect(about.getByText("Murcia, Spain")).toBeVisible();
  await expect(about.getByText(/Java, Spring, Kafka, APIs/)).toBeVisible();
  await expect(about.getByText(/TypeScript, Python, cloud/)).toBeVisible();
  await expect(about.getByText(/requisitos, hoja de ruta/)).toBeVisible();

  for (const [name, href] of [
    ["Ver experiencia", "/experience/"],
    ["Ver proyectos", "/projects/"],
    ["LinkedIn", "https://www.linkedin.com/in/danny-riofrio-jimenez"],
    ["Correo profesional", "mailto:dannyriofriojimenez@gmail.com"],
  ]) {
    await expect(about.getByRole("link", { name })).toHaveAttribute(
      "href",
      href,
    );
  }
  await expect(about.getByRole("link", { name: /CV/ })).toHaveCount(0);
  await expect(about.getByText(/CV general en español/)).toBeVisible();

  const homeCopy = (await about.innerText()).replaceAll(/\s+/g, " ").trim();
  await page.goto("/about/");
  const routeCopy = (
    await page.locator("main[data-about-projection='about']").innerText()
  )
    .replaceAll(/\s+/g, " ")
    .trim();
  expect(routeCopy).toBe(homeCopy);
});

test("keeps the About document before duplicate desktop navigation in browse order", async ({
  page,
}) => {
  await page.goto("/");
  const order = await page
    .locator("[data-static-desktop]")
    .evaluate((desktop) => {
      const main = desktop.querySelector("main");
      const navigation = desktop.querySelector(".desktop-icons");
      if (!main || !navigation) throw new Error("Missing desktop landmarks");
      return Boolean(
        main.compareDocumentPosition(navigation) &
        Node.DOCUMENT_POSITION_FOLLOWING,
      );
    });
  expect(order).toBe(true);
});

test("keeps keyboard focus visible and text contrast sufficient", async ({
  page,
}) => {
  await page.goto("/");
  await page.keyboard.press("Tab");

  const focused = page.locator(":focus");
  await expect(focused).toHaveAttribute("href", "#contenido");
  const focusStyle = await focused.evaluate((element) => {
    const style = getComputedStyle(element);
    const bounds = element.getBoundingClientRect();
    return {
      outlineColor: style.outlineColor,
      outlineStyle: style.outlineStyle,
      outlineWidth: Number.parseFloat(style.outlineWidth),
      top: bounds.top,
    };
  });
  expect(focusStyle.outlineStyle).toBe("solid");
  expect(focusStyle.outlineWidth).toBeGreaterThanOrEqual(3);
  expect(focusStyle.top).toBeGreaterThanOrEqual(0);

  for (const selector of [
    ".about-window__body",
    ".retro-title-bar",
    "a.retro-menu-item",
  ]) {
    const colors = await page
      .locator(selector)
      .first()
      .evaluate((element) => {
        const style = getComputedStyle(element);
        return { foreground: style.color, background: style.backgroundColor };
      });
    expect(
      contrastRatio(colors.foreground, colors.background),
    ).toBeGreaterThanOrEqual(4.5);
  }
});

test("reflows at 200 percent zoom and preserves touch-size targets", async ({
  page,
}) => {
  await page.setViewportSize({ width: 640, height: 900 });
  await page.goto("/");
  await page.evaluate(() => {
    document.documentElement.style.zoom = "2";
  });

  expect(
    await page.evaluate(
      () =>
        document.documentElement.scrollWidth <=
        document.documentElement.clientWidth,
    ),
  ).toBe(true);
  await expect(page.getByRole("heading", { level: 1 })).toBeVisible();

  await page.evaluate(() => {
    document.documentElement.style.zoom = "1";
  });
  await page.setViewportSize({ width: 360, height: 800 });
  for (const target of await page
    .locator(
      ".retro-menu-item:visible, .retro-button:visible, .retro-taskbar-item:visible, .desktop-icon:visible",
    )
    .all()) {
    const box = await target.boundingBox();
    expect(box?.height).toBeGreaterThanOrEqual(44);
    expect(box?.width).toBeGreaterThanOrEqual(44);
  }
});

test("reduces motion without removing visual state", async ({ page }) => {
  await page.emulateMedia({ reducedMotion: "reduce" });
  await page.goto("/");

  const state = await page
    .locator(".retro-button")
    .first()
    .evaluate((element) => {
      const style = getComputedStyle(element);
      return {
        animationDuration: Number.parseFloat(style.animationDuration),
        transitionDuration: Number.parseFloat(style.transitionDuration),
        display: style.display,
      };
    });
  expect(state.animationDuration).toBeLessThanOrEqual(0.001);
  expect(state.transitionDuration).toBeLessThanOrEqual(0.001);
  expect(state.display).not.toBe("none");
});
