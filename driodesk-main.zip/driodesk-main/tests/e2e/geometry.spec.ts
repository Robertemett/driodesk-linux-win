import { expect, test, type Locator, type Page } from "@playwright/test";

const appWindow = (page: Page, id = "about") =>
  page.locator(`[data-app-window="${id}"]`);

async function bounds(locator: Locator) {
  const box = await locator.boundingBox();
  if (!box) throw new Error("Expected visible geometry");
  return box;
}

async function beginGesture(
  page: Page,
  target: Locator,
  point?: { x: number; y: number },
) {
  const box = await bounds(target);
  const start = point ?? {
    x: box.x + Math.min(64, box.width / 2),
    y: box.y + box.height / 2,
  };
  await page.mouse.move(start.x, start.y);
  await page.mouse.down();
  await expect
    .poll(() => target.evaluate((element) => element.hasPointerCapture(1)))
    .toBe(true);
  return start;
}

async function expectGestureRejected(page: Page, window: Locator) {
  const title = window.locator("[data-window-drag-handle]");
  const before = await window.evaluate((element) => ({
    lifecycle: element.dataset.lifecycle,
    transform: element.style.transform,
    width: element.style.width,
    height: element.style.height,
    hidden: (element as HTMLElement).hidden,
  }));

  if (before.hidden)
    await window.evaluate((element) => {
      (element as HTMLElement).hidden = false;
    });

  const titleBox = await bounds(title);
  await page.mouse.move(titleBox.x + 60, titleBox.y + titleBox.height / 2);
  await page.mouse.down();
  expect(await title.evaluate((element) => element.hasPointerCapture(1))).toBe(
    false,
  );
  await page.mouse.move(titleBox.x + 200, titleBox.y + 120);
  await page.mouse.up();

  expect(
    await window.evaluate((element) => ({
      lifecycle: element.dataset.lifecycle,
      transform: element.style.transform,
      width: element.style.width,
      height: element.style.height,
    })),
  ).toEqual({
    lifecycle: before.lifecycle,
    transform: before.transform,
    width: before.width,
    height: before.height,
  });

  if (before.hidden)
    await window.evaluate((element) => {
      (element as HTMLElement).hidden = true;
    });
}

test.beforeEach(async ({ page }) => {
  await page.setViewportSize({ width: 1400, height: 850 });
  await page.goto("/");
});

test("drags and resizes without focus churn or announcements", async ({
  page,
}) => {
  const window = appWindow(page);
  const title = window.locator("[data-window-drag-handle]");
  const close = window.getByRole("button", { name: "Cerrar About" });
  await close.focus();
  const initial = await bounds(window);
  const start = await beginGesture(page, title);

  await page.locator("[data-desktop-root]").dispatchEvent("pointermove", {
    pointerId: 99,
    clientX: start.x + 400,
    clientY: start.y + 300,
  });
  expect(await bounds(window)).toEqual(initial);

  await page.mouse.move(start.x + 240, start.y + 140, { steps: 4 });
  await page.mouse.up();
  const moved = await bounds(window);
  expect(moved.x).toBeGreaterThan(initial.x);
  expect(moved.y).toBeGreaterThan(initial.y);
  await expect(close).toBeFocused();

  const east = window.locator('[data-window-resize="e"]');
  const resizeStart = await beginGesture(page, east);
  await page.mouse.move(resizeStart.x + 40, resizeStart.y);
  await page.mouse.up();
  await expect(close).toBeFocused();
  await expect(page.locator("[aria-live]")).toHaveCount(0);
});

test("renders all resize edges and corners and clamps resizing to minimum dimensions", async ({
  page,
}) => {
  const window = appWindow(page);
  for (const edge of ["n", "ne", "e", "se", "s", "sw", "w", "nw"]) {
    await expect(
      window.locator(`[data-window-resize="${edge}"]`),
    ).toBeVisible();
  }

  const east = window.locator('[data-window-resize="e"]');
  const initial = await bounds(window);
  let start = await beginGesture(page, east);
  await page.mouse.move(start.x + 80, start.y);
  await page.mouse.up();
  expect((await bounds(window)).width).toBeCloseTo(initial.width + 80, 0);

  const west = window.locator('[data-window-resize="w"]');
  const beforeWest = await bounds(window);
  start = await beginGesture(page, west);
  await page.mouse.move(start.x + 50, start.y);
  await page.mouse.up();
  const afterWest = await bounds(window);
  expect(afterWest.x).toBeCloseTo(beforeWest.x + 50, 0);
  expect(afterWest.x + afterWest.width).toBeCloseTo(
    beforeWest.x + beforeWest.width,
    0,
  );

  const southeast = window.locator('[data-window-resize="se"]');
  const beforeSoutheast = await bounds(window);
  start = await beginGesture(page, southeast);
  await page.mouse.move(start.x + 40, start.y + 30);
  await page.mouse.up();
  const afterSoutheast = await bounds(window);
  expect(afterSoutheast.width).toBeCloseTo(beforeSoutheast.width + 40, 0);
  expect(afterSoutheast.height).toBeCloseTo(beforeSoutheast.height + 30, 0);

  start = await beginGesture(page, east);
  await page.mouse.move(0, start.y);
  await page.mouse.up();
  expect((await bounds(window)).width).toBeGreaterThanOrEqual(320);
});

test("cleans up an active gesture on pointer cancellation and lost capture", async ({
  page,
}) => {
  const window = appWindow(page);
  const title = window.locator("[data-window-drag-handle]");

  let start = await beginGesture(page, title);
  await title.dispatchEvent("pointercancel", { pointerId: 1 });
  const cancelled = await bounds(window);
  await page.mouse.move(start.x + 180, start.y + 100);
  await page.mouse.up();
  expect(await bounds(window)).toEqual(cancelled);

  start = await beginGesture(page, title);
  await title.evaluate((element) => element.releasePointerCapture(1));
  await title.dispatchEvent("lostpointercapture", { pointerId: 1 });
  const lost = await bounds(window);
  await page.mouse.move(start.x + 180, start.y + 100);
  await page.mouse.up();
  expect(await bounds(window)).toEqual(lost);
});

test("recovers normal and restore geometry when the viewport changes", async ({
  page,
}) => {
  const window = appWindow(page);
  const title = window.locator("[data-window-drag-handle]");
  await beginGesture(page, title);
  await page.mouse.move(1360, 790);
  await page.mouse.up();

  await page.setViewportSize({ width: 900, height: 650 });
  await expect
    .poll(async () => (await bounds(window)).x)
    .toBeGreaterThanOrEqual(0);
  const workspace = await bounds(page.locator("[data-window-workspace]"));
  const recovered = await bounds(window);
  expect(recovered.x + recovered.width).toBeLessThanOrEqual(
    workspace.x + workspace.width + 1,
  );
  expect(recovered.y + recovered.height).toBeLessThanOrEqual(
    workspace.y + workspace.height + 1,
  );

  await window.getByRole("button", { name: "Maximizar About" }).click();
  await page.setViewportSize({ width: 820, height: 620 });
  await window.getByRole("button", { name: "Restaurar About" }).click();
  const restoredWorkspace = await bounds(
    page.locator("[data-window-workspace]"),
  );
  const restored = await bounds(window);
  expect(restored.x).toBeGreaterThanOrEqual(restoredWorkspace.x - 1);
  expect(restored.y).toBeGreaterThanOrEqual(restoredWorkspace.y - 1);
  expect(restored.x + restored.width).toBeLessThanOrEqual(
    restoredWorkspace.x + restoredWorkspace.width + 1,
  );
  expect(restored.y + restored.height).toBeLessThanOrEqual(
    restoredWorkspace.y + restoredWorkspace.height + 1,
  );
});

test("maximizes across the desktop above the operable taskbar and restores exactly", async ({
  page,
}) => {
  const window = appWindow(page);
  const desktop = page.locator("[data-desktop-root]");
  const taskbar = page.locator("[data-desktop-taskbar]");
  const icon = page.locator("#desktop-icon-about");
  const normal = await bounds(window);

  await window.getByRole("button", { name: "Maximizar About" }).click();

  const expectDesktopMaximized = async () => {
    const [desktopBox, taskbarBox, maximizedBox] = await Promise.all([
      bounds(desktop),
      bounds(taskbar),
      bounds(window),
    ]);
    expect(maximizedBox.x).toBeCloseTo(desktopBox.x, 0);
    expect(maximizedBox.y).toBeCloseTo(desktopBox.y, 0);
    expect(maximizedBox.x + maximizedBox.width).toBeCloseTo(
      desktopBox.x + desktopBox.width,
      0,
    );
    expect(maximizedBox.y + maximizedBox.height).toBeCloseTo(taskbarBox.y, 0);
  };

  await expectDesktopMaximized();
  const iconBox = await bounds(icon);
  expect(
    await page.evaluate(
      ({ x, y }) =>
        document
          .elementFromPoint(x, y)
          ?.closest<HTMLElement>("[data-app-window]")?.dataset.appWindow,
      { x: iconBox.x + iconBox.width / 2, y: iconBox.y + iconBox.height / 2 },
    ),
  ).toBe("about");

  const start = page.locator("[data-start-trigger]");
  await start.click();
  await expect(page.locator("[data-start-popup]")).toBeVisible();
  await start.click();

  await window.getByRole("button", { name: "Restaurar About" }).click();
  expect(await bounds(window)).toEqual(normal);
  await window.getByRole("button", { name: "Maximizar About" }).click();

  await page.setViewportSize({ width: 900, height: 650 });
  await expect
    .poll(async () => (await bounds(window)).width)
    .toBeCloseTo(900, 0);
  await expectDesktopMaximized();

  await page.setViewportSize({ width: 1400, height: 850 });
  await expect
    .poll(async () => (await bounds(window)).width)
    .toBeCloseTo(1400, 0);
  await expectDesktopMaximized();
});

test("keeps normal drag and resize geometry inside the workspace", async ({
  page,
}) => {
  const window = appWindow(page);
  const workspace = await bounds(page.locator("[data-window-workspace]"));
  const title = window.locator("[data-window-drag-handle]");
  await beginGesture(page, title);
  await page.mouse.move(0, 0);
  await page.mouse.up();

  let normal = await bounds(window);
  expect(normal.x).toBeCloseTo(workspace.x, 0);
  expect(normal.y).toBeCloseTo(workspace.y, 0);

  const southeast = window.locator('[data-window-resize="se"]');
  await beginGesture(page, southeast);
  await page.mouse.move(2000, 1200);
  await page.mouse.up();

  normal = await bounds(window);
  expect(normal.x + normal.width).toBeLessThanOrEqual(
    workspace.x + workspace.width + 1,
  );
  expect(normal.y + normal.height).toBeLessThanOrEqual(
    workspace.y + workspace.height + 1,
  );
});

test("rejects geometry gestures for maximized, minimized, and closed windows", async ({
  page,
}) => {
  const about = appWindow(page);
  await about.getByRole("button", { name: "Maximizar About" }).click();
  const maximized = await bounds(about);
  await expectGestureRejected(page, about);
  expect(await bounds(about)).toEqual(maximized);

  await about.getByRole("button", { name: "Minimizar About" }).click();
  await expect(about).toBeHidden();
  await expectGestureRejected(page, about);
  await expect(about).toBeHidden();
  await page.locator('[data-taskbar-item="about"]').click();
  await about.getByRole("button", { name: "Cerrar About" }).click();
  await expect(about).toBeHidden();
  await expectGestureRejected(page, about);
  await expect(about).toBeHidden();
});
