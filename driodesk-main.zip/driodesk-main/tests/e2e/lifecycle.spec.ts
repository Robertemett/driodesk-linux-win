import { expect, test, type Page } from "@playwright/test";

const appWindow = (page: Page, id: string) =>
  page.locator(`[data-app-window="${id}"]`);

test("opens About by default and direct routes activate their app", async ({
  page,
}) => {
  for (const [path, id] of [
    ["/", "about"],
    ["/about/", "about"],
    ["/experience/", "experience"],
    ["/projects/", "projects"],
    ["/github/", "github"],
  ]) {
    await page.goto(path);
    await expect(page.locator("[data-desktop-root]")).toHaveAttribute(
      "data-enhanced",
      "true",
    );
    await expect(appWindow(page, id)).toBeVisible();
    await expect(appWindow(page, id)).toHaveAttribute("data-active", "true");
    await expect(page.locator("[data-app-window]:visible")).toHaveCount(1);
  }
});

test("keeps singleton windows open, overlapping, and deterministically stacked", async ({
  page,
}) => {
  await page.setViewportSize({ width: 1280, height: 800 });
  await page.goto("/");

  await page.locator("#desktop-icon-projects").click();
  await expect(appWindow(page, "about")).toBeVisible();
  await expect(appWindow(page, "projects")).toBeVisible();
  await expect(page.locator('[data-app-window="projects"]')).toHaveAttribute(
    "data-active",
    "true",
  );

  const overlap = await page.evaluate(() => {
    const about = document
      .querySelector('[data-app-window="about"]')
      ?.getBoundingClientRect();
    const projects = document
      .querySelector('[data-app-window="projects"]')
      ?.getBoundingClientRect();
    if (!about || !projects) return 0;
    return (
      Math.max(
        0,
        Math.min(about.right, projects.right) -
          Math.max(about.left, projects.left),
      ) *
      Math.max(
        0,
        Math.min(about.bottom, projects.bottom) -
          Math.max(about.top, projects.top),
      )
    );
  });
  expect(overlap).toBeGreaterThan(0);

  await page.locator("#desktop-icon-about").click();
  await page.locator("#desktop-icon-projects").click();
  await expect(page.locator("[data-app-window]:visible")).toHaveCount(2);
  await expect(page.locator('[data-app-window="projects"]')).toHaveCSS(
    "z-index",
    "2",
  );
  await expect(page.locator('[data-app-window="about"]')).toHaveCSS(
    "z-index",
    "1",
  );
  await expect(page.locator('[data-taskbar-item="projects"]')).toHaveAttribute(
    "aria-current",
    "true",
  );
});

test("mirrors lifecycle state in the taskbar and restores window size", async ({
  page,
}) => {
  await page.setViewportSize({ width: 1280, height: 800 });
  await page.goto("/");
  await page.locator("#desktop-icon-projects").click();

  const projects = appWindow(page, "projects");
  const taskbarItem = page.locator('[data-taskbar-item="projects"]');
  await projects.getByRole("button", { name: "Minimizar Projects" }).click();
  await expect(projects).toBeHidden();
  await expect(taskbarItem).toBeVisible();
  await expect(taskbarItem).toHaveAttribute("data-lifecycle", "minimized");
  await expect(appWindow(page, "about")).toHaveAttribute("data-active", "true");

  await taskbarItem.click();
  await expect(projects).toBeVisible();
  await expect(projects).toHaveAttribute("data-active", "true");
  await expect(projects).toBeFocused();

  const normalBounds = await projects.boundingBox();
  await projects.getByRole("button", { name: "Maximizar Projects" }).click();
  await expect(projects).toHaveAttribute("data-display-mode", "maximized");
  const desktopBounds = await page.locator("[data-desktop-root]").boundingBox();
  const taskbarBounds = await page
    .locator("[data-desktop-taskbar]")
    .boundingBox();
  const maximizedBounds = await projects.boundingBox();
  expect(maximizedBounds?.x).toBeCloseTo(desktopBounds?.x ?? -1, 0);
  expect(maximizedBounds?.y).toBeCloseTo(desktopBounds?.y ?? -1, 0);
  expect((maximizedBounds?.x ?? 0) + (maximizedBounds?.width ?? 0)).toBeCloseTo(
    (desktopBounds?.x ?? 0) + (desktopBounds?.width ?? 0),
    0,
  );
  expect(
    (maximizedBounds?.y ?? 0) + (maximizedBounds?.height ?? 0),
  ).toBeCloseTo(taskbarBounds?.y ?? 0, 0);

  await projects.getByRole("button", { name: "Restaurar Projects" }).click();
  await expect(projects).toHaveAttribute("data-display-mode", "normal");
  expect(await projects.boundingBox()).toEqual(normalBounds);

  await projects.getByRole("button", { name: "Cerrar Projects" }).click();
  await expect(projects).toBeHidden();
  await expect(taskbarItem).toBeHidden();
  await expect(page.locator("#desktop-icon-projects")).toBeFocused();
  await expect(appWindow(page, "about")).toHaveAttribute("data-active", "true");

  await page.locator("#desktop-icon-projects").click();
  await expect(projects).toBeVisible();
  await expect(projects).toHaveAttribute("data-display-mode", "normal");
  await expect(page.locator('[data-app-window="projects"]')).toHaveCount(1);
});

test("keeps document geometry fixed while each long app body scrolls", async ({
  page,
}) => {
  for (const viewport of [
    { width: 1280, height: 800 },
    { width: 360, height: 640 },
  ]) {
    await page.setViewportSize(viewport);
    await page.goto("/");
    const body = page.locator('[data-app-window="about"] .about-window__body');
    const title = page.locator('[data-app-window="about"] .retro-title-bar');
    const taskbar = page.locator("[data-desktop-taskbar]");
    const titleBox = await title.boundingBox();
    const taskbarBox = await taskbar.boundingBox();

    await body.evaluate((element) => {
      const fixture = document.createElement("div");
      fixture.style.height = "1600px";
      element.append(fixture);
      element.scrollTop = 900;
    });

    const geometry = await page.evaluate(() => ({
      bodyScrollTop: document.querySelector(".about-window__body")?.scrollTop,
      documentWidth: document.documentElement.scrollWidth,
      documentHeight: document.documentElement.scrollHeight,
      viewportWidth: window.innerWidth,
      viewportHeight: window.innerHeight,
    }));
    expect(geometry.bodyScrollTop).toBeGreaterThan(0);
    expect(geometry.documentWidth).toBeLessThanOrEqual(geometry.viewportWidth);
    expect(geometry.documentHeight).toBeLessThanOrEqual(
      geometry.viewportHeight,
    );
    expect(await title.boundingBox()).toEqual(titleBox);
    expect(await taskbar.boundingBox()).toEqual(taskbarBox);
  }
});

test("preserves native navigation when the enhancement script fails", async ({
  page,
}) => {
  await page.route("**/*", async (route) => {
    if (route.request().resourceType() === "script") await route.abort();
    else await route.continue();
  });
  await page.goto("/");

  await expect(page.locator("[data-desktop-root]")).not.toHaveAttribute(
    "data-enhanced",
    "true",
  );
  await page.locator("#desktop-icon-experience").click();
  await expect(page).toHaveURL(/\/experience\/$/);
  await expect(
    page.getByRole("heading", { level: 1, name: "Experience" }),
  ).toBeVisible();
  await expect(page.getByRole("main")).toBeVisible();
});
