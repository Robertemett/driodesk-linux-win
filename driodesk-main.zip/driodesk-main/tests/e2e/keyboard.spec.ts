import { expect, test, type Locator, type Page } from "@playwright/test";

const appWindow = (page: Page, id: string) =>
  page.locator(`[data-app-window="${id}"]`);

async function expectOutline(locator: Locator) {
  const outline = await locator.evaluate((element) => {
    const style = getComputedStyle(element);
    return {
      style: style.outlineStyle,
      width: Number.parseFloat(style.outlineWidth),
    };
  });
  expect(outline.style).toBe("solid");
  expect(outline.width).toBeGreaterThanOrEqual(3);
}

test.beforeEach(async ({ page }) => {
  await page.setViewportSize({ width: 1280, height: 800 });
  await page.goto("/");
});

test("uses a complete menu-button pattern without trapping Tab or Shift+Tab", async ({
  page,
}) => {
  const start = page.getByRole("button", { name: "Inicio" });
  const menu = page.getByRole("menu", { name: "Menú Inicio" });
  await expect(start).toHaveAttribute("aria-haspopup", "menu");
  await expect(start).toHaveAttribute("aria-controls", "start-menu-popup");
  await expect(start).toHaveAttribute("aria-expanded", "false");
  await expect(menu).toBeHidden();

  await start.focus();
  await page.keyboard.press("Space");
  await expect(start).toHaveAttribute("aria-expanded", "true");
  await expect(menu).toBeVisible();
  await expect(menu.getByRole("menuitem", { name: "About" })).toBeFocused();

  await page.keyboard.press("Tab");
  await expect(page.locator('[data-taskbar-item="about"]')).toBeFocused();
  await expect(start).toHaveAttribute("aria-expanded", "false");
  await page.keyboard.press("Shift+Tab");
  await expect(start).toBeFocused();
});

test("activates desktop, window, taskbar, and Start controls with Enter and Space", async ({
  page,
}) => {
  const experienceIcon = page.locator("#desktop-icon-experience");
  await experienceIcon.focus();
  await page.keyboard.press("Enter");
  await expect(appWindow(page, "experience")).toBeFocused();

  const projectsIcon = page.locator("#desktop-icon-projects");
  await projectsIcon.focus();
  await page.keyboard.press("Space");
  const projects = appWindow(page, "projects");
  await expect(projects).toBeFocused();

  const maximize = projects.getByRole("button", { name: "Maximizar Projects" });
  await maximize.focus();
  await page.keyboard.press("Enter");
  await expect(projects).toHaveAttribute("data-display-mode", "maximized");
  await page.keyboard.press("Space");
  await expect(projects).toHaveAttribute("data-display-mode", "normal");
  await expect(
    projects.locator('[data-window-command="toggle-maximize"]'),
  ).toBeFocused();

  const minimize = projects.getByRole("button", { name: "Minimizar Projects" });
  await minimize.focus();
  await page.keyboard.press("Enter");
  const taskbarItem = page.locator('[data-taskbar-item="projects"]');
  await expect(taskbarItem).toBeFocused();
  await page.keyboard.press("Space");
  await expect(projects).toBeFocused();

  const start = page.getByRole("button", { name: "Inicio" });
  await start.focus();
  await page.keyboard.press("Enter");
  await expect(page.getByRole("menu", { name: "Menú Inicio" })).toBeVisible();
  await page.keyboard.press("Escape");
  await page.keyboard.press("Space");
  const githubItem = page.getByRole("menuitem", { name: "GitHub" });
  await githubItem.focus();
  await page.keyboard.press("Space");
  await expect(appWindow(page, "github")).toBeFocused();
});

test("supports menu arrows, Home and End, but does not invent submenu keys", async ({
  page,
}) => {
  const start = page.getByRole("button", { name: "Inicio" });
  await start.focus();
  await page.keyboard.press("ArrowDown");
  const menuItems = page.getByRole("menuitem");
  await expect(menuItems.nth(0)).toBeFocused();
  await page.keyboard.press("ArrowUp");
  await expect(menuItems.nth(3)).toBeFocused();
  await page.keyboard.press("ArrowDown");
  await expect(menuItems.nth(0)).toBeFocused();
  await page.keyboard.press("End");
  await expect(menuItems.nth(3)).toBeFocused();
  await page.keyboard.press("Home");
  await expect(menuItems.nth(0)).toBeFocused();
  await expect(menuItems.locator('[aria-haspopup="menu"]')).toHaveCount(0);

  for (const key of ["ArrowRight", "ArrowLeft"]) {
    expect(
      await menuItems.nth(0).evaluate(
        (element, pressedKey) =>
          element.dispatchEvent(
            new KeyboardEvent("keydown", {
              key: pressedKey,
              bubbles: true,
              cancelable: true,
            }),
          ),
        key,
      ),
    ).toBe(true);
    await expect(menuItems.nth(0)).toBeFocused();
  }
});

test("gives Start Escape precedence and never closes an application window", async ({
  page,
}) => {
  await page.locator("#desktop-icon-projects").click();
  const visibleWindows = page.locator("[data-app-window]:visible");
  await expect(visibleWindows).toHaveCount(2);

  const start = page.getByRole("button", { name: "Inicio" });
  await start.focus();
  await page.keyboard.press("ArrowDown");
  await page.keyboard.press("Escape");
  await expect(page.getByRole("menu", { name: "Menú Inicio" })).toBeHidden();
  await expect(start).toBeFocused();
  await expect(visibleWindows).toHaveCount(2);

  await page.keyboard.press("Escape");
  await expect(visibleWindows).toHaveCount(2);
  await expect(start).toBeFocused();
});

test("places focus on open and restore and returns it on minimize and close", async ({
  page,
}) => {
  const projectsIcon = page.locator("#desktop-icon-projects");
  await projectsIcon.focus();
  await page.keyboard.press("Enter");
  const projects = appWindow(page, "projects");
  await expect(projects).toBeFocused();

  await projects.getByRole("button", { name: "Minimizar Projects" }).click();
  const taskbarItem = page.locator('[data-taskbar-item="projects"]');
  await expect(taskbarItem).toBeFocused();
  await taskbarItem.press("Enter");
  await expect(projects).toBeFocused();
  await projects.getByRole("button", { name: "Cerrar Projects" }).click();
  await expect(projectsIcon).toBeFocused();

  const about = appWindow(page, "about");
  await page
    .locator("#desktop-icon-about")
    .evaluate((element) => element.remove());
  await about.getByRole("button", { name: "Cerrar About" }).click();
  await expect(page.getByRole("button", { name: "Inicio" })).toBeFocused();
  await expect(page.locator("[data-desktop-root]")).toHaveAttribute(
    "data-active-window",
    "",
  );
});

test("raises keyboard-focused windows above overlaps and keeps focus visible", async ({
  page,
}) => {
  await page.locator("#desktop-icon-projects").click();
  const about = appWindow(page, "about");
  const projects = appWindow(page, "projects");
  await expect(about).toHaveAttribute("data-active", "false");
  const aboutClose = about.getByRole("button", { name: "Cerrar About" });
  await page.keyboard.press("Tab");
  await aboutClose.focus();
  await expect(about).toHaveAttribute("data-active", "true");
  await expect(about).toHaveCSS("z-index", "2");
  await expect(projects).toHaveCSS("z-index", "1");
  await expectOutline(aboutClose);

  const start = page.getByRole("button", { name: "Inicio" });
  await start.focus();
  await page.keyboard.press("ArrowDown");
  const focusedItem = page.getByRole("menuitem", { name: "About" });
  await expectOutline(focusedItem);
  expect(
    await page
      .locator(".start-menu__popup")
      .evaluate((element) =>
        Number.parseInt(getComputedStyle(element).zIndex, 10),
      ),
  ).toBeGreaterThan(
    await page
      .locator("[data-desktop-taskbar]")
      .evaluate((element) =>
        Number.parseInt(getComputedStyle(element).zIndex, 10),
      ),
  );
});

test("reflows the enhanced desktop and Start menu at 200 percent zoom", async ({
  page,
}) => {
  await page.setViewportSize({ width: 640, height: 900 });
  await page.evaluate(() => {
    document.documentElement.style.zoom = "2";
  });
  const start = page.getByRole("button", { name: "Inicio" });
  await start.focus();
  await page.keyboard.press("ArrowDown");

  const geometry = await page.evaluate(() => {
    const focused = document.activeElement?.getBoundingClientRect();
    const taskbar = document
      .querySelector("[data-desktop-taskbar]")
      ?.getBoundingClientRect();
    return {
      documentWidth: document.documentElement.scrollWidth,
      viewportWidth: document.documentElement.clientWidth,
      focusedLeft: focused?.left ?? -1,
      focusedRight: focused?.right ?? Number.POSITIVE_INFINITY,
      taskbarBottom: taskbar?.bottom ?? 0,
      viewportHeight: window.innerHeight,
    };
  });
  expect(geometry.documentWidth).toBeLessThanOrEqual(geometry.viewportWidth);
  expect(geometry.focusedLeft).toBeGreaterThanOrEqual(0);
  expect(geometry.focusedRight).toBeLessThanOrEqual(geometry.viewportWidth);
  expect(geometry.taskbarBottom).toBeCloseTo(geometry.viewportHeight, 0);
});
