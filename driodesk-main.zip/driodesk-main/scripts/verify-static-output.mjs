import { access, readFile, readdir } from "node:fs/promises";
import { stdout } from "node:process";
import { fileURLToPath, URL } from "node:url";
import { join, relative } from "node:path";

const outputDirectory = fileURLToPath(new URL("../dist/", import.meta.url));

const expectedRouteFiles = [
  "index.html",
  "about/index.html",
  "experience/index.html",
  "projects/index.html",
  "github/index.html",
];

await Promise.all(
  expectedRouteFiles.map((file) => access(join(outputDirectory, file))),
);

async function listFiles(directory) {
  const entries = await readdir(directory, { withFileTypes: true });
  const files = await Promise.all(
    entries.map(async (entry) => {
      const path = join(directory, entry.name);
      return entry.isDirectory() ? listFiles(path) : [path];
    }),
  );

  return files.flat();
}

const outputFiles = (await listFiles(outputDirectory)).map((file) =>
  relative(outputDirectory, file).replaceAll("\\", "/"),
);

const hasStaticAsset = outputFiles.some((file) => file.endsWith(".css"));
const serverEntries = outputFiles.filter(
  (file) =>
    /(^|\/)(entry|server)\.mjs$/.test(file) || file.endsWith("_worker.js"),
);
const englishOutput = outputFiles.filter(
  (file) => file === "en/index.html" || file.startsWith("en/"),
);
const unexpectedCaseStudies = outputFiles.filter(
  (file) => file.startsWith("projects/") && file !== "projects/index.html",
);

const routeHtml = await Promise.all(
  expectedRouteFiles.map(async (file) => ({
    file,
    html: await readFile(join(outputDirectory, file), "utf8"),
  })),
);
const extract = (html, expression, name, file) => {
  const value = html.match(expression)?.[1]?.trim();
  if (!value) throw new Error(`${file} has no ${name}.`);
  return value;
};
const titles = routeHtml.map(({ file, html }) =>
  extract(html, /<title>([^<]+)<\/title>/i, "title", file),
);
const descriptions = routeHtml.map(({ file, html }) =>
  extract(
    html,
    /<meta name="description" content="([^"]+)"/i,
    "description",
    file,
  ),
);

if (!hasStaticAsset) {
  throw new Error("The static output does not contain a generated CSS asset.");
}

if (serverEntries.length > 0) {
  throw new Error(`Unexpected server output: ${serverEntries.join(", ")}`);
}

if (englishOutput.length > 0) {
  throw new Error(`Unexpected English output: ${englishOutput.join(", ")}`);
}

if (unexpectedCaseStudies.length > 0) {
  throw new Error(
    `Unpublished case-study output: ${unexpectedCaseStudies.join(", ")}`,
  );
}

if (new Set(titles).size !== titles.length) {
  throw new Error("Generated route titles are not unique.");
}

if (new Set(descriptions).size !== descriptions.length) {
  throw new Error("Generated route descriptions are not unique.");
}

for (const { file, html } of routeHtml) {
  if (!/<html lang="es">/i.test(html))
    throw new Error(`${file} does not declare the Spanish locale.`);
  if (/<select\b/i.test(html))
    throw new Error(`${file} unexpectedly contains a locale selector.`);
  if (/href=""|src=""/i.test(html))
    throw new Error(`${file} contains an empty link or resource output.`);
  if (
    !/<noscript>[\s\S]*Directorio de rutas sin JavaScript[\s\S]*<\/noscript>/i.test(
      html,
    )
  )
    throw new Error(`${file} has no no-JavaScript route directory.`);
  if (!html.includes("data-static-desktop"))
    throw new Error(`${file} has no shared static desktop shell.`);
  if (
    !/<div[^>]+class="[^"]*desktop-shell__workspace[^"]*"[^>]*>[\s\S]*<main[^>]+retro-window/i.test(
      html,
    )
  )
    throw new Error(
      `${file} does not render route content in the desktop workspace.`,
    );
  for (const path of ["/about/", "/experience/", "/projects/", "/github/"]) {
    if (!html.includes(`href="${path}"`))
      throw new Error(`${file} has no native link to ${path}.`);
  }
}

const homeHtml =
  routeHtml.find(({ file }) => file === "index.html")?.html ?? "";
const aboutHtml =
  routeHtml.find(({ file }) => file === "about/index.html")?.html ?? "";
for (const requiredCopy of [
  "Danny Riofrio — Senior Software Engineer",
  "10+ años de experiencia",
  "Murcia, Spain",
  "Java, Spring, Kafka, APIs",
  "TypeScript, Python, cloud",
  "requisitos, hoja de ruta, implementación y verificación",
]) {
  if (!homeHtml.includes(requiredCopy) || !aboutHtml.includes(requiredCopy))
    throw new Error(`Shared About output is missing: ${requiredCopy}`);
}
for (const requiredHref of [
  "/experience/",
  "/projects/",
  "https://www.linkedin.com/in/danny-riofrio-jimenez",
  "mailto:dannyriofriojimenez@gmail.com",
]) {
  if (!homeHtml.includes(`href="${requiredHref}"`))
    throw new Error(`Home About output has no native link to ${requiredHref}.`);
}
if (!homeHtml.includes("data-static-desktop"))
  throw new Error("Home output has no static desktop shell.");
if (!homeHtml.includes('data-about-projection="about"'))
  throw new Error("Home output has no initially rendered About projection.");
if (!homeHtml.includes("Directorio de rutas sin JavaScript"))
  throw new Error("Home output has no explicit no-JavaScript navigation.");
if (/href="[^"]*Danny_Riofrio_CV_ES\.pdf"/i.test(homeHtml + aboutHtml))
  throw new Error("A CV download was emitted without an approved public file.");

stdout.write(
  `Static output contains ${expectedRouteFiles.length} expected route documents and generated assets.\n`,
);
stdout.write("Route metadata is unique, non-empty, and Spanish-only.\n");
stdout.write("No English or unpublished case-study output was found.\n");
stdout.write("Every route contains a native no-JavaScript route directory.\n");
stdout.write(
  "Home contains the shared About facts, real evidence links, and honest CV pending state.\n",
);
stdout.write("No server entry was found.\n");
