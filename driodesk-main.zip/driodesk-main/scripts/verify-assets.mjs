import { createHash } from "node:crypto";
import { readFile, readdir, stat } from "node:fs/promises";
import { extname, join, relative, resolve, sep } from "node:path";
import { stdout } from "node:process";
import { fileURLToPath, URL } from "node:url";

const projectRoot = fileURLToPath(new URL("../", import.meta.url));
const manifestPath = join(
  projectRoot,
  "src",
  "content",
  "assets",
  "provenance.json",
);
const publicRoot = join(projectRoot, "public");
const outputRoot = join(projectRoot, "dist");
const assetExtensions = new Set([
  ".avif",
  ".cur",
  ".gif",
  ".ico",
  ".jpeg",
  ".jpg",
  ".pdf",
  ".png",
  ".svg",
  ".webp",
]);
const prohibitedSourceSignatures = [
  /archivos[\s_-]*eladio/i,
  /microsoft/i,
  /shell32/i,
  /moricons/i,
  /windows[\s_-]*(?:95|98|logo|icon|cursor)/i,
  /(?:font|icon)[\s_-]*pack/i,
];
const privacySignatures = [
  /<metadata\b/i,
  /<script\b/i,
  /<foreignObject\b/i,
  /\b(?:href|xlink:href|src)\s*=/i,
  /\bon[a-z]+\s*=/i,
  /data:/i,
  /<!--/,
  /\bEXIF\b/i,
  /<\?xpacket/i,
  /\/Author\s*\(/i,
  /\/Creator\s*\(/i,
  /[A-Z]:\\Users\\/i,
  /\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/i,
];
const requiredFields = [
  "id",
  "localPath",
  "sourcePath",
  "outputPath",
  "purpose",
  "altTreatment",
  "origin",
  "creator",
  "permission",
  "license",
  "sanitization",
  "sanitizationNotes",
  "optimization",
  "sourceSha256",
  "outputSha256",
  "sourceOutputIdentity",
];

const toPosix = (path) => path.split(sep).join("/");
const hash = (bytes) => createHash("sha256").update(bytes).digest("hex");

async function listAssetFiles(directory) {
  try {
    const entries = await readdir(directory, { withFileTypes: true });
    return (
      await Promise.all(
        entries.map(async (entry) => {
          const path = join(directory, entry.name);
          return entry.isDirectory() ? listAssetFiles(path) : [path];
        }),
      )
    )
      .flat()
      .filter((path) => assetExtensions.has(extname(path).toLowerCase()));
  } catch (error) {
    if (error.code === "ENOENT") return [];
    throw error;
  }
}

const manifest = JSON.parse(await readFile(manifestPath, "utf8"));
if (!Array.isArray(manifest) || manifest.length === 0) {
  throw new Error(
    "Asset provenance manifest must contain at least one record.",
  );
}

const ids = new Set();
const sourcePaths = new Set();
const outputPaths = new Set();

for (const record of manifest) {
  for (const field of requiredFields) {
    if (typeof record[field] !== "string" || record[field].trim() === "") {
      throw new Error(`Asset ${record.id ?? "unknown"} has no ${field}.`);
    }
  }
  if (ids.has(record.id)) throw new Error(`Duplicate asset id: ${record.id}.`);
  ids.add(record.id);
  if (record.permission !== "approved" || record.sanitization !== "approved") {
    throw new Error(`Asset ${record.id} is not approved and sanitized.`);
  }
  if (!/^(Decorative|Informative):/.test(record.altTreatment)) {
    throw new Error(`Asset ${record.id} has no explicit accessible treatment.`);
  }
  if (record.sourcePath !== `public${record.localPath}`) {
    throw new Error(`Asset ${record.id} source/local references do not match.`);
  }
  if (record.outputPath !== `dist${record.localPath}`) {
    throw new Error(`Asset ${record.id} output/local references do not match.`);
  }
  if (record.sourceSha256 !== record.outputSha256) {
    throw new Error(`Asset ${record.id} direct-copy hashes do not match.`);
  }

  const sourcePath = resolve(projectRoot, record.sourcePath);
  const expectedPrefix = `${resolve(publicRoot)}${sep}`;
  if (!sourcePath.startsWith(expectedPrefix)) {
    throw new Error(`Asset ${record.id} source escapes public/.`);
  }
  const sourceBytes = await readFile(sourcePath);
  if (hash(sourceBytes) !== record.sourceSha256) {
    throw new Error(
      `Asset ${record.id} source hash does not match provenance.`,
    );
  }
  const inspectableText = sourceBytes.toString("latin1");
  for (const signature of [
    ...prohibitedSourceSignatures,
    ...privacySignatures,
  ]) {
    if (signature.test(inspectableText) || signature.test(record.sourcePath)) {
      throw new Error(
        `Asset ${record.id} contains prohibited signature ${signature}.`,
      );
    }
  }
  sourcePaths.add(toPosix(relative(projectRoot, sourcePath)));
  outputPaths.add(record.outputPath);
}

const publicAssets = (await listAssetFiles(publicRoot)).map((path) =>
  toPosix(relative(projectRoot, path)),
);
const unrecordedSources = publicAssets.filter((path) => !sourcePaths.has(path));
if (unrecordedSources.length > 0) {
  throw new Error(`Unrecorded public assets: ${unrecordedSources.join(", ")}.`);
}
if (publicAssets.length !== sourcePaths.size) {
  throw new Error("One or more provenance source references are not emitted.");
}

let outputStatus = "dist not present; source gate complete";
try {
  if ((await stat(outputRoot)).isDirectory()) {
    const builtAssets = (await listAssetFiles(outputRoot)).map((path) =>
      toPosix(relative(projectRoot, path)),
    );
    const unrecordedOutputs = builtAssets.filter(
      (path) => !outputPaths.has(path),
    );
    if (unrecordedOutputs.length > 0) {
      throw new Error(
        `Unrecorded built assets: ${unrecordedOutputs.join(", ")}.`,
      );
    }
    for (const record of manifest) {
      const outputBytes = await readFile(
        resolve(projectRoot, record.outputPath),
      );
      if (hash(outputBytes) !== record.outputSha256) {
        throw new Error(
          `Asset ${record.id} built hash does not match provenance.`,
        );
      }
      const text = outputBytes.toString("latin1");
      for (const signature of [
        ...prohibitedSourceSignatures,
        ...privacySignatures,
      ]) {
        if (signature.test(text) || signature.test(record.outputPath)) {
          throw new Error(
            `Built asset ${record.id} contains prohibited signature ${signature}.`,
          );
        }
      }
    }
    outputStatus = `${builtAssets.length} built asset output verified`;
  }
} catch (error) {
  if (error.code !== "ENOENT") throw error;
}

stdout.write(
  `${manifest.length} original asset record verified; ${publicAssets.length} public asset source verified; ${outputStatus}.\n`,
);
stdout.write(
  "Approved provenance, source/output identity, metadata/privacy rules, and prohibited-source checks passed.\n",
);
