# Asset Publication and Provenance Policy

## Approval gate

Only files listed in `src/content/assets/provenance.json` may be emitted from the public asset directories. Each record must identify the original source and output, purpose, accessible treatment, creator, permission or license, sanitization review, optimization, and SHA-256 identity.

The Unit 3 artwork is original project-created work. Microsoft, Windows, Archivos Eladio, icon-pack, font-pack, stock, and other third-party source files are not inputs to the asset pipeline. Visual references may inform broad period characteristics only; they are not copied or traced.

## Omission and replacement

An asset with missing, pending, rejected, contradictory, or unverifiable permission is omitted from `public/` and therefore from built output. The interface must use semantic text or a CSS primitive as its fallback. It must not use an unapproved placeholder that could be mistaken for publishable evidence.

A replacement receives a new provenance record and hash review before references change. The old output is removed in the same work unit. Source and optimized output identities remain explicit; an optimizer must not overwrite or obscure the reviewed source. When the canonical source is already a compact deployable SVG, source and output may intentionally be the same byte-identical file.

## Review procedure

Run `npm run inspect:assets` after the production build. The check enforces manifest-to-source/output references, SHA-256 identity, approved permission and sanitization, decorative or informative treatment, metadata/privacy restrictions, and prohibited source/output signatures.

Human review still inspects every asset at full resolution and confirms that the provenance statement and license match how the file was created. Automated scanning supplements that legal and visual review; it does not replace it.
