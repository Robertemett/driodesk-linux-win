# Portfolio MVP Construction Roadmap

## Roadmap summary

Construction is organized as 15 dependency-ordered, vertically demonstrable work units. Each unit combines the content, rendering, behavior, tests, and documentation needed to review one outcome. Units are candidate implementation/review boundaries only: this roadmap does not choose commits, branches, or pull requests and does not authorize implementation.

The default review budget is **400 authored changed lines per unit** (additions plus deletions). Generated lockfiles, optimized binaries, screenshots, PDFs, and derived assets are reported separately from authored review load but remain part of complete review and release evidence. When a cohesive unit is likely to exceed the budget, split it honestly at the indicated boundary; do not code-golf, defer its tests, or separate documentation by file type.

## Dependency map

```text
1 Foundation
  -> 2 Content model and routes
      -> 3 Visual primitives and asset gate
          -> 4 Static desktop and first visit
              -> 5 Window state core
                  -> 6 Desktop window integration
                      -> 7 Pointer geometry and recovery
                      -> 8 Keyboard, Start menu, and focus
                          -> 9 Mobile capability policy
  -> 10 Experience and education -----------\
  -> 11 Projects and case studies ------------+-> 13 CV, contact, and social metadata
  -> 12 GitHub and historical archive --------/          -> 14 Hardening -> 15 Release

Units 10-12 require Unit 2 and may proceed after their specific inputs are ready.
Units 7 and 8 both require Unit 6; Unit 9 requires both 7 and 8.
Unit 14 requires Units 3-13. Unit 15 requires Unit 14 and production inputs.
```

## Delivery rules

### Definition of ready for a work unit

A unit is ready when its listed prerequisites are evidenced, blocking user inputs are approved, factual copy/assets needed for that outcome are available, and its acceptance evidence can be produced without importing later scope. Unit 1 also finalizes the real command names; until then, this roadmap names command **categories**, not fictional package scripts.

### Definition of done for a work unit

A unit is done when its user-visible outcome works at the unit's intended route/view, all in-scope automated command categories pass with recorded exact commands/results, manual checks are recorded, privacy/provenance gates pass where relevant, and the rollback boundary can be applied without removing unrelated completed behavior. Each unit's **Acceptance evidence** is its specific definition of done.

### Review and rollback discipline

- Slice by behavior, never by models/components/tests/docs alone.
- Keep tests and supporting documentation with the behavior they verify.
- A unit may be rolled back by its named artifacts and behavior boundary whether or not a commit exists.
- Forecast authored line load before implementation. At likely overage, use the recommended sub-boundaries once; if the smallest honest slice still exceeds 400 lines, record the estimate and request a review-size exception rather than compressing the work.
- Generated files and binary assets receive separate identity, size, provenance, and review notes.

## Unit 1 — Static Astro and quality foundation

**User-visible outcome:** A semantic Spanish placeholder page renders locally and as static output, with no client framework or backend.

**Prerequisites:** Approved roadmap and explicit implementation authorization. No Git repository is required beforehand; initialize Git only if that later authorization explicitly includes it.

**In scope:** Astro scaffold; strict TypeScript; static output; baseline semantic layout/page; dependency lockfile; formatter/linter; Astro diagnostics; Vitest and Playwright foundations; documented local/build verification commands.

**Out of scope:** Final content, Windows styling, window behavior, hosting connection, Git/branch/PR strategy unless separately authorized.

**Implementation steps:**
1. Verify current Astro and tooling guidance, then scaffold the smallest static project in the existing directory without replacing approved docs.
2. Enable strict TypeScript and static output with no server adapter.
3. Add one semantic Spanish document proving headings, navigation, and native links render without client JavaScript.
4. Establish minimal format, lint, Astro diagnostic, unit-test, browser-test, and production-build tooling.
5. Record the actual command names and supported runtime versions for all later units; inspect `dist` to prove static output.

**Acceptance evidence (unit definition of done):** Local page screenshot/HTML; successful strict diagnostics, format/lint checks, empty or foundation unit suite, browser smoke, and static build; `dist` contains HTML and assets with no server entry; actual commands are documented for later units.

**Verification command categories to finalize:** Dependency installation; Astro/TypeScript diagnostics; formatter check; lint; focused Vitest; focused Playwright smoke; static production build; static-output inspection. Exact invocations are finalized here and reused by category in Units 2-15.

**Manual checks:** Readability with JavaScript disabled; semantic heading/landmark inspection; no runtime request to an application API.

**Rollback boundary:** Remove the scaffold/tooling and generated dependency artifacts while preserving the three planning/requirements documents and any separately approved repository metadata.

**Risk and review notes:** Tooling can dominate the diff. Forecast likely exceeds 400 authored lines if lint, unit, and browser foundations are configured together; if so, split into (1A) static Astro/strict TypeScript/build and (1B) quality harness, while each slice remains runnable. Review generated lockfile separately from authored lines.

## Unit 2 — Canonical content model and Spanish routes

**User-visible outcome:** About, Experience, Projects, case-study, and GitHub routes render readable Spanish-first content structures and remain navigable without JavaScript.

**Prerequisites:** Unit 1; approved initial Spanish editorial records sufficient to avoid invented copy. Final polish may remain pending, but factual values must be reviewed.

**In scope:** `src/content.config.ts`; typed local collections/loaders; profile, navigation, experience, education, skills, case studies, curated repositories, archive, SEO, and asset-record schemas; relationship validation; route layouts/pages; `<noscript>`/native fallback navigation; unique baseline metadata.

**Out of scope:** Desktop chrome, final visual assets, client interaction, final social images/domain canonicals, publishing incomplete English routes.

**Implementation steps:**
1. Model durable editorial records separately from UI state and encode publication/privacy fields.
2. Load and normalize local content into shared route/view data.
3. Create stable routes for About, Experience, Projects, individual case studies, and GitHub.
4. Add native cross-links and a retro-compatible no-JavaScript route directory.
5. Add structural checks for route ownership, references, Spanish locale, metadata uniqueness, and prohibited inclusion states.

**Acceptance evidence (unit definition of done):** Built HTML exists for all required routes; records validate; route and desktop-view loaders consume one authority; JavaScript-disabled navigation reaches readable content/contact placeholders; no `/en/` output or empty selector exists.

**Verification command categories:** Unit 1 diagnostics; format/lint; focused schema/relationship tests; no-JavaScript Playwright route journey; static build; generated-route/output inspection.

**Manual checks:** Compare facts to requirements; confirm employer/client distinction; confirm NTT DATA ends Jul 2022 and Babel starts Jul 2022; inspect headings and link destinations.

**Rollback boundary:** Remove collection config, normalized content layer, and new stable routes together, returning to Unit 1's semantic page without changing tooling.

**Risk and review notes:** Likely over 400 authored lines. Prefer honest splits: (2A) schemas/normalization with fixtures and tests, then (2B) stable routes/no-JS navigation/metadata using those records. Never split tests from the corresponding slice.

## Unit 3 — Windows 98 visual primitives and lawful asset pipeline

**User-visible outcome:** Stable routes demonstrate a coherent, readable Windows 98-inspired visual vocabulary using only approved assets.

**Prerequisites:** Units 1-2; an initial original/licensed asset set with provenance and usage permissions.

**In scope:** Design tokens; CSS layers; classic surface/button/title/menu/icon/taskbar/window primitives; typography fallbacks; focus and contrast tokens; asset provenance records; image/PDF metadata inspection process; optimized local asset outputs.

**Out of scope:** Full desktop composition, window interactions, copied Microsoft/Archivos Eladio assets, decorative animation library.

**Implementation steps:**
1. Establish token and CSS layer ownership before page-specific styling.
2. Build only reusable visual primitives needed by planned views.
3. Connect each asset to origin, permission/license, purpose, alt/decorative treatment, and sanitization status.
4. Add a review surface on existing routes and test responsive/focus states.
5. Document replacement/omission behavior for any unapproved asset.

**Acceptance evidence (unit definition of done):** Primitive review page/route state is coherent at desktop and narrow widths; contrast/focus checks are recorded; every emitted asset has approved provenance and sanitization state; no prohibited source asset exists in output.

**Verification command categories:** Diagnostics; format/lint; CSS/static build; asset-reference/provenance structural checks; metadata/privacy scan; browser visual smoke.

**Manual checks:** Keyboard focus visibility; contrast; 200% zoom; touch-size preview; license/permission review; full-resolution image inspection; reduced-motion baseline.

**Rollback boundary:** Remove the visual styles/primitives and approved asset outputs while leaving Unit 2 semantic routes/content intact.

**Risk and review notes:** Binary/generated assets are reviewed separately. Authored CSS may exceed 400 lines; split (3A) tokens/surfaces/focus and (3B) icons/cursors/asset pipeline only if each leaves a demonstrable lawful visual surface.

## Unit 4 — Static desktop and first-visit About

**User-visible outcome:** `/` looks like a recognizable desktop, renders About open by default, communicates the five success signals within 30 seconds, and exposes direct evidence paths before JavaScript runs.

**Prerequisites:** Units 2-3; approved About positioning copy and avatar/provenance.

**In scope:** Desktop layout; four primary app icons; secondary My Documents icon; static taskbar/Start affordance; About window markup; shared About view; native links to Experience, Projects, CV, LinkedIn, and email; `<noscript>` navigation.

**Out of scope:** Working window controls, drag/resize, full Start menu keyboard model, completed app copy beyond About.

**Implementation steps:**
1. Compose desktop shell and semantic reading order without changing content authority.
2. Render the shared About projection in the initially open window and `/about/` route.
3. Ensure desktop icons/actions remain real route links before enhancement.
4. Keep My Documents visually secondary and avoid false interactive claims on inactive controls.
5. Validate the 30-second first-visit narrative at representative widths.

**Acceptance evidence (unit definition of done):** `/` server HTML contains meaningful About content and all required evidence paths; About is visually open without script; no-JS navigation works; route/window facts match.

**Verification command categories:** Diagnostics; format/lint; focused content/projection tests; desktop/no-JS Playwright smoke; static build; HTML inspection.

**Manual checks:** Timed 30-second comprehension review; semantic reading order; screen-reader browse-mode pass; narrow reflow; desktop fidelity without obstructing links.

**Rollback boundary:** Remove desktop composition and restore Unit 2's route-led landing page; shared About content/routes remain.

**Risk and review notes:** Likely near/over 400 authored lines because layout, CSS, and journeys are cohesive. Split shell/navigation from About-window composition only if the first slice remains a semantic usable landing page.

## Unit 5 — Deterministic window state core

**User-visible outcome:** No additional controls are enabled yet; the project gains verified deterministic rules that make later window interactions trustworthy.

**Prerequisites:** Unit 4; approved state, command, event, and invariant contracts from the architecture.

**In scope:** Pure state model/reducer; lifecycle commands; singleton app registry; active window and normalized z-order; current/restore rectangles; maximize/restore semantics; capability-aware command rejection; pure focus-intent policy; Vitest coverage.

**Out of scope:** DOM querying/mutation, event listeners, pointer handling, CSS integration, persistence.

**Implementation steps:**
1. Define minimal serializable state and exhaustive command results.
2. Implement lifecycle, activation, z-order, display-mode, and focus-intent transitions.
3. Encode invariants and safe no-ops for invalid/unsupported commands.
4. Test transition tables, repeated commands, one-instance behavior, and z-order normalization.

**Acceptance evidence (unit definition of done):** Unit tests prove all defined transitions and invariants, including repeated open/focus, minimize/restore, close/reopen, maximize/restore, no eligible active window, and invalid command safety.

**Verification command categories:** Diagnostics; format/lint; focused Vitest state/focus suites; full unit suite; static build regression.

**Manual checks:** Review transition table against product requirements; inspect public types for content/UI-state separation.

**Rollback boundary:** Remove the isolated window-manager core and its tests; Unit 4's static desktop remains unchanged.

**Risk and review notes:** Keep below 400 authored lines by avoiding speculative abstractions. If honest coverage exceeds the budget, split lifecycle/z-order from maximize/focus policy, each with its own tests.

## Unit 6 — Desktop window lifecycle integration

**User-visible outcome:** Desktop users can open, focus, close, minimize, restore, maximize, and restore one instance of each app with clear active-window and taskbar state.

**Prerequisites:** Unit 5; static app views/routes available from Unit 2/4.

**In scope:** Enhancement bootstrap; controller and DOM adapter; stable data hooks; state-to-DOM attributes/styles; desktop icons; title-bar controls; taskbar entries; z-order; lifecycle focus placement/return at baseline; failure-safe fallback.

**Out of scope:** Drag/resize, full Start menu keyboard behavior, mobile-specific fullscreen policy, persistence, animation polish.

**Implementation steps:**
1. Validate DOM hooks and initialize state from rendered app identifiers with About open.
2. Translate icon, window-control, and taskbar actions into core commands.
3. Apply state atomically and keep route links available if interception cannot complete.
4. Integrate one-instance, active styling, z-order, minimize/restore, and maximize/restore.
5. Add representative desktop browser journeys and initialization-failure checks.

**Acceptance evidence (unit definition of done):** Playwright proves every lifecycle action, one instance per app, active stacking, taskbar restoration, About initial state, and readable native fallback when enhancement is unavailable.

**Verification command categories:** Diagnostics; format/lint; focused Vitest regression; focused Playwright lifecycle/failure journeys; static build; no-JS regression.

**Manual checks:** Rapid repeated actions feel instant; focus does not disappear; links still navigate after simulated bootstrap failure; screen-reader labels for controls are understandable.

**Rollback boundary:** Remove bootstrap/controller/adapter bindings and interactive attributes while retaining Unit 4's static desktop and Unit 5's isolated tested core.

**Risk and review notes:** High integration risk and likely over 400 authored lines. Prefer (6A) open/focus/close with failure-safe bootstrap, then (6B) taskbar minimize/restore and maximize/restore, preserving tests in each slice.

## Unit 7 — Pointer drag, resize, and viewport recovery

**User-visible outcome:** Desktop windows drag and resize with pointer capture while essential controls remain recoverable after gestures or viewport changes.

**Prerequisites:** Unit 6; minimum window sizes and available desktop-area rules agreed from actual content.

**In scope:** Pure geometry functions; pointer gesture controller; pointer capture/cancellation; move and resize handles; bounds/minimums; maximize exclusions; resize/orientation recalculation; recoverable title/control region; tests.

**Out of scope:** Momentum, springs, multi-window gestures, mobile drag/resize, persisted geometry.

**Implementation steps:**
1. Define geometry inputs/outputs and viewport/title-bar reachability constraints.
2. Test clamp, resize, maximize, restore, and viewport-recovery boundaries.
3. Integrate initiating-pointer-only gestures with capture and cancellation cleanup.
4. Recalculate visible geometry on viewport/orientation changes before applying styles.
5. Verify focus remains on its original meaningful target throughout geometry changes.

**Acceptance evidence (unit definition of done):** Unit and browser evidence covers every edge/corner, minimum size, pointer leaving bounds, lost capture, resize/orientation changes, and restoration from stale geometry without stranded controls.

**Verification command categories:** Diagnostics; format/lint; focused Vitest geometry suites; focused Playwright pointer/viewport journeys; static build regression.

**Manual checks:** Mouse and touchpad drag/resize; rapid cancellation; zoom/reflow; no lag or momentum; focus remains visible and content usable.

**Rollback boundary:** Remove gesture bindings, resize handles, and geometry integration while preserving Unit 6 lifecycle behavior and the independently tested state core.

**Risk and review notes:** Highest algorithmic interaction risk. Likely over 400 authored lines; split pure geometry/tests from pointer/controller integration, with no untested geometry entering the integration slice.

## Unit 8 — Keyboard, Start menu, focus, and accessibility journeys

**User-visible outcome:** Keyboard and assistive-technology users can traverse icons, windows, taskbar, and Start navigation predictably, with correct focus placement and restoration.

**Prerequisites:** Unit 6; Unit 7 for geometry-related focus regression; final decision from implementation evidence on native disclosure/navigation versus complete ARIA menu pattern.

**In scope:** Tab/Shift+Tab order; Enter activation; Start control/menu; arrow-key nested navigation where the menu pattern is used; Escape transient-layer precedence; focus entry/return; accessible names/states/status; keyboard and screen-reader journeys.

**Out of scope:** Global shortcut system, Escape-to-close windows, decorative keyboard animation, desktop-dialog semantics for ordinary content.

**Implementation steps:**
1. Select the simplest semantic Start pattern that fulfills required arrow behavior without partial ARIA.
2. Implement menu open/close, active item, nesting, and Escape precedence.
3. Complete focus entry and return across open/focus/restore/minimize/close and missing-target fallbacks.
4. Expose only necessary states and suppress noisy pointer-movement announcements.
5. Add browser journeys for keyboard order, no traps, focus visibility, and restoration.

**Acceptance evidence (unit definition of done):** Recorded journeys prove Tab, Shift+Tab, Enter, arrows, and Escape contracts; every lifecycle action has predictable focus; no content window closes on Escape; manual screen-reader review finds coherent names/order.

**Verification command categories:** Diagnostics; format/lint; focused focus-policy Vitest; focused Playwright keyboard/menu/accessibility journeys; automated accessibility scan if established; static build.

**Manual checks:** Keyboard-only full pass; at least one screen reader; 200% zoom; visible focus over every visual layer; rapid repeated keyboard actions have no blocking animation.

**Rollback boundary:** Remove Start/menu enhancement and advanced focus bindings, restoring native route navigation and Unit 6 baseline lifecycle controls.

**Risk and review notes:** ARIA/menu/focus complexity is high and likely over 400 authored lines. Split (8A) lifecycle focus contracts and (8B) Start menu keyboard model only if each has complete journeys.

## Unit 9 — Mobile fullscreen and capability policy

**User-visible outcome:** At narrow viewports, apps open fullscreen, drag/resize disappears, taskbar minimize/restore remains touch-usable, and orientation changes never strand content or focus.

**Prerequisites:** Units 7-8; representative content available for sizing; responsive capability breakpoint calibrated from evidence.

**In scope:** Shared named capability boundary; fullscreen mobile window composition; disabled move/resize commands and affordances; touch target rules; taskbar behavior; orientation/mobile-to-desktop recovery; mobile browser journeys.

**Out of scope:** User-agent detection, device-specific forks, swipe gestures, persistent responsive state.

**Implementation steps:**
1. Establish one layout/capability boundary consumed consistently by CSS and TypeScript.
2. Derive fullscreen geometry and suppress unsupported controls/commands on mobile.
3. Preserve taskbar minimize/restore and native content actions without hover.
4. Reconcile state/geometry when crossing modes or rotating.
5. Exercise common narrow viewports and at least one physical touch device.

**Acceptance evidence (unit definition of done):** Browser journeys prove fullscreen apps, unavailable drag/resize, touch-usable controls, taskbar restore, orientation recovery, and valid desktop geometry after returning from mobile mode.

**Verification command categories:** Diagnostics; format/lint; focused capability/geometry Vitest; Playwright mobile/touch/orientation journeys; static build; no-JS narrow-viewport regression.

**Manual checks:** Physical-device touch pass; portrait/landscape rotation; zoom/text scaling; no hover dependency; focus and controls remain reachable.

**Rollback boundary:** Remove mobile capability integration and responsive window overrides, returning to the verified desktop-only interaction while semantic routes remain mobile-readable.

**Risk and review notes:** Breakpoint drift between CSS and TypeScript is the central risk. Keep one source/contract and review mode transitions, not only initial viewport. Likely reviewable under 400 lines if tokens already exist.

## Unit 10 — Experience and education completion

**User-visible outcome:** Visitors can assess 10+ years of experience, accurate employer/client relationships, progression, technologies, sectors, three vocational qualifications, and PSM I.

**Prerequisites:** Unit 2; final reviewed Spanish experience/education copy. Interaction placement may use Units 4-6 but is not required for route completion.

**In scope:** Final Experience records; chronology; employer/client attribution; progression; contextual technologies; secondary education presentation; shared route/window rendering; factual tests.

**Out of scope:** Invented outcomes, confidential systems, employer-attributed AI work, apologetic education framing.

**Implementation steps:**
1. Enter reviewed stages and validate date boundaries/client attribution.
2. Present NTT DATA as one Dec 2014-Jul 2022 stage with internal progression; Babel begins Jul 2022; NEOSISTEC remains Apr-Jun 2014.
3. Add the secondary education/certification section.
4. Verify shared content in route and desktop view without drift.

**Acceptance evidence (unit definition of done):** Rendered route/view show complete approved chronology and education; structural assertions lock critical dates and client wording; no confidential or unsupported claims appear.

**Verification command categories:** Diagnostics; format/lint; focused content/schema assertions; route/window Playwright content journey; static build/output text inspection.

**Manual checks:** Editorial/legal/privacy review; recruiter scan; compare every date and client relationship to requirements.

**Rollback boundary:** Revert Experience/education records and their presentation additions without changing shared schemas or other app content.

**Risk and review notes:** Main risk is factual wording, not code. Count editorial content as authored review load. Split chronology from education only if the combined approved copy exceeds the review budget.

## Unit 11 — Projects, case studies, and sanitized Harunna evidence

**User-visible outcome:** Projects presents Harunna Investments and `reimbursement-tracker` as credible, factual case studies with safe evidence and honest ownership.

**Prerequisites:** Unit 2; final project copy; approved Harunna evidence package with provenance/sanitization; verified reimbursement-tracker repository evidence.

**In scope:** Projects index; two case-study routes/views; problem/ownership/approach/stack/capabilities/decisions/evidence/limitations; live/repository links; private-source treatment; sanitized images/diagram.

**Out of scope:** Harunna source link/code, private client data, invented metrics/outcomes, AI Laboratory, unpublished code-to-diagram work.

**Implementation steps:**
1. Publish Harunna as client-owned with Danny's end-to-end delivery ownership, not business ownership.
2. Record AWS Amplify Gen 1, React, AppSync/GraphQL, DynamoDB, S3, Cognito, public portal, protected `/admin`, client-selected imagery, private source, and the confirmed live URL.
3. Admit only sanitized/provenance-approved screenshots and diagram after full-resolution/metadata review.
4. Publish reimbursement-tracker's verified stack/capabilities and requirements-roadmap-implementation-verification narrative, clearly retaining Danny's judgment.
5. Add outbound-link and no-private-source assertions.

**Acceptance evidence (unit definition of done):** Both studies render from canonical records; Harunna links only to <https://harunnainvestments.com/> and approved evidence, states client ownership/private source/AWS Amplify Gen 1, and contains no invented metrics; reimbursement evidence matches its public repository.

**Verification command categories:** Diagnostics; format/lint; focused case-study/schema/privacy tests; metadata scan; route/window Playwright journeys; external-link allowlist check; static build/output scan.

**Manual checks:** Client/privacy review; full-resolution evidence inspection; factual stack comparison; alt text; source maps/output search for private material.

**Rollback boundary:** Remove the two published case-study records, evidence assets, and routes/index entries as one feature while retaining generic project schema and the rest of the site.

**Risk and review notes:** Publication risk is critical and assets make the unit likely large. Prefer (11A) text-only case studies and tests, then (11B) approved evidence assets/presentation; never publish placeholder private evidence. Binary assets are separate from authored line budget.

## Unit 12 — Curated GitHub and historical archive

**User-visible outcome:** GitHub shows only approved current repositories, while My Documents contains a clearly secondary, dated historical archive.

**Prerequisites:** Unit 2; accurate `estate-hub-prototype` README completed and public before inclusion; reviewed archive links/context.

**In scope:** Curated `reimbursement-tracker` and eligible `estate-hub-prototype` metadata; outbound repository links; GitHub route/window; My Documents; `Archive 2014–2015`; CodeIgniterDAO; grouped ChiriChat/ChiriChatServer; historical disclaimer.

**Out of scope:** Runtime GitHub API, all-repository feed, `python-utilities`, treating archive work as current standards, promoting archive to primary app.

**Implementation steps:**
1. Validate local repository records against the approved allowlist and readiness status.
2. Render the curated GitHub view without runtime fetching.
3. Add My Documents as secondary navigation and group the dated archive correctly.
4. Make historical context explicit and lower its visual/editorial prominence.
5. Assert excluded repositories and runtime API requests are absent.

**Acceptance evidence (unit definition of done):** GitHub contains exactly the approved ready repositories; archive grouping/date/disclaimer are correct; no runtime GitHub request occurs; no excluded project appears.

**Verification command categories:** Diagnostics; format/lint; focused curation/schema tests; Playwright GitHub/archive/no-network journeys; static build/output allowlist scan.

**Manual checks:** Repository links and README credibility; visual hierarchy; historical wording; no implication of current-standard practice.

**Rollback boundary:** Remove curated GitHub/archive records and their desktop/route views without affecting Projects case studies or shared navigation infrastructure.

**Risk and review notes:** Block `estate-hub-prototype` rather than weaken the readiness requirement. Likely under 400 authored lines; split current GitHub from archive only if both remain complete vertical outcomes.

## Unit 13 — Spanish CV, contact, and social metadata

**User-visible outcome:** Visitors can download the approved Spanish CV, email Danny, open LinkedIn/GitHub, and share pages with accurate social metadata.

**Prerequisites:** Units 2, 4, 10-12; approved `Danny_Riofrio_CV_ES.pdf`; final custom domain for absolute canonical/social URLs; approved social images/provenance.

**In scope:** CV asset/download name; About/desktop contact actions; approved public email, LinkedIn, GitHub identity; per-route canonical/Open Graph records; local social images; PDF/image metadata sanitization.

**Out of scope:** Contact form/backend, phone number, unrelated login identity, English CV, analytics, invented social claims.

**Implementation steps:**
1. Inspect and sanitize the approved CV, preserving the exact public filename.
2. Wire native `mailto`, LinkedIn, GitHub, and CV links across shared content projections.
3. Apply final domain to canonical/Open Graph URLs and verify route ownership.
4. Add provenance-approved social assets and inspect generated tags/output.

**Acceptance evidence (unit definition of done):** `Danny_Riofrio_CV_ES.pdf` downloads correctly and contains only approved contact/location information; links resolve safely; every indexable route has factual Spanish metadata and correct absolute canonical/social URLs.

**Verification command categories:** Diagnostics; format/lint; link/metadata structural tests; PDF/image metadata privacy scan; Playwright download/contact/external-link journey; static build/output inspection.

**Manual checks:** Open PDF and inspect visible text/properties; test email and external destination affordances; social preview inspection; confirm no phone or unrelated identity.

**Rollback boundary:** Remove the CV/social assets and final contact/metadata wiring, restoring route-local placeholder metadata without disturbing completed content.

**Risk and review notes:** Block release rather than fabricate the domain, CV, or social imagery. Binary files are reviewed by content hash, provenance, metadata, and visual inspection outside authored line count.

## Unit 14 — Production hardening and preview qualification

**User-visible outcome:** A production-like preview is fast, indexable, accessible, privacy-safe, resilient without JavaScript, and complete across desktop/mobile journeys.

**Prerequisites:** Units 3-13 complete; all user-supplied publication inputs approved; Vercel preview available without production promotion.

**In scope:** SEO/sitemap/robots verification; full accessibility and keyboard pass; performance/assets; reduced motion; no-JS; route/link integrity; privacy/output scan; dependency/build hygiene; cross-browser/viewport review; production preview evidence.

**Out of scope:** New features, analytics, redesign, speculative optimization, production release.

**Implementation steps:**
1. Run the complete established diagnostic, unit, browser, and build gates.
2. Inspect generated HTML, sitemap, robots, metadata, outbound links, and static-only output.
3. Test keyboard, screen reader, contrast, 200% zoom/reflow, reduced motion, no-JS, touch, orientation, and window recovery.
4. Audit performance payloads and remove unnecessary client code/assets without changing behavior.
5. Scan source and `dist` for prohibited identifiers/private evidence and recheck all asset/PDF metadata.
6. Record preview URL, exact results, known limitations, and rollback candidate.

**Acceptance evidence (unit definition of done):** All global release-gate items below pass against one identified preview/source state; no critical accessibility/privacy/functional issue remains; any noncritical limitation is explicit and accepted before release.

**Verification command categories:** Full diagnostics; formatter/lint; complete Vitest; complete Playwright desktop/mobile/keyboard/no-JS suites; static production build; route/link/SEO checks; accessibility scanner; dependency/license/advisory checks; asset/output privacy and metadata scans; performance measurement.

**Manual checks:** Real browser/device matrix; screen reader; keyboard-only; reduced motion; zoom/reflow; social previews; 30-second audience review; full publication/privacy/legal checklist.

**Rollback boundary:** Revert only hardening corrections that regress behavior, or reject the preview entirely and retain the last complete Unit 13 state; no production traffic is involved.

**Risk and review notes:** This is an evidence unit, not a feature catch-all. Any substantive defect fix should be a bounded behavior slice with its regression test and independent rollback, preferably under 400 authored lines.

## Unit 15 — Vercel production release and rollback evidence

**User-visible outcome:** The approved static portfolio is available at the final domain with verified routes, assets, contact actions, and a tested rollback path.

**Prerequisites:** Unit 14 release gate passes; explicit production approval; final domain/DNS ownership; Vercel project access; identified previous safe deployment or documented initial-release rollback procedure.

**In scope:** Vercel Git integration/static settings; production promotion; DNS/domain attachment; post-deploy smoke checks; cache/content-update confirmation; immutable deployment identity; rollback exercise/evidence.

**Out of scope:** Application runtime, secrets, server adapter/functions, analytics, new content/features, branch/PR strategy.

**Implementation steps:**
1. Confirm Vercel builds static `dist` with no adapter, functions, or runtime secrets.
2. Promote the exact qualified preview/source state and attach the approved domain.
3. Smoke test canonical routes, sitemap/robots, assets, CV, outbound actions, desktop/mobile/no-JS behavior.
4. Record deployment/source identity and cache behavior for HTML versus fingerprinted assets.
5. Exercise or safely demonstrate rollback to the identified immutable deployment, then restore the approved release if appropriate.

**Acceptance evidence (unit definition of done):** Production URL/domain resolve; release checks match Unit 14 evidence; no server runtime/secrets exist; deployment and source identities are recorded; rollback target and observed procedure are documented.

**Verification command categories:** Vercel build/deployment status inspection; production HTTP/route smoke; static asset/header inspection; focused Playwright production smoke with no destructive actions; DNS/canonical/sitemap checks; rollback status verification.

**Manual checks:** Recruiter/client first visit; CV/contact/external links; desktop/mobile keyboard smoke; stale-cache/content correction check; Vercel dashboard confirms static deployment.

**Rollback boundary:** Promote the previously verified immutable Vercel deployment (or disable the initial custom-domain assignment if no prior release), then correct source before redeploying. Rollback does not depend on creating a new commit during the incident.

**Risk and review notes:** Operational configuration is small but high impact. Use two-person review where available for domain and production promotion. Any mismatch returns to Unit 14; do not patch production outside the source/build path.

## Required user-supplied inputs and blocking points

| Input | First blocking unit | Release effect |
| --- | --- | --- |
| Final reviewed Spanish editorial copy | Unit 2 for factual records; Units 10-12 for completion | Unit 14 cannot qualify incomplete or placeholder copy. |
| Original/licensed Windows 98-inspired asset set and provenance | Unit 3 | Unapproved assets are omitted; Unit 14/15 cannot ship them. |
| Sanitized Harunna screenshots, architecture diagram, and permissions/provenance | Unit 11 | Harunna may not publish unsafe placeholder evidence; production requires the approved package defined by requirements. |
| Accurate public `estate-hub-prototype` README | Unit 12 | The repository remains excluded until ready. |
| Approved `Danny_Riofrio_CV_ES.pdf` | Unit 13 | CV acceptance and production release are blocked. |
| Final custom domain and DNS ownership | Unit 13 for canonical/social URLs; Unit 15 for release | Absolute production metadata and domain release are blocked. |
| Explicit implementation authorization | Unit 1 | No scaffold, package, configuration, Git initialization, application code, or deployment work may begin. |
| Explicit production approval and Vercel access | Unit 15 | No production promotion occurs. |

Inputs remain inputs, not invitations to reopen confirmed scope. Missing material is blocked or omitted according to requirements; it is never invented.

## Global release gate

Production is eligible only when all items are evidenced against the same source/deployment candidate:

- [ ] All 15 work units meet their definitions of done, or an explicitly nonapplicable operational item has an approved rationale.
- [ ] A first-time visitor can identify the five positioning signals and evidence paths within 30 seconds.
- [ ] About opens by default; stable routes and essential contact/CV/evidence remain readable with JavaScript disabled.
- [ ] Desktop lifecycle, pointer, keyboard/focus, Start menu, mobile fullscreen, touch, orientation, and recovery contracts pass.
- [ ] Astro/TypeScript diagnostics, format/lint, Vitest, Playwright, structural checks, and static production build pass using Unit 1's recorded commands.
- [ ] Output is static `dist` with no server adapter, backend, runtime API, React, Tailwind, UI/animation library, or external state store.
- [ ] Spanish route metadata is unique and factual; final canonicals, Open Graph, sitemap, and robots output use the approved domain.
- [ ] Accessibility review covers semantics, names, keyboard, focus, screen reader, contrast, touch, 200% zoom/reflow, and reduced motion.
- [ ] Privacy scan finds no phone number, unrelated login identity, credentials, private Harunna source, internal client detail, or unsanitized metadata.
- [ ] Harunna is presented as client-owned, with Danny owning delivery rather than the business; private source and AWS Amplify Gen 1 are explicit.
- [ ] Experience states NTT DATA through Jul 2022 and Babel from Jul 2022 without confusing employers and clients.
- [ ] Every shipped asset/PDF has approved provenance, permission, sanitization, and accessible treatment.
- [ ] No analytics or runtime secrets exist.
- [ ] The qualified preview, production deployment identity, and independent rollback target/procedure are recorded.

## Authorization boundary

**Implementation remains unauthorized until the user explicitly approves this roadmap.** Approval to read or revise these documents is not approval to initialize Git, scaffold Astro, create package/configuration files, write application code, connect Vercel, create commits, choose a branch/PR strategy, or deploy.
