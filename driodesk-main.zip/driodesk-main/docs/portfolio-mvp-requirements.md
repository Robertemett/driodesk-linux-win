# Personal Portfolio MVP Requirements

## Decision summary

The MVP is one Spanish-first, static portfolio for recruiters and freelance clients. Within 30 seconds, it must establish **Danny Riofrio** as a Senior Software Engineer with 10+ years of experience, a deep Java/backend foundation, adaptability across TypeScript, Python, and cloud technologies, and a disciplined approach to AI-assisted delivery.

The experience will use a faithful Windows 98-inspired desktop without copying proprietary assets. Its four applications—About, Experience, Projects, and GitHub—enhance server-rendered content rather than owning it. This document consolidates confirmed product requirements; it does not authorize implementation.

## 1. Purpose and success outcome

### Purpose

Create a credible professional portfolio that helps:

- recruiters assess experience, capabilities, evidence, and fit quickly;
- freelance clients understand the problems Danny can solve and his ability to own delivery end to end;
- either audience reach the relevant evidence, CV, LinkedIn profile, or email without navigating a separate site.

### Success outcome

A first-time visitor can identify, within 30 seconds:

1. **Who:** Danny Riofrio, Senior Software Engineer with 10+ years of experience.
2. **Foundation:** proven professional depth in Java, Spring, Kafka, APIs, integration, and distributed systems.
3. **Range:** practical adaptability to TypeScript, Python, cloud, and full-stack delivery.
4. **Method:** disciplined AI-assisted engineering based on requirements, roadmaps, implementation, and verification—not unqualified automation claims.
5. **Evidence:** employment history, curated case studies, selected repositories, CV, LinkedIn, and a direct professional email.

Success is demonstrated through content clarity and the acceptance criteria in section 11, not through unverified traffic, conversion, or client-impact claims.

## 2. Confirmed audience and positioning

### Public identity

| Context | Required identity |
| --- | --- |
| Primary public name | **Danny Riofrio** |
| Professional title | **Senior Software Engineer** |
| Windows username | `driofrio91` |
| GitHub identity | `@driofrio91` |
| General location | Murcia, Spain |

### One site, two audience paths

| Audience | Questions the site must answer | Primary destinations |
| --- | --- | --- |
| Recruiters | What has Danny done, what can he do, and what evidence supports it? | Experience, About, Projects, GitHub, CV, LinkedIn |
| Freelance clients | What problems can Danny solve, can he own delivery end to end, and how can he be contacted? | Projects, About, Experience, LinkedIn, email |

The information architecture must support both paths without splitting the product into recruiter and freelance variants.

### Positioning rules

- Java, Spring, Kafka, and distributed systems are the proven professional foundation, **not the boundary** of the profile.
- TypeScript, Python, cloud, and full-stack work demonstrate adaptability; descriptions must distinguish professional depth from personal-project exposure.
- AI experience is personal engineering practice and must never be attributed to an employer.
- Current AI evidence is the completed, open-source reimbursement tracker built through requirements, roadmap, implementation, and verification, plus experimentation with Gentle AI.
- A future code-to-diagram skill is unpublished work and must not appear until it has an accessible repository, README, verifiable demo, and honest roadmap.
- Claims must remain factual, evidence-linked, and free of confidential or internal client information.

## 3. MVP information architecture and first visit

### Primary desktop

The home route presents a recognizable Windows 98-inspired desktop with:

- application icons for **About**, **Experience**, **Projects**, and **GitHub**;
- a **My Documents** icon containing the historical archive;
- a Start menu and taskbar;
- classic application windows and period-appropriate cursors;
- restrained feedback and motion that never obstruct content.

### First-visit experience

1. The page renders meaningful Spanish content before client JavaScript runs.
2. **About opens by default** on the first visit.
3. Its opening view communicates the five success signals from section 1 and exposes clear paths to Experience, Projects, CV, LinkedIn, and email.
4. Desktop chrome supports exploration but does not delay access to content.
5. Returning visits do not require persisted window state; persistence across visits is outside the MVP.

### Content hierarchy

| Level | Content |
| --- | --- |
| Primary desktop apps | About, Experience, Projects, GitHub |
| Supporting desktop item | My Documents |
| Secondary archive | `Archive 2014–2015` inside My Documents |
| Direct actions | Download CV, open LinkedIn, send email |
| No-JavaScript routes | HTML versions of About, Experience, Projects, and GitHub |

The archive must not appear as a desktop app or compete visually with current work.

## 4. Content requirements per app

All public portfolio content is Spanish-first. Source code, technical identifiers, and internal content keys remain English. The content model must allow a future `/en/` tree, but the MVP must not show an empty language selector or publish incomplete duplicated content.

### About

About must include:

- Danny's name, Senior Software Engineer title, 10+ years of experience, and Murcia, Spain;
- a concise positioning statement covering backend depth, broader adaptability, and disciplined AI-assisted delivery;
- a current GitHub avatar, stored as configurable content so a professional photo can replace it later;
- useful alt text that identifies Danny without describing decorative styling;
- grouped skills as contextual tags, never percentages, meters, rankings, or unsupported proficiency levels;
- direct LinkedIn and professional email actions;
- a downloadable general Spanish CV.

Required contact details:

- LinkedIn: <https://www.linkedin.com/in/danny-riofrio-jimenez>
- Public professional email: <dannyriofriojimenez@gmail.com>

No contact form, contact backend, reference-site login, credential flow, or unrelated email address is permitted.

#### Skills groups

1. Backend and APIs
2. Architecture and integration
3. Messaging and data
4. Testing and delivery
5. Cloud and full-stack
6. AI-assisted engineering

Each skill or group must indicate context such as professional foundation, professional use, or personal-project exposure where needed to prevent inflated interpretations.

#### CV

The public file must be named `Danny_Riofrio_CV_ES.pdf` and must:

- position Danny as a Senior Software Engineer;
- include only the public professional email, LinkedIn, GitHub, and Murcia, Spain as contact/location details;
- omit a phone number;
- be a general Spanish CV rather than the supplied job-specific English/backend CV.

The supplied CV is source material only. An English CV is deferred.

### Experience

Experience must present 10+ years across banking, international ecommerce, and the public sector while accurately separating employers from their clients.

| Period | Employment stage | Required presentation |
| --- | --- | --- |
| Jul 2022–present | Babel | Use wording such as **“Babel — project for ING”**; do not imply direct ING employment. |
| Dec 2014–Jul 2022 | NTT DATA | Present as one stage with internal progression and representative work for Inditex, Telefónica, Santander, and public administrations. Use wording such as **“NTT DATA — client Inditex”** where relevant. |
| Apr–Jun 2014 | NEOSISTEC | Present as a brief first professional role without overstating its scope. |

Responsibilities and technologies must be described at a useful professional level without confidential systems, internal names, proprietary data, or unverifiable business results.

Education is secondary to experience and must list all three vocational qualifications plus PSM I. It must not apologize for or foreground the absence of a university degree.

### Projects

Projects contains editorial case studies, not an automated repository feed. The MVP includes:

1. **Harunna Investments** as the principal client case study.
2. **reimbursement-tracker** as the open-source AI-assisted product case study.

Each entry must emphasize the problem, Danny's ownership, architecture and decisions, delivered capabilities, evidence, and honest constraints. Requirements are detailed in section 5.

### GitHub

GitHub is separate from Projects and uses manually curated local metadata and outbound repository links. The MVP includes only:

- `reimbursement-tracker`;
- `estate-hub-prototype`, after its generic starter README is replaced with an accurate project README.

There must be no runtime GitHub API or automatic all-repository synchronization. `python-utilities` remains excluded until it is substantial and documented.

### My Documents and historical archive

My Documents contains a secondary `Archive 2014–2015` folder. It groups:

- CodeIgniterDAO; and
- ChiriChat with ChiriChatServer as one historical project.

The archive must be clearly dated and labeled as meaningful evidence of Danny's evolution, while explicitly stating that it is not representative of current engineering standards. Its visual and editorial prominence must remain below current case studies and repositories.

## 5. Case-study requirements

### Harunna Investments

#### Required narrative

Harunna Investments is a deployed real-estate portal owned and controlled by the client. It operates independently of third-party marketplaces, preserving the client's control over listings, brand, and data. Do not invent revenue, traffic, conversion, operational savings, or other client metrics.

#### Ownership and implementation facts

- Danny held end-to-end responsibility for architecture, frontend, design, data model, security, and deployment; this delivery ownership does not imply business ownership of the product.
- The client selected the imagery.
- The product includes a public property search/listing portal and a Cognito-protected `/admin` back office.
- The stack is **AWS Amplify Gen 1**, React, AppSync/GraphQL, DynamoDB, S3, and Cognito.
- The repository and source are private and must never be linked, embedded, or exposed.

#### Permitted evidence

- confirmed live product: <https://harunnainvestments.com/>;
- sanitized screenshots;
- an architecture diagram;
- selected technical decisions and tradeoffs;
- a clear ownership statement;
- factual product outcomes listed above.

Screenshots should use synthetic or tightly cropped data. If blur is unavoidable, the final asset must be checked at full resolution for readable remnants and stripped of sensitive metadata before publication.

### reimbursement-tracker

#### Required narrative

`reimbursement-tracker` is a completed, open-source, AI-assisted product replacing an Excel-based reimbursement workflow. It demonstrates how Danny turns requirements and a roadmap into an implemented and verified product. The case study must distinguish AI assistance from Danny's engineering judgment and ownership.

#### Verified scope to present

- Next.js 15, React 19, TypeScript, Server Actions, Prisma, and PostgreSQL;
- hexagonal/clean architecture;
- role-based behavior;
- rate limiting and progressive lockout;
- security headers;
- CSV export;
- mobile-first experience.

Evidence should link to the repository and explain the requirements, roadmap, implementation, and verification workflow. It must not claim employer adoption or capabilities beyond the documented product.

### Excluded AI Laboratory

No AI Laboratory app, section, teaser, or empty placeholder belongs in the MVP. It may be reconsidered only when the code-to-diagram skill has an accessible repository, useful README, verifiable demo, and honest roadmap.

## 6. Windows 98 interaction requirements

### Visual system and assets

- The interface must faithfully evoke a Windows 98 desktop through layout, classic windows, icons, Start menu, taskbar, cursors, typography, borders, and restrained feedback.
- Archivos Eladio is inspiration only. No login, credentials, scraping, or dependency on that site is required.
- Do not copy assets from Archivos Eladio or proprietary Microsoft assets.
- Every shipped asset must be original, appropriately licensed, or otherwise documented as legally usable.
- Visual fidelity must not override readability, semantics, accessibility, or touch usability.

### Desktop window behavior

Each app has exactly one instance. The window manager must support:

- open a closed app;
- focus an open app and bring it to the foreground;
- close an app;
- minimize to the taskbar and restore from it;
- maximize and restore;
- drag windows within viewport bounds;
- manually resize windows within viewport bounds;
- maintain a clear active-window state.

Windows must remain recoverable: title bars and essential controls cannot become permanently unreachable outside the viewport.

### Mobile behavior

- Preserve a recognizable desktop, icons, and taskbar.
- Open apps fullscreen.
- Disable dragging and manual resizing.
- Preserve minimize and restore behavior.
- Size controls and interaction regions for reliable touch use without requiring hover.
- Keep essential content and actions usable at supported narrow viewports and after orientation changes.

### Keyboard, menus, and focus

- `Tab` and `Shift+Tab` traverse interactive elements in a logical, visible order.
- `Enter` activates focused desktop icons, taskbar items, menu items, links, and window controls where appropriate.
- Arrow keys navigate Start menu items and nested menu choices.
- `Escape` closes the active menu or transient layer first; it must not unexpectedly close content windows.
- Opening an app places focus at its window or first meaningful heading/control.
- Focusing or restoring a window moves keyboard focus into that window predictably.
- Closing or minimizing a window restores focus to the control that opened or last represented it when that control remains available.
- Maximizing, restoring, dragging, and resizing must not lose keyboard focus or make focused content unreachable.
- Focus order must follow user intent and active-layer order, not visual coordinates or arbitrary DOM order.

## 7. Progressive enhancement, SEO, accessibility, privacy, and security

### Progressive enhancement

- Essential portfolio content must be server-rendered, indexable, and readable without JavaScript.
- A retro-styled no-JavaScript fallback must provide direct links to HTML versions of About, Experience, Projects, and GitHub.
- Core contact links, CV download, experience, skills, and project evidence must not depend on window-manager JavaScript.
- Client TypeScript enhances window behavior; it does not fetch or own canonical content.

### SEO

- Each indexable content route must have a unique Spanish title and description.
- Pages must use semantic heading structure, canonical URLs once the domain is chosen, Open Graph metadata, and appropriate crawl directives.
- Person, experience, and project copy must remain present in rendered HTML.
- Decorative desktop chrome must not obscure the site's topic from crawlers or assistive technology.

### Accessibility and responsive quality

- Use semantic HTML and native controls before custom roles.
- Provide useful accessible names for icons, controls, links, windows, and profile imagery.
- Maintain visible keyboard focus and sufficient color contrast.
- Do not rely on color, sound, hover, or motion alone to convey state.
- Respect `prefers-reduced-motion`; nonessential movement must be removable without loss of information.
- Support keyboard-only and screen-reader navigation through the content, window controls, taskbar, and menus.
- Avoid keyboard traps and preserve readable zoom/reflow behavior.
- Optimize static assets and load only the client JavaScript required for interaction.

### Privacy and security

- Publish only the approved professional email, LinkedIn, GitHub identity, general location, and sanitized project evidence.
- Do not publish a phone number, credentials, private source, internal client details, or unrelated personal identifiers.
- Strip sensitive metadata from published images and documents.
- External links must use safe browser behavior and clearly identify their destinations.
- The static MVP must not collect form submissions or introduce a backend, authentication flow, analytics requirement, or runtime external API.

## 8. Content and data ownership

All canonical portfolio content is repository-owned, manually reviewed, and available at build time. External services are destinations or evidence—not runtime content authorities.

### Requirement-level content entities

| Entity | Required fields or relationships |
| --- | --- |
| Site profile | public name, title, summary, location, configurable avatar, avatar alt text, approved contact links, CV reference |
| Navigation app | stable identifier, Spanish label, icon reference, route/fallback link, default window state, display order |
| Experience stage | employer, start/end dates, progression, responsibilities, technologies, client attribution, sector context |
| Education item | qualification/certification name, institution or issuer, completion context/order |
| Skill group | group name, contextual description, tags, exposure context |
| Case study | title, status, problem, ownership, approach, stack, capabilities, decisions, evidence, limitations, links, source visibility |
| Curated repository | name, concise description, technologies, repository URL, curation status/order |
| Archive group | date range, historical label, context statement, grouped projects, links if suitable |
| Asset record | local reference, purpose, alt text when informative, origin, license/permission status, sanitization status |
| SEO record | route, locale, title, description, canonical reference, social image reference |

### Ownership rules

- Astro Content Collections must validate structured editorial content at build time.
- Spanish is the only published locale in the MVP; schemas must permit later localized entries without requiring duplicates now.
- Projects and GitHub repositories remain different entity types and editorial surfaces.
- Manual curation controls ordering, inclusion, descriptions, and outbound links.
- Private-source status and evidence restrictions are explicit case-study fields, not assumptions in presentation code.
- Asset provenance, license status, and sanitization must be reviewable before publication.

## 9. Confirmed technology baseline and rationale

| Decision | Requirement | Rationale |
| --- | --- | --- |
| Framework | Static Astro | Server-rendered content and selective enhancement suit a content-led portfolio. |
| Language | Strict TypeScript | Makes interactive state contracts explicit and catches integration errors early. |
| Content | Astro Content Collections | Keeps editorial data local, typed, and build-validated. |
| Styling | Hand-authored CSS | Provides precise retro styling without a utility framework or component dependency. |
| Client behavior | Minimal native TypeScript | Supports the window manager without shipping a frontend framework or external state store. |
| Output | Static `astro build` to `dist` | No server runtime or Astro server adapter is needed for the MVP. |
| Hosting | Vercel with Git integration | Supports static hosting, preview deployments, and a future custom domain. |

React and Tailwind may appear in case-study descriptions because existing projects use them; they are not portfolio implementation dependencies.

### Planned quality tooling

After implementation begins, the project should use:

- Astro check for Astro and TypeScript diagnostics;
- ESLint and Prettier for code and formatting consistency;
- Vitest for deterministic window-manager and state logic;
- Playwright for critical desktop, mobile, keyboard, focus, and no-JavaScript journeys.

Tool configuration and package selection belong to the later architecture/construction phase, not this requirements task.

## 10. Explicit non-goals

The MVP does **not** include:

- a backend, server adapter, contact form, or credential handling;
- runtime external APIs, including the GitHub API;
- automatic GitHub synchronization or an all-repository feed;
- React, Tailwind, UI component libraries, or external state stores in the portfolio;
- multiple instances of the same app;
- persisted desktop/window state across visits;
- an AI Laboratory or code-to-diagram placeholder;
- an English site or English CV;
- public access or links to Harunna source code;
- inclusion of `python-utilities` before it becomes substantial and documented;
- invented project capabilities, client metrics, traffic claims, or unpublished work;
- copied Archivos Eladio or proprietary Microsoft assets.

## 11. Acceptance criteria

### Outcome and content

- [ ] A first-visit review can identify Danny's name, senior title, 10+ years, backend foundation, broader adaptability, AI-assisted method, and evidence paths within 30 seconds.
- [ ] About opens by default and provides direct access to Experience, Projects, CV, LinkedIn, and the approved professional email.
- [ ] Public UI and portfolio content are complete in Spanish; no empty language selector or incomplete `/en/` content is visible.
- [ ] The CV downloads as `Danny_Riofrio_CV_ES.pdf`, is general and Spanish, and contains no phone number.
- [ ] Experience shows Babel from Jul 2022–present, NTT DATA as one Dec 2014–Jul 2022 stage, and NEOSISTEC from Apr–Jun 2014.
- [ ] Employer/client wording does not imply employment by ING, Inditex, Telefónica, Santander, or public administrations.
- [ ] All three vocational qualifications and PSM I appear in a secondary education section without apologetic framing.
- [ ] Skills use contextual grouped tags and no proficiency percentages.

### Projects, repositories, and evidence

- [ ] Projects presents Harunna Investments and reimbursement-tracker as separate editorial case studies.
- [ ] Harunna is labeled as AWS Amplify Gen 1 and private-source; no source link or private material is exposed.
- [ ] Harunna evidence is sanitized and its imagery is attributed to client selection.
- [ ] reimbursement-tracker presents the documented stack, capabilities, open-source link, and requirements/roadmap/verification workflow without employer attribution.
- [ ] GitHub contains only reimbursement-tracker and the README-ready estate-hub-prototype using manually maintained metadata.
- [ ] No runtime GitHub API request occurs.
- [ ] The `Archive 2014–2015` folder is inside My Documents, combines ChiriChat with ChiriChatServer, and labels all archive work as historical rather than current-standard work.
- [ ] No AI Laboratory, code-to-diagram placeholder, or `python-utilities` entry appears.

### Interaction and responsive behavior

- [ ] Each app can have no more than one instance and supports open, focus, close, taskbar minimize/restore, and maximize/restore.
- [ ] At desktop sizes, every window can be dragged and manually resized without leaving essential controls irretrievably outside viewport bounds.
- [ ] At mobile sizes, apps open fullscreen, drag/resize is unavailable, and taskbar minimize/restore remains touch-usable.
- [ ] Tab, Shift+Tab, Enter, menu arrow keys, and Escape follow the behaviors in section 6.
- [ ] Automated or manual journey checks confirm focus placement on open/restore and focus restoration on close/minimize.
- [ ] Reduced-motion mode removes nonessential motion without removing information or controls.

### Rendering, quality, and safety

- [ ] With JavaScript disabled, rendered HTML still exposes readable About, Experience, Projects, and GitHub pages plus contact and CV links.
- [ ] Each indexable route has a unique Spanish title, description, semantic heading structure, and rendered canonical content.
- [ ] Keyboard-only review finds no trap and always shows the active focus indicator.
- [ ] Informative images have useful alt text; decorative assets are hidden appropriately from assistive technology.
- [ ] Published assets have recorded provenance/permission and pass sensitive-data and metadata review.
- [ ] The built portfolio uses static Astro output in `dist` with no Astro server adapter, backend, runtime external content API, React, Tailwind, UI library, or external state store.
- [ ] Astro check, lint/format checks, deterministic state tests, and critical Playwright journeys pass once their planned configurations exist.

## 12. Open decisions and required inputs

Only these inputs remain open; confirmed choices elsewhere in this document must not be reopened during construction without a new product decision.

| Input | Why it is required | Completion evidence |
| --- | --- | --- |
| Final custom domain | Needed for canonical URLs, production links, and social metadata. | Confirmed domain and DNS ownership. |
| Final Spanish CV asset | Current supplied English/backend CV is source material, not publishable output. | Approved `Danny_Riofrio_CV_ES.pdf` meeting section 4. |
| Harunna evidence package | Publication requires safe, credible visual evidence beyond the confirmed live product. | Sanitized screenshots, architecture diagram, and asset permissions/provenance. |
| estate-hub-prototype README | The generic starter README is not credible portfolio evidence. | Repository README accurately explains purpose, scope, setup, stack, status, and limitations. |
| Windows 98-inspired asset set | Visual fidelity requires lawful, consistent assets. | Original or licensed icons, cursors, fonts/suitable alternatives, provenance, and usage permissions. |
| Final Spanish editorial copy | The requirements define facts and structure, not publish-ready prose. | Reviewed profile, experience, education, skills, and case-study copy with confidential details removed. |

## 13. Next step: architecture and construction roadmap

No implementation is authorized by this document. The next activity is to produce an architecture and construction roadmap that:

1. maps the server-rendered route and content model;
2. defines window-manager state, focus, keyboard, viewport, and mobile contracts;
3. defines asset provenance and evidence-sanitization gates;
4. sequences content preparation before interaction polish;
5. specifies the planned diagnostic, unit, and end-to-end verification gates;
6. divides construction into reviewable increments while preserving the static Astro baseline.

Implementation, package files, repository scaffolding, and application code begin only after that roadmap is reviewed.
