# Portfolio MVP Technical Architecture

## Architecture summary

The MVP is a statically generated Astro site deployed from GitHub to Vercel. Semantic Spanish content is rendered at build time into stable routes; `/` adds a progressively enhanced Windows 98-inspired desktop over the same typed, repository-owned content. A framework-free TypeScript state core governs desktop interactions, a DOM controller applies those decisions, and hand-authored CSS provides the visual system. There is no runtime backend, API, authentication, analytics, or content service.

The architecture protects three things above visual novelty: factual content, access without JavaScript, and recoverable keyboard/touch interaction. Desktop chrome is an enhancement and must never become the only route to evidence or contact actions.

## Decision table

| Area | Decision | Main consequence |
| --- | --- | --- |
| Rendering | Astro static output to `dist` | All public content exists as build-time HTML; no server adapter or runtime application tier. |
| Information access | Stable routes plus an enhanced `/` desktop | Search engines, assistive technology, no-JavaScript users, and desktop-window users reach the same reviewed content. |
| Content | Local typed Astro Content Collections and local assets | Editorial facts are versioned, validated at build time, and never fetched from runtime APIs. |
| Interaction | Pure framework-free TypeScript state core plus DOM adapter/controller | Window behavior is deterministic and unit-testable without React or an external store. |
| Styling | Hand-authored layered CSS with Windows 98-inspired tokens and primitives | Fidelity remains controllable without Tailwind or a UI library. |
| Responsive policy | Desktop windows where supported; fullscreen apps on mobile | Mobile has no drag or manual resize, while minimize/restore remains available. |
| Hosting | Vercel Git integration | Pull-request previews, atomic static releases, and platform rollback are available without runtime secrets. |
| Locale | Spanish only, with a future `/en/` model boundary | No empty selector or incomplete translation ships in the MVP. |

## 1. Goals and boundaries

### Goals

- Establish Danny Riofrio as a Senior Software Engineer with 10+ years of experience within 30 seconds.
- Present Java, Spring, Kafka, APIs, integration, and distributed systems as the professional foundation while showing factual TypeScript, Python, cloud, full-stack, and AI-assisted engineering range.
- Serve recruiters and freelance clients through one information architecture.
- Make About, Experience, Projects, GitHub, CV, LinkedIn, and email evidence immediately reachable.
- Deliver a faithful but original Windows 98-inspired experience that remains readable, accessible, responsive, and legally usable.
- Keep content factual, manually reviewed, build-validated, and safe to publish.

### Constraints and quality attributes

| Attribute | Architectural response |
| --- | --- |
| Progressive enhancement | Server-rendered documents and native links precede client behavior. |
| Accessibility | Semantic pages are primary; custom desktop behavior adds focused keyboard and screen-reader contracts. |
| Reliability | Pure state transitions, explicit invariants, bounded geometry, and failure-safe DOM enhancement. |
| Performance | Static HTML, local optimized assets, minimal page-specific TypeScript, and no frontend framework. |
| Maintainability | One content authority, cohesive modules, typed records, and behavior tests beside each work unit. |
| Privacy/security | No runtime data collection or secrets; publication gates cover private evidence and metadata. |
| SEO | Stable Spanish routes, unique metadata, rendered content, sitemap, robots policy, and later canonical domain. |
| Reviewability | Construction proceeds in vertically demonstrable units with a default 400 authored changed-line review budget. |

### Non-goals

The MVP does not introduce a backend, server adapter, contact form, credentials, authentication, analytics, runtime GitHub API, automated repository feed, content management service, React, Tailwind, UI or animation libraries, external state store, persisted window state, multiple app instances, English content, an AI Laboratory, unpublished work, or public Harunna source. It does not copy assets from Archivos Eladio or Microsoft.

## 2. System context and deployment

```text
Author/editor
  -> local repository content and assets
  -> GitHub repository
  -> Vercel build pipeline: install -> validate/test -> astro build
  -> immutable static dist deployment
  -> visitor browser

Visitor browser -- outbound navigation only --> LinkedIn
                -- outbound navigation only --> GitHub repositories/profile
                -- outbound navigation only --> Harunna live site
                -- mailto action ------------> email client
```

- **Browser:** receives HTML, CSS, local assets, and narrowly scoped enhancement scripts. Essential reading and navigation work without scripts.
- **GitHub repository:** source of truth for code, content, provenance records, and publication-safe assets.
- **Vercel:** builds previews and production static output. It does not host an application runtime for this MVP.
- **External sites:** destinations only. Their availability cannot prevent local content from rendering.
- **Trust boundary:** anything committed to public output is assumed discoverable. Private Harunna source, credentials, internal client detail, and unsanitized evidence never enter the publishable tree.

## 3. Rendering and route strategy

### Static route map

| Route | Purpose | Indexing intent |
| --- | --- | --- |
| `/` | Unique landing summary and enhanced Windows 98 desktop; About is initially open | Indexable, self-canonical after domain selection |
| `/about/` | Full About, skills, contact, and CV access | Indexable, self-canonical |
| `/experience/` | Employment, progression, and secondary education | Indexable, self-canonical |
| `/projects/` | Case-study index | Indexable, self-canonical |
| `/projects/harunna-investments/` | Harunna case study | Indexable, self-canonical |
| `/projects/reimbursement-tracker/` | Reimbursement tracker case study | Indexable, self-canonical |
| `/github/` | Curated repository presentation | Indexable, self-canonical |

My Documents and `Archive 2014–2015` are secondary desktop content. They may use a stable readable route if implementation evidence shows it improves no-JavaScript or direct-link access; they must not become primary desktop apps or compete with current work. That route choice does not change archive content authority.

### Shared content and render ownership

Content records are the authority. Route pages and desktop app views both receive normalized, typed view data derived from those records. Astro presentation components may be shared where their semantics remain valid in both contexts; desktop chrome wraps views but does not duplicate facts in script constants or separate copy files.

`/` renders a unique landing summary plus meaningful About content before enhancement. Stable routes are the authoritative full-topic destinations and permanent links. Every desktop app exposes its corresponding route as a normal link, including in a `<noscript>` navigation block. The desktop remains useful if JavaScript never runs.

### Canonical and duplicate-content policy

- Every stable content route owns its unique Spanish title, description, heading, and self-referencing canonical URL after the domain is known.
- `/` is a distinct landing/desktop document and self-canonical; it is not declared a duplicate of one app route.
- Shared facts may appear in summary form on `/`, but full editorial narratives belong to their stable routes. Desktop windows reuse content projections rather than maintaining alternate editorial copy.
- Canonical tags apply to documents, not individual window fragments. They are not used to disguise uncontrolled duplication.
- Sitemap entries include indexable routes only. Query strings or future client-only window state must not produce indexable route variants.

### Future English boundary

Locale is an explicit field in content and metadata normalization, with Spanish as the only accepted published value for the MVP. Route builders and link helpers must not hard-code assumptions that prevent a later `/en/` tree. English publication later requires complete translated records, metadata, navigation, and hreflang/canonical review as one feature; the MVP emits neither `/en/` nor a locale selector.

## 4. Content architecture

### Collection configuration

`src/content.config.ts` will declare typed collections using the current Astro Content Collections configuration and loader concepts available when Unit 1 establishes dependencies. Local file/glob loaders are preferred; exact package versions and unverified APIs are intentionally not pinned here. Schemas reject incomplete, unsupported, or unsafe publication states during the build.

### Content domains

| Domain | Responsibility and relationships |
| --- | --- |
| Site profile | Singleton public identity, title, summary, Murcia location, configurable avatar/alt text, approved email, LinkedIn, GitHub identity, and CV reference. |
| Navigation apps | Stable app identifiers, Spanish labels, lawful icon references, fallback routes, initial state, and display order. References route ownership; does not store runtime window state. |
| Experience | Chronological stages, progression, responsibilities, technology context, sectors, and explicit employer/client attribution. NTT DATA ends Jul 2022; Babel starts Jul 2022. |
| Education | Three vocational qualifications and PSM I, presented as a secondary ordered section. |
| Skill groups | Six required groups, contextual descriptions, tags, and exposure context; no percentages or rankings. |
| Case studies | Editorial problem, ownership, approach, stack, capabilities, decisions, evidence, limitations, links, and source visibility. Harunna records client ownership, Danny's delivery ownership, private source, and AWS Amplify Gen 1. |
| Curated repositories | Manual inclusion/order and outbound links for `reimbursement-tracker` and eligible `estate-hub-prototype`; separate from case studies. |
| Historical archive | Dated `Archive 2014–2015`, context disclaimer, CodeIgniterDAO, and grouped ChiriChat/ChiriChatServer. |
| SEO | Per-route Spanish title, description, locale, route key, canonical path, social image, and crawl intent. |
| Asset provenance | Local asset reference, purpose, informative alt text where applicable, origin, creator/license or permission, sanitization status, and approval state. |

Cross-record identifiers should be stable English technical keys. References connect navigation to routes, case studies to approved evidence, profile to CV/avatar, and SEO to route keys. Build validation must catch missing references, duplicate route ownership, disallowed publication status, and malformed approved links.

### Content is not interaction state

Content describes durable editorial facts. Window openness, focus, minimization, z-order, rectangles, current viewport, menu state, and focus-return targets are ephemeral UI state held in memory by the enhancement layer. Content files must never be rewritten from browser interaction, and runtime state must never decide whether factual HTML exists.

## 5. Component and module boundaries

### Proposed source tree

```text
src/
  content.config.ts
  content/
    site/
    experience/
    education/
    skills/
    case-studies/
    repositories/
    archive/
    seo/
    assets/
  lib/
    content/              # load, validate relationships, normalize view data
    routes/               # stable route and locale-aware link helpers
  layouts/
    BaseLayout.astro
    ContentLayout.astro
    DesktopLayout.astro
  pages/
    index.astro
    about.astro
    experience.astro
    projects/
      index.astro
      [slug].astro
    github.astro
  components/
    desktop/
      DesktopShell.astro
      DesktopIcons.astro
      AppWindow.astro
      Taskbar.astro
      StartMenu.astro
      MyDocuments.astro
    apps/
      AboutView.astro
      ExperienceView.astro
      ProjectsView.astro
      GitHubView.astro
      ArchiveView.astro
    content/              # cohesive reusable editorial structures only
    seo/
  scripts/
    enhancement.ts
    window-manager/
      model.ts
      reducer.ts
      geometry.ts
      focus-policy.ts
      controller.ts
      dom-adapter.ts
      capability-policy.ts
  styles/
    tokens.css
    reset.css
    base.css
    primitives.css
    desktop.css
    content.css
    responsive.css
    utilities.css
  tests/
    unit/window-manager/
    e2e/
public/
  assets/
    icons/
    cursors/
    images/
    social/
  documents/
    Danny_Riofrio_CV_ES.pdf
```

Astro components render documents and views. Native TypeScript modules own interaction state and DOM coordination; they do not render or fetch editorial content. CSS primitives may cover classic buttons, inset/outset panels, title bars, menus, and focus rings. Decorative one-off pixels, separators, and icon details should remain CSS/pseudo-elements or local markup rather than becoming components with no behavioral or semantic responsibility.

## 6. Window manager architecture

### Core/adaptor split

1. **State core:** pure data and deterministic command reduction. It has no DOM, timing, storage, or viewport API dependencies.
2. **Geometry policy:** pure clamping, resizing, maximize/restore, and viewport-recovery calculations.
3. **Focus policy:** pure decisions about intended focus destination and return target identifiers.
4. **Capability policy:** maps the architecture-owned responsive mode to allowed commands.
5. **Controller:** translates pointer, keyboard, taskbar, menu, and control intent into commands; coordinates effects.
6. **DOM adapter:** discovers enhanced elements, applies state through attributes/styles, manages pointer capture and actual focus, and reports recoverable failures.

### State model

There is exactly one record per app identifier and one visual instance per app.

| State area | Required data |
| --- | --- |
| Lifecycle | `closed`, `open`, `minimized`; maximized is an open display mode, and restored means open/non-maximized. |
| Activation | active window identifier or `null`, monotonically ordered z-order without unbounded growth. |
| Geometry | current rectangle, restore rectangle, minimum size, current viewport constraints. |
| Display mode | normal or maximized; mobile fullscreen is derived from capability mode rather than persisted as desktop geometry. |
| Focus intent | preferred entry target and return-target identifier supplied by the invoking control. |
| Transient UI | Start menu open/closed state and active menu item belong to controller state, separate from app content. |

Commands include open, focus, close, minimize, restore-from-taskbar, maximize, restore-size, move, resize, viewport-changed, capability-changed, and menu operations. Domain events/effects describe state changed, active window changed, focus requested, focus return requested, pointer interaction started/ended, and recovery applied. DOM events are translated at the boundary rather than becoming domain events directly.

### Transition contracts

- Opening a closed app opens and activates its existing instance; opening an open app focuses it; opening a minimized app restores and focuses it.
- Focusing raises an open, non-minimized window and makes it the sole active window.
- Minimizing removes the app from active stacking, preserves recoverable geometry, selects the next eligible active window if one exists, and requests focus return to its taskbar/invoker control.
- Closing clears ephemeral app geometry to its configured initial value for a later open and restores focus to an available invoking or representing control.
- Maximizing captures the normal rectangle once, uses the available desktop area, and retains keyboard focus.
- Restoring from maximized uses a viewport-clamped restore rectangle; restoring from minimized preserves the prior display mode.
- Unsupported commands are deterministic no-ops with no partial DOM mutation.

### Invariants

1. No app has more than one state record or rendered window instance.
2. At most one eligible visible window is active.
3. Closed or minimized windows are never active and do not participate in visible z-order.
4. Visible z-order values are unique and normalized when needed.
5. A normal desktop window keeps a reachable title-bar/control region and respects minimum usable dimensions.
6. Maximized/fullscreen geometry is derived from the current available viewport, not stale stored pixels.
7. A restore rectangle exists only as a valid normal-mode target and is clamped before use.
8. State transitions do not depend on animation completion.
9. No state survives navigation or a new visit.

### Drag and resize

The controller uses Pointer Events and pointer capture from an eligible title bar or resize handle. Only the initiating pointer controls the gesture; additional contacts are ignored. Movement is clamped through pure geometry functions before DOM application. Release, cancellation, lost capture, capability change, and visibility interruption all terminate the gesture safely. Momentum, inertia, spring physics, and decorative drag lag are unnecessary and excluded.

### Focus and keyboard contracts

- Every app has a stable focus entry strategy: window heading/container first, otherwise the first meaningful control.
- Open, focus, and taskbar restore request focus inside the active window after state is applied.
- Close/minimize return focus to the last valid invoker or taskbar/desktop representation; missing targets fall back to a stable desktop navigation control.
- Move, resize, maximize, and restore-size do not relocate focus.
- Escape dismisses the top transient menu/layer and never closes a content window unexpectedly.
- Focus order follows semantic DOM and active-layer intent, not z-coordinate sorting.

### Desktop/mobile capability policy

CSS and TypeScript consume one shared named breakpoint/capability definition established in Unit 1 and calibrated during responsive implementation. CSS owns layout presentation; `capability-policy.ts` owns which window commands are valid. Desktop permits bounded drag and resize. Mobile renders open apps fullscreen, disables move/manual resize, and retains taskbar minimize/restore. Input type alone does not define mobile: viewport/layout capability is authoritative, with hover/pointer media features used only to refine affordances.

Resize and orientation changes dispatch viewport/capability updates. Visible windows are recalculated immediately: maximized/mobile windows fit the available area; normal desktop windows are clamped so essential controls remain reachable. A mobile-to-desktop transition restores a valid clamped normal rectangle, never stale off-screen geometry.

### Failure-safe behavior

Enhancement initializes only after validating required root hooks and unique app identifiers. A malformed app can remain a semantic linked content block while its controls stay unenhanced. Reducer errors must not leave half-applied state; the controller computes next state before applying DOM effects. Lost elements, focus failures, and pointer cancellation fall back to native links, visible content, and normalized state. The system does not hide essential content merely because initialization failed.

## 7. Progressive enhancement lifecycle

1. Astro emits semantic content, native links, contact actions, and a `<noscript>` route directory.
2. CSS provides a readable retro presentation without requiring behavioral classes.
3. A small module script locates the desktop root, validates hooks, constructs initial state with About open, and marks enhancement availability.
4. The controller binds behavior through stable data attributes and event delegation where appropriate.
5. State-derived attributes/styles are applied; editorial HTML is not regenerated.

Before initialization, controls that require JavaScript are not presented as functional substitutes for links. Desktop icons and content calls-to-action retain real `href` destinations; enhancement may intercept only when it can complete the corresponding action. If JavaScript fails during or after initialization, route links remain navigable, rendered content remains in the document, and no loading overlay or hidden shell blocks access.

## 8. CSS and visual architecture

### Tokens and layers

- **Tokens:** palette, text colors, focus colors, spacing, border widths, shadows, typography fallbacks, taskbar/title-bar dimensions, control hit-area minimums, z-index bands, and motion durations.
- **Primitives:** outset/inset surfaces, classic button, title bar, menu panel/item, icon tile, taskbar item, window frame, and selection/focus treatment.
- **Composition:** desktop, windows, Start menu, app content, archive, and route layouts.
- **Responsive/utility:** capability-specific rules, visually hidden text, readable measures, and explicit print/download behavior if needed.

CSS layer order should make reset/tokens/base/primitives/compositions/utilities predictable. Z-index bands distinguish desktop icons, windows, taskbar, and transient menu; per-window ordering is applied only inside the window band.

### Fidelity, motion, and responsive rules

- Recreate the visual language with original or licensed assets and documented system-font alternatives, not copied Microsoft or Archivos Eladio files.
- Preserve readable text sizes, contrast, visible focus, and sufficient touch targets even where literal period fidelity would fail modern use.
- Frequent window, menu, taskbar, and keyboard actions are instant or nearly instant and never wait for animation.
- Motion is limited to brief feedback that explains state; no decorative sequence blocks input, delays content, or adds drag momentum.
- Animate only appropriate compositor-friendly properties when motion is justified; do not use `transition: all`.
- `prefers-reduced-motion: reduce` removes positional/decorative motion while preserving immediate state changes and useful color/focus feedback.
- Hover-only styling is gated by hover/pointer capability and never carries unique information.

### Asset gate

Every shipped icon, cursor, font, image, diagram, screenshot, PDF, and social image must have a provenance record and approval state. Informative assets require useful Spanish alt text; decorative assets are explicitly decorative. Sanitization includes full-resolution content review and metadata removal. Generated assets require recorded generation source/tool terms and a legal-use decision; generation does not itself prove ownership or permission.

## 9. Accessibility architecture

- Stable routes use ordinary document landmarks, headings, lists, links, buttons, and sections as the primary accessibility model.
- Desktop app content remains document content. Do not assign `dialog` semantics to every window merely because it looks like a desktop window; modal semantics are reserved for genuinely modal behavior, which the MVP does not require.
- Window controls are native buttons with explicit accessible names. Desktop icons and taskbar representations use native links/buttons according to their actual fallback and enhanced action.
- The Start menu receives menu roles and arrow-key behavior only if implementation can satisfy the complete composite-widget contract; otherwise it uses a simpler disclosure/navigation pattern with native controls. Visual imitation is not sufficient reason to add ARIA.
- Active/minimized/maximized state is exposed through names, states, or concise status messaging where native semantics cannot communicate it. Avoid noisy announcements for pointer movement.
- Focus is always visible, logical, and restored under the contracts in section 6. Background windows remain readable/navigable according to document order unless a true transient layer requires temporary focus management.
- Informative imagery has meaningful alt text; decorative chrome is hidden from assistive technology.
- Touch controls use reliable target sizes and spacing without hover dependence.
- At supported zoom and narrow widths, text reflows, controls remain reachable, and horizontal scrolling is limited to content that intrinsically requires it.

## 10. SEO and metadata architecture

`BaseLayout.astro` owns common document language (`es`), baseline metadata, safe defaults, robots references, and shared social tags. Each page owns its route-specific Spanish title, description, heading, canonical path, and factual social presentation through a typed SEO record.

- Absolute canonical and Open Graph URLs activate only after the final custom domain is supplied.
- A generated sitemap includes indexable stable routes; `robots.txt` references it and does not attempt to secure private material.
- Open Graph images are local, optimized, provenance-approved, and free of private evidence.
- Structured data is recommended only where the published facts map truthfully to a supported type (for example, a Person and factual creative/project entries). It is omitted rather than padded with invented employers, ratings, outcomes, or metrics.
- Desktop shell metadata describes the portfolio, not Windows or an unrelated inspiration site.

## 11. Privacy, security, and dependency hygiene

- Approved contact data is limited to `dannyriofriojimenez@gmail.com`, <https://www.linkedin.com/in/danny-riofrio-jimenez>, `@driofrio91`, and Murcia, Spain. The CV omits a phone number. No unrelated login identity is published.
- Harunna is client-owned; Danny owned end-to-end delivery, not the business. Its source is private, and its architecture is accurately labeled AWS Amplify Gen 1. Only <https://harunnainvestments.com/>, approved factual narrative, sanitized screenshots, an approved diagram, and reviewed decisions may be published.
- External links use HTTPS where available, identify their destination, and use safe new-context behavior when opening a new tab (`noopener`/`noreferrer` as appropriate). Email is a direct `mailto` action, not collected data.
- Images and `Danny_Riofrio_CV_ES.pdf` receive content and metadata inspection before release. Source material and rejected evidence stay outside public output.
- No browser-accessible environment variable, token, or runtime secret is expected. A build requiring private credentials violates the static content model.
- Dependencies are minimal, version-pinned by the eventual lockfile, reviewed for licenses and advisories, and updated deliberately. CI/build logs must not expose private source or asset inputs.
- No analytics, cookies, tracking pixels, service worker, or user-generated input enters the MVP.

## 12. Testing and verification strategy

### Verification matrix

| Layer | Observable contract | Planned verification |
| --- | --- | --- |
| Static diagnostics | Astro templates and strict TypeScript are valid | Astro check established in Unit 1 |
| Source consistency | Formatting/lint rules pass without hiding errors | Formatter check and lint established in Unit 1 |
| Content/schema | Required fields, relationships, route keys, approved links, locale, source visibility, and provenance states are valid | Build-time schema checks plus focused structural tests |
| Build | Static `dist` contains expected routes/assets and no server adapter/runtime dependency | Production build and output inspection |
| State core | Commands preserve lifecycle, singleton, active-window, z-order, and restore invariants | Vitest table/property-oriented unit cases over pure reducers |
| Geometry | Move/resize/maximize/restore/reflow remain bounded and recoverable | Vitest boundary cases across viewport and minimum-size inputs |
| Focus policy | Open/restore entry and close/minimize return targets are deterministic | Vitest policy cases plus browser focus assertions |
| Desktop journeys | About initial state; open/focus/close/minimize/restore/maximize; stacking and controls | Playwright desktop journeys |
| Pointer journeys | Pointer capture, drag/resize bounds, cancellation, and viewport recovery | Playwright interaction journeys and unit geometry checks |
| Keyboard/menu | Tab order, Enter, arrow navigation, Escape precedence, visible focus, no traps | Playwright keyboard journeys plus manual screen-reader review |
| Mobile | Fullscreen apps, disabled drag/resize, touch targets, taskbar restore, orientation recovery | Playwright mobile viewport journeys plus physical-device review |
| No JavaScript | About, Experience, Projects, GitHub, CV, contact, and evidence remain reachable/readable | Playwright JavaScript-disabled journey and raw HTML inspection |
| SEO | Unique Spanish metadata, canonical readiness, rendered headings/content, sitemap/robots | Structural assertions and production preview inspection |
| Accessibility | Semantic landmarks, names, contrast, reduced motion, zoom/reflow, screen-reader expectations | Automated browser checks where configured plus mandatory manual review |
| Privacy/legal | No prohibited contact data, private source, sensitive metadata, or unapproved assets | Repository/output scans plus human full-resolution/provenance review |

Tests assert outcomes rather than internal DOM styling. Browser journeys cover representative app paths without duplicating every reducer case. Manual visual review includes common desktop and mobile widths, 200% zoom, forced/reduced motion preferences where available, keyboard-only operation, at least one screen reader, focus under stacking, and fidelity against the approved original/licensed asset set.

## 13. Deployment and operations

1. Git is initialized only after implementation is explicitly authorized.
2. The authorized repository connects to Vercel through Git integration.
3. Pull requests or equivalent review branches produce preview deployments after diagnostics, tests, privacy/content gates, and a static production build.
4. Vercel publishes `dist` as static output with no Astro adapter and no server functions.
5. The approved production deployment is promoted after domain, metadata, asset, accessibility, and content checks.

No runtime environment variables or secrets are expected. If Vercel configuration requires only public build identifiers, they must not become content authorities. Content updates require a new build and atomic deployment; browsers/CDN may cache fingerprinted assets long-term while HTML receives a revalidation policy that allows editorial corrections to appear promptly. Rollback uses Vercel's previously verified immutable deployment, followed by a source correction so repository and production state converge.

Operational evidence consists of the source revision, successful build/check records, preview URL, production URL, route/asset smoke results, and identified rollback deployment. Availability monitoring or analytics may be considered later, but analytics is outside the MVP.

## 14. Architecture decisions

| ID | Decision and rationale | Rejected alternatives | Consequences |
| --- | --- | --- | --- |
| ADR-01 | Use static Astro because the product is content-led and must render meaningful HTML before JavaScript. | SPA rendering; server-rendered runtime; backend services. | Excellent static delivery and simple operations; interactive behavior must remain deliberately small. |
| ADR-02 | Keep manually curated content and assets in the repository with typed collections. | CMS; runtime GitHub API; automated repository feed. | Reviewable facts and reliable builds; updates require editorial work and deployment. |
| ADR-03 | Use a pure vanilla TypeScript state core with controller/DOM adapter boundaries. | React; external state store; state embedded in components. | Deterministic tests and low client cost; explicit DOM integration discipline is required. |
| ADR-04 | Use hand-authored layered CSS and lawful Windows 98-inspired primitives. | Tailwind; UI kit; copied proprietary assets; animation library. | Precise fidelity and small dependency surface; custom accessibility and consistency require careful review. |
| ADR-05 | Share canonical content records between stable routes and desktop views. | Separate route/window copy; JavaScript-owned content. | Facts cannot drift; projections and route-specific summaries need clear ownership. |
| ADR-06 | Deploy static `dist` through Vercel Git integration. | Astro server adapter; bespoke server; runtime hosting. | Preview and rollback are straightforward; platform configuration must remain static-only. |
| ADR-07 | Publish Spanish first while preserving a locale-aware model for later `/en/`. | Ship partial English; hard-code an unextendable single-language model. | MVP stays complete and honest; future English is a full content/release unit, not a toggle. |
| ADR-08 | Treat mobile as a capability policy: fullscreen apps, no drag/resize, taskbar restore retained. | Shrink desktop windows onto narrow screens; detect only by touch/user agent. | Reliable touch/reflow behavior; responsive mode changes need explicit geometry recovery. |
| ADR-09 | Make stable content routes the full-topic SEO destinations and `/` a distinct landing desktop. | Canonicalize all pages to `/`; index client-state URL variants. | Search ownership is clear while desktop summaries remain discoverable; page metadata must be maintained per route. |

## 15. Risks and mitigations

| Risk | Mitigation |
| --- | --- |
| Windows 98 fidelity harms contrast, semantics, reflow, or touch usability | Accessibility and content contracts outrank literal fidelity; tokens and primitives receive contrast, zoom, keyboard, and device review. |
| Window behavior becomes a fragile mini-framework | Keep a bounded command/state model, pure geometry/focus policy, singleton apps, no persistence, and no momentum physics. |
| Desktop and routes drift or create uncontrolled duplicate content | One typed content authority, shared projections, route ownership, unique metadata, and explicit summary/full-copy boundaries. |
| Harunna evidence leaks client/private information | Private-source schema field, allowlisted evidence, full-resolution sanitization, metadata stripping, and human approval before public placement. |
| Scope grows into CMS, localization, analytics, or AI showcase work | Enforce non-goals and roadmap unit boundaries; new product behavior requires a separate approved decision. |
| Generated or nostalgic assets have unclear legal status | Provenance records are mandatory; generation source and terms are reviewed; replace or omit anything without demonstrated permission. |
| Complex interactions exceed review capacity | Keep each vertical work unit near 400 authored changed lines and split by demonstrable behavior rather than compressing code/tests/docs. |
| Responsive mode changes strand windows or focus | Central capability/geometry policies process every viewport/orientation change and browser journeys verify recoverability. |

## 16. Assumptions and unresolved inputs

### Architecture assumptions

- Vercel continues to support direct static Astro output and preview deployments when implementation begins; Unit 1 verifies current platform/framework guidance without pinning a version here.
- A single responsive capability boundary can govern CSS layout and TypeScript command availability. Its exact value is calibrated from content and interaction evidence, not device branding.
- No archive-specific public route is required unless no-JavaScript/direct-link verification demonstrates that the archive cannot remain usable within the chosen stable-route structure.

### Required product inputs, not architecture questions

The following remain the authoritative open inputs from the requirements: final custom domain, approved Spanish CV, sanitized Harunna evidence package, corrected `estate-hub-prototype` README, lawful Windows 98-inspired asset set, and final reviewed Spanish editorial copy. Architecture must accommodate them; it must not invent or silently resolve them.

No implementation is authorized by this architecture document.
