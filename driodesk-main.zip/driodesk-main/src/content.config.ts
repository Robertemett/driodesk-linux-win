import { defineCollection } from "astro:content";

import { normalizeContent } from "./lib/content/normalize";
import { contentSchemas } from "./lib/content/schemas";

const normalized = normalizeContent();

const collection = <K extends keyof typeof normalized.all>(name: K) =>
  defineCollection({
    loader: async () => [...normalized.all[name]],
    schema: contentSchemas[name],
  });

export const collections = {
  profile: collection("profile"),
  navigation: collection("navigation"),
  experience: collection("experience"),
  education: collection("education"),
  skills: collection("skills"),
  caseStudies: collection("caseStudies"),
  repositories: collection("repositories"),
  archive: collection("archive"),
  seo: collection("seo"),
  assets: collection("assets"),
};
