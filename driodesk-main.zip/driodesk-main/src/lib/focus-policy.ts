import type { FocusIntent } from "./window-manager/state";

export type FocusCandidate =
  | { type: "id"; id: string }
  | { type: "active-window" }
  | { type: "start-trigger" }
  | { type: "desktop-launcher" }
  | { type: "desktop-root" };

export function getFocusCandidates(
  intent: FocusIntent,
  activeWindowId: string | null,
): FocusCandidate[] {
  const requested: FocusCandidate =
    intent.type === "window"
      ? { type: "id", id: `window-${intent.targetId}` }
      : { type: "id", id: intent.targetId };

  return [
    requested,
    ...(activeWindowId
      ? ([{ type: "active-window" }] as FocusCandidate[])
      : []),
    { type: "start-trigger" },
    { type: "desktop-launcher" },
    { type: "desktop-root" },
  ];
}

export function selectFocusCandidate<T>(
  candidates: FocusCandidate[],
  resolve: (candidate: FocusCandidate) => T | null,
  isEligible: (target: T) => boolean,
): T | null {
  for (const candidate of candidates) {
    const target = resolve(candidate);
    if (target !== null && isEligible(target)) return target;
  }
  return null;
}
