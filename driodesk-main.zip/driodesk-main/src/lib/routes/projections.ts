import { portfolioContent } from "../content/normalize";

const coreRouteKeys = [
  "home",
  "about",
  "experience",
  "projects",
  "github",
] as const;

export type CoreRouteKey = (typeof coreRouteKeys)[number];

export type ViewLink = {
  label: string;
  href: string;
};

export type ViewEntry = {
  title: string;
  details: string[];
  links: ViewLink[];
  image?: {
    src: string;
    alt: string;
  };
};

export type ViewSection = {
  heading: string;
  entries: ViewEntry[];
};

export type RouteProjection = {
  key: string;
  path: string;
  title: string;
  description: string;
  heading: string;
  sections: ViewSection[];
  pendingMessage: string | null;
};

const baselineMetadata: Record<
  CoreRouteKey,
  Pick<RouteProjection, "title" | "description" | "heading">
> = {
  home: {
    title: "Directorio | Portafolio",
    description: "Directorio estático de las rutas disponibles del portafolio.",
    heading: "Directorio del portafolio",
  },
  about: {
    title: "About | Portafolio",
    description: "Ruta About del portafolio profesional.",
    heading: "About",
  },
  experience: {
    title: "Experience | Portafolio",
    description: "Ruta Experience del portafolio profesional.",
    heading: "Experience",
  },
  projects: {
    title: "Projects | Portafolio",
    description: "Índice de casos de estudio aprobados para publicación.",
    heading: "Projects",
  },
  github: {
    title: "GitHub | Portafolio",
    description: "Selección aprobada de repositorios públicos.",
    heading: "GitHub",
  },
};

const seoByRouteKey = new Map(
  portfolioContent.all.seo.map((record) => [record.routeKey, record]),
);

const directoryLabels: Record<Exclude<CoreRouteKey, "home">, string> = {
  about: "About",
  experience: "Experience",
  projects: "Projects",
  github: "GitHub",
};

const getCanonicalPath = (key: string) => {
  const record = seoByRouteKey.get(key);
  if (!record) throw new Error(`Missing canonical route record for ${key}`);
  return record.path;
};

const displayPeriod = (value: string) => {
  if (value === "present") return "actualidad";
  const [year, month] = value.split("-");
  const months: Record<string, string> = {
    "04": "abr.",
    "06": "jun.",
    "07": "jul.",
    "12": "dic.",
  };
  return `${months[month ?? ""] ?? month} ${year}`;
};

const publishedSeo = new Map(
  portfolioContent.published.seo.map((record) => [record.routeKey, record]),
);

export const routeDirectory = coreRouteKeys
  .filter((key): key is Exclude<CoreRouteKey, "home"> => key !== "home")
  .map((key) => ({
    key,
    label: directoryLabels[key],
    href: getCanonicalPath(key),
  }));

function createSections(key: CoreRouteKey): ViewSection[] {
  if (key === "home") return [];

  if (key === "about") {
    const profileEntries = portfolioContent.published.profile.map((profile) => {
      const avatarAsset = portfolioContent.published.assets.find(
        (asset) => asset.id === profile.avatarAssetId,
      );
      const cvAsset = portfolioContent.published.assets.find(
        (asset) => asset.id === profile.cvAssetId,
      );

      return {
        title: `${profile.publicName} — ${profile.professionalTitle}`,
        details: [
          profile.summary ?? "",
          `${profile.minimumYearsExperience}+ años de experiencia`,
          profile.location,
        ].filter(Boolean),
        links: [
          { label: "Ver experiencia", href: getCanonicalPath("experience") },
          { label: "Ver proyectos", href: getCanonicalPath("projects") },
          { label: "LinkedIn", href: profile.linkedInUrl },
          { label: "Correo profesional", href: `mailto:${profile.email}` },
          ...(cvAsset?.localPath
            ? [{ label: "Descargar CV en español", href: cvAsset.localPath }]
            : []),
        ],
        ...(avatarAsset?.localPath && avatarAsset.alt
          ? {
              image: {
                src: avatarAsset.localPath,
                alt: avatarAsset.alt,
              },
            }
          : {}),
      };
    });
    const skillEntries = portfolioContent.published.skills.map((skill) => ({
      title: skill.label ?? "",
      details: [skill.description ?? "", ...skill.tags].filter(Boolean),
      links: [],
    }));
    return [
      { heading: "Perfil", entries: profileEntries },
      { heading: "Competencias", entries: skillEntries },
    ];
  }

  if (key === "experience") {
    const experienceEntries = portfolioContent.published.experience.map(
      (item) => ({
        title: item.employer,
        details: [
          `Empleador: ${item.employer}`,
          `Periodo: ${displayPeriod(item.start)}–${displayPeriod(item.end)}`,
          ...item.clients.map((client) => `Cliente: ${client}`),
          ...item.responsibilities,
          ...item.technologies,
        ],
        links: [],
      }),
    );
    const educationEntries = portfolioContent.published.education.map(
      (item) => ({
        title: item.name ?? "",
        details: [
          item.institutionOrIssuer ?? "",
          item.completionContext ?? "",
        ].filter(Boolean),
        links: [],
      }),
    );
    return [
      { heading: "Experiencia profesional", entries: experienceEntries },
      { heading: "Formación", entries: educationEntries },
    ];
  }

  if (key === "projects") {
    return [
      {
        heading: "Casos de estudio",
        entries: getPublishableCaseStudyProjections().map((study) => ({
          title: study.heading,
          details: [study.description],
          links: [{ label: "Leer el caso de estudio", href: study.path }],
        })),
      },
    ];
  }

  return [
    {
      heading: "Repositorios seleccionados",
      entries: portfolioContent.published.repositories.map((repository) => ({
        title: repository.name,
        details: [
          repository.description ?? "",
          ...repository.technologies,
        ].filter(Boolean),
        links: repository.repositoryUrl
          ? [
              {
                label: "Abrir repositorio en GitHub",
                href: repository.repositoryUrl,
              },
            ]
          : [],
      })),
    },
  ];
}

export function getCoreRouteProjection(key: CoreRouteKey): RouteProjection {
  const baseline = baselineMetadata[key];
  const approvedMetadata = publishedSeo.get(key);
  const sections = createSections(key);
  const hasEntries = sections.some((section) => section.entries.length > 0);
  const approvedCvAvailable = portfolioContent.published.assets.some(
    (asset) => asset.id === "spanish-cv" && Boolean(asset.localPath),
  );

  return {
    key,
    path: getCanonicalPath(key),
    title: approvedMetadata?.title ?? baseline.title,
    description: approvedMetadata?.description ?? baseline.description,
    heading: baseline.heading,
    sections,
    pendingMessage:
      key === "about" && hasEntries && !approvedCvAvailable
        ? "CV general en español: pendiente de publicación. La descarga se activará aquí cuando el archivo aprobado supere la revisión de contenido, privacidad y metadatos."
        : hasEntries
          ? null
          : key === "about"
            ? "Los enlaces de contacto y el CV se publicarán cuando sus registros estén aprobados."
            : "El contenido editorial de esta ruta está pendiente de aprobación.",
  };
}

export function getPublishableCaseStudyProjections(): RouteProjection[] {
  return portfolioContent.published.caseStudies.flatMap((study) => {
    const metadata = publishedSeo.get(study.slug);
    if (!metadata) return [];

    return [
      {
        key: study.slug,
        path: metadata.path,
        title: metadata.title ?? `${study.title} | Portafolio`,
        description: metadata.description ?? study.problem ?? study.title,
        heading: study.title,
        pendingMessage: null,
        sections: [
          {
            heading: "Caso de estudio",
            entries: [
              {
                title: study.title,
                details: [
                  study.problem ?? "",
                  `Propiedad: ${study.ownership.business}`,
                  `Responsabilidad de entrega: ${study.ownership.delivery}`,
                  `Visibilidad del código fuente: ${study.sourceVisibility === "private" ? "privado" : "público"}`,
                  ...study.approach,
                  ...study.capabilities,
                  ...study.limitations,
                ].filter(Boolean),
                links: study.links.map((link) => ({
                  label: link.label,
                  href: link.url,
                })),
              },
            ],
          },
        ],
      },
    ];
  });
}

export function validateRouteProjections() {
  const routes = [
    ...coreRouteKeys.map(getCoreRouteProjection),
    ...getPublishableCaseStudyProjections(),
  ];
  const paths = routes.map(({ path }) => path);
  const titles = routes.map(({ title }) => title);
  const descriptions = routes.map(({ description }) => description);

  if (new Set(paths).size !== paths.length)
    throw new Error("Route projections contain duplicate ownership");
  if (new Set(titles).size !== titles.length)
    throw new Error("Route projections contain duplicate titles");
  if (new Set(descriptions).size !== descriptions.length)
    throw new Error("Route projections contain duplicate descriptions");
  if (routes.some(({ path }) => path.startsWith("/en/")))
    throw new Error("English routes are prohibited in the MVP");
  if (portfolioContent.all.seo.some(({ locale }) => locale !== "es"))
    throw new Error("Only the Spanish locale may be published");

  return routes;
}

validateRouteProjections();
