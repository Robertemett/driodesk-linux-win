import type { StartMenuState } from "./state";

export type StartMenuDomAdapter = {
  root: HTMLElement;
  trigger: HTMLButtonElement;
  items: HTMLAnchorElement[];
  initialActiveIndex: number;
  applyState(state: StartMenuState): void;
  focusItem(index: number): void;
  focusTrigger(): void;
  markEnhanced(): void;
};

export type StartMenuDiscovery =
  { ok: true; adapter: StartMenuDomAdapter } | { ok: false; reason: string };

export function discoverStartMenu(document: Document): StartMenuDiscovery {
  const desktopRoots = [
    ...document.querySelectorAll<HTMLElement>("[data-desktop-root]"),
  ];
  if (desktopRoots.length !== 1)
    return { ok: false, reason: "Expected one desktop root" };
  const root = desktopRoots[0];
  const menuRoots = [
    ...root.querySelectorAll<HTMLElement>("[data-start-menu]"),
  ];
  if (menuRoots.length !== 1)
    return { ok: false, reason: "Expected one Start menu" };
  const menuRoot = menuRoots[0];
  const trigger = menuRoot.querySelector<HTMLButtonElement>(
    "[data-start-trigger]",
  );
  const popup = menuRoot.querySelector<HTMLElement>("[data-start-popup]");
  const list = menuRoot.querySelector<HTMLElement>("[data-start-list]");
  const listItems = list ? [...list.querySelectorAll(":scope > li")] : [];
  const items = [
    ...menuRoot.querySelectorAll<HTMLAnchorElement>("a[data-start-item]"),
  ];
  if (
    !trigger ||
    !popup ||
    !list ||
    !list.id ||
    !items.length ||
    listItems.length !== items.length
  )
    return { ok: false, reason: "Missing required Start menu hooks" };
  if (
    new Set(items.map(({ id }) => id)).size !== items.length ||
    items.some(
      (item) =>
        !item.id ||
        !item.href ||
        !item.dataset.appLauncher ||
        new URL(item.href, document.baseURI).origin !==
          document.location.origin,
    )
  )
    return { ok: false, reason: "Invalid Start menu items" };

  const initialActiveIndex = Math.max(
    0,
    items.findIndex((item) => item.getAttribute("aria-current") === "page"),
  );
  const adapter: StartMenuDomAdapter = {
    root,
    trigger,
    items,
    initialActiveIndex,
    applyState(state) {
      trigger.setAttribute("aria-expanded", String(state.open));
      popup.hidden = !state.open;
      items.forEach((item, index) => {
        item.tabIndex = index === state.activeIndex ? 0 : -1;
      });
    },
    focusItem(index) {
      items[index]?.focus({ preventScroll: true });
    },
    focusTrigger() {
      trigger.focus({ preventScroll: true });
    },
    markEnhanced() {
      trigger.hidden = false;
      trigger.setAttribute("aria-haspopup", "menu");
      trigger.setAttribute("aria-controls", list.id);
      list.setAttribute("role", "menu");
      listItems.forEach((item) => item.setAttribute("role", "none"));
      items.forEach((item) => item.setAttribute("role", "menuitem"));
      menuRoot.dataset.enhanced = "true";
    },
  };

  return { ok: true, adapter };
}
