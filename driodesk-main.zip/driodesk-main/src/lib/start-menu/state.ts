export type StartMenuState = {
  open: boolean;
  activeIndex: number;
  itemCount: number;
};

export type StartMenuCommand =
  | { type: "open"; placement?: "current" | "first" | "last" }
  | { type: "close" }
  | { type: "next" }
  | { type: "previous" }
  | { type: "first" }
  | { type: "last" };

export function createStartMenuState(
  itemCount: number,
  currentIndex = 0,
): StartMenuState {
  if (!Number.isInteger(itemCount) || itemCount < 1)
    throw new Error("Start menu requires at least one item");

  return {
    open: false,
    activeIndex:
      currentIndex >= 0 && currentIndex < itemCount ? currentIndex : 0,
    itemCount,
  };
}

export function reduceStartMenu(
  state: StartMenuState,
  command: StartMenuCommand,
): StartMenuState {
  if (command.type === "open") {
    const activeIndex =
      command.placement === "first"
        ? 0
        : command.placement === "last"
          ? state.itemCount - 1
          : state.activeIndex;
    return { ...state, open: true, activeIndex };
  }
  if (command.type === "close") return { ...state, open: false };
  if (command.type === "first") return { ...state, activeIndex: 0 };
  if (command.type === "last")
    return { ...state, activeIndex: state.itemCount - 1 };
  if (command.type === "next")
    return { ...state, activeIndex: (state.activeIndex + 1) % state.itemCount };
  return {
    ...state,
    activeIndex: (state.activeIndex - 1 + state.itemCount) % state.itemCount,
  };
}
