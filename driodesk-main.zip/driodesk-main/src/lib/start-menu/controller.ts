import type { StartMenuDomAdapter } from "./dom-adapter";
import {
  createStartMenuState,
  reduceStartMenu,
  type StartMenuCommand,
} from "./state";

export function startStartMenuController(adapter: StartMenuDomAdapter) {
  let state = createStartMenuState(
    adapter.items.length,
    adapter.initialActiveIndex,
  );

  const dispatch = (command: StartMenuCommand, focusItem = false) => {
    state = reduceStartMenu(state, command);
    adapter.applyState(state);
    if (focusItem) adapter.focusItem(state.activeIndex);
  };
  const close = (restoreFocus: boolean) => {
    if (!state.open) return;
    dispatch({ type: "close" });
    if (restoreFocus) adapter.focusTrigger();
  };
  const open = (placement: "current" | "first" | "last" = "current") =>
    dispatch({ type: "open", placement }, true);

  const onClick = (event: MouseEvent) => {
    const target = event.target;
    if (!(target instanceof Element)) return;
    if (target.closest("[data-start-trigger]")) {
      event.preventDefault();
      if (state.open) close(true);
      else open();
      return;
    }
    if (target.closest("[data-start-item]")) {
      close(false);
      return;
    }
    if (state.open && !target.closest("[data-start-menu]")) close(false);
  };

  const onKeyDown = (event: KeyboardEvent) => {
    const target = event.target;
    if (!(target instanceof Element)) return;

    if (state.open && event.key === "Escape") {
      event.preventDefault();
      event.stopPropagation();
      close(true);
      return;
    }

    if (target.closest("[data-start-trigger]")) {
      if (event.key === "ArrowDown") {
        event.preventDefault();
        open();
      } else if (event.key === "ArrowUp") {
        event.preventDefault();
        open("last");
      } else if (event.key === "Home" || event.key === "End") {
        event.preventDefault();
        open(event.key === "Home" ? "first" : "last");
      }
      return;
    }

    if (!state.open || !target.closest("[data-start-item]")) return;
    const commands: Partial<Record<string, StartMenuCommand["type"]>> = {
      ArrowDown: "next",
      ArrowUp: "previous",
      Home: "first",
      End: "last",
    };
    const command = commands[event.key];
    if (command) {
      event.preventDefault();
      dispatch({ type: command } as StartMenuCommand, true);
    } else if (event.key === " ") {
      event.preventDefault();
      (target.closest("[data-start-item]") as HTMLAnchorElement).click();
    }
  };

  const onFocusIn = (event: FocusEvent) => {
    const target = event.target;
    if (
      state.open &&
      target instanceof Element &&
      !target.closest("[data-start-menu]")
    )
      close(false);
  };

  adapter.applyState(state);
  adapter.root.addEventListener("click", onClick);
  adapter.root.addEventListener("keydown", onKeyDown, true);
  adapter.root.addEventListener("focusin", onFocusIn);
  return {
    getState: () => state,
    destroy() {
      adapter.root.removeEventListener("click", onClick);
      adapter.root.removeEventListener("keydown", onKeyDown, true);
      adapter.root.removeEventListener("focusin", onFocusIn);
    },
  };
}
