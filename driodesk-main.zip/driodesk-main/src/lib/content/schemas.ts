import { z } from "astro/zod";

export const editorialStateSchema = z.enum(["approved", "pending", "excluded"]);
export const inclusionStateSchema = z.enum(["included", "pending", "excluded"]);
export const localeSchema = z.literal("es");
const key = z.string().regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/);
const httpsUrl = z.url({ protocol: /^https$/ });
const nullableCopy = z.string().min(1).nullable();
const base = z.object({
  id: key,
  locale: localeSchema,
  editorialState: editorialStateSchema,
});

export const profileSchema = base.extend({
  publicName: z.literal("Danny Riofrio"),
  professionalTitle: z.literal("Senior Software Engineer"),
  minimumYearsExperience: z.number().int().min(10),
  location: z.literal("Murcia, Spain"),
  windowsUsername: z.literal("driofrio91"),
  githubIdentity: z.literal("@driofrio91"),
  email: z.literal("dannyriofriojimenez@gmail.com"),
  linkedInUrl: z.literal("https://www.linkedin.com/in/danny-riofrio-jimenez"),
  summary: nullableCopy,
  avatarAssetId: key.nullable(),
  cvAssetId: key.nullable(),
});

export const navigationSchema = base.extend({
  label: z.string().min(1),
  routeKey: key.nullable(),
  iconAssetId: key.nullable(),
  initialState: z.enum(["open", "closed"]),
  order: z.number().int().nonnegative(),
  inclusion: inclusionStateSchema,
});

export const experienceSchema = base.extend({
  employer: z.string().min(1),
  start: z.string().regex(/^\d{4}-(0[1-9]|1[0-2])$/),
  end: z.union([
    z.literal("present"),
    z.string().regex(/^\d{4}-(0[1-9]|1[0-2])$/),
  ]),
  clients: z.array(z.string().min(1)),
  sectors: z.array(z.string().min(1)),
  progression: z.array(z.string().min(1)),
  responsibilities: z.array(z.string().min(1)),
  technologies: z.array(z.string().min(1)),
  order: z.number().int().nonnegative(),
});

export const educationSchema = base.extend({
  kind: z.enum(["vocational-qualification", "certification"]),
  name: nullableCopy,
  institutionOrIssuer: nullableCopy,
  completionContext: nullableCopy,
  order: z.number().int().nonnegative(),
});

export const skillGroupSchema = base.extend({
  key,
  label: nullableCopy,
  description: nullableCopy,
  tags: z.array(z.string().min(1)),
  exposure: z.enum([
    "professional-foundation",
    "professional-use",
    "personal-project",
    "pending",
  ]),
  order: z.number().int().nonnegative(),
});

export const caseStudySchema = base.extend({
  slug: key,
  title: z.string().min(1),
  problem: nullableCopy,
  ownership: z.object({
    business: z.string().min(1),
    delivery: z.string().min(1),
  }),
  approach: z.array(z.string().min(1)),
  stack: z.array(z.string().min(1)),
  capabilities: z.array(z.string().min(1)),
  decisions: z.array(z.string().min(1)),
  evidenceAssetIds: z.array(key),
  limitations: z.array(z.string().min(1)),
  links: z.array(z.object({ label: z.string().min(1), url: httpsUrl })),
  sourceVisibility: z.enum(["public", "private"]),
  inclusion: inclusionStateSchema,
  order: z.number().int().nonnegative(),
});

export const repositorySchema = base.extend({
  name: z.string().min(1),
  description: nullableCopy,
  technologies: z.array(z.string().min(1)),
  repositoryUrl: httpsUrl.nullable(),
  inclusion: inclusionStateSchema,
  order: z.number().int().nonnegative(),
});

export const archiveSchema = base.extend({
  label: z.literal("Archive 2014–2015"),
  context: nullableCopy,
  groups: z.array(
    z.object({
      id: key,
      projects: z.array(z.string().min(1)).min(1),
      links: z.array(httpsUrl),
    }),
  ),
  inclusion: inclusionStateSchema,
});

export const seoSchema = base.extend({
  routeKey: key,
  path: z.string().regex(/^\/(?:[a-z0-9-]+\/)*(?:[a-z0-9-]+\/)?$/),
  title: nullableCopy,
  description: nullableCopy,
  socialImageAssetId: key.nullable(),
  crawl: z.enum(["index", "noindex"]),
});

export const assetSchema = base.extend({
  localPath: z.string().startsWith("/").nullable(),
  purpose: z.enum(["profile", "document", "icon", "evidence", "social"]),
  alt: nullableCopy,
  decorative: z.boolean(),
  origin: nullableCopy,
  creator: nullableCopy,
  license: nullableCopy,
  permission: z.enum(["approved", "pending", "rejected"]),
  sanitization: z.enum(["approved", "pending", "not-applicable"]),
  sanitizationNotes: nullableCopy,
  sourcePath: nullableCopy,
  outputPath: nullableCopy,
  sourceSha256: z
    .string()
    .regex(/^[a-f0-9]{64}$/)
    .nullable(),
  outputSha256: z
    .string()
    .regex(/^[a-f0-9]{64}$/)
    .nullable(),
});

export const contentSchemas = {
  profile: profileSchema,
  navigation: navigationSchema,
  experience: experienceSchema,
  education: educationSchema,
  skills: skillGroupSchema,
  caseStudies: caseStudySchema,
  repositories: repositorySchema,
  archive: archiveSchema,
  seo: seoSchema,
  assets: assetSchema,
};
