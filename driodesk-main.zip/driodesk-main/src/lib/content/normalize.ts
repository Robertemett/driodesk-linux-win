import { contentRecords, type ContentRecords } from "../../content/records";
import { contentSchemas } from "./schemas";

export class ContentRelationshipError extends Error {}

const isPublishable = (record: {
  editorialState: string;
  inclusion?: string;
}) =>
  record.editorialState === "approved" &&
  (!record.inclusion || record.inclusion === "included");

function requirePublicationFields(
  name: string,
  records: Array<Record<string, unknown>>,
  fields: string[],
  errors: string[],
) {
  for (const record of records) {
    if (
      !isPublishable(record as { editorialState: string; inclusion?: string })
    )
      continue;
    for (const field of fields) {
      const value = record[field];
      if (
        value === null ||
        value === "pending" ||
        (Array.isArray(value) && value.length === 0)
      ) {
        errors.push(
          `${name} ${String(record.id)} cannot publish without ${field}`,
        );
      }
    }
  }
}

export function normalizeContent(records: ContentRecords = contentRecords) {
  const parsed = Object.fromEntries(
    Object.entries(records).map(([name, entries]) => {
      const schema = contentSchemas[name as keyof typeof contentSchemas];
      return [name, entries.map((entry) => schema.parse(entry))];
    }),
  ) as unknown as {
    [K in keyof ContentRecords]: Array<(typeof contentRecords)[K][number]>;
  };

  const errors: string[] = [];
  const assetById = new Map<string, (typeof parsed.assets)[number]>(
    parsed.assets.map((asset) => [asset.id, asset]),
  );
  const routes = new Set(parsed.seo.map(({ routeKey }) => routeKey));
  const validateAsset = (
    owner: { id: string; editorialState: string; inclusion?: string },
    assetId: string,
  ) => {
    const asset = assetById.get(assetId);
    if (!asset) errors.push(`${owner.id} references missing asset ${assetId}`);
    else if (isPublishable(owner) && !isPublishable(asset))
      errors.push(`${owner.id} references unpublished asset ${assetId}`);
  };

  for (const [name, entries] of Object.entries(parsed)) {
    const ids = entries.map(({ id }) => id);
    if (new Set(ids).size !== ids.length)
      errors.push(`${name} contains duplicate identifiers`);
  }
  for (const item of parsed.navigation) {
    if (item.routeKey && !routes.has(item.routeKey))
      errors.push(
        `Navigation ${item.id} references missing route ${item.routeKey}`,
      );
    if (item.iconAssetId) validateAsset(item, item.iconAssetId);
  }
  for (const profile of parsed.profile) {
    if (profile.avatarAssetId) validateAsset(profile, profile.avatarAssetId);
    if (profile.cvAssetId && !assetById.has(profile.cvAssetId))
      errors.push(
        `${profile.id} references missing CV asset ${profile.cvAssetId}`,
      );
  }
  for (const study of parsed.caseStudies) {
    for (const assetId of study.evidenceAssetIds) {
      validateAsset(study, assetId);
    }
  }
  for (const record of parsed.seo) {
    if (record.socialImageAssetId)
      validateAsset(record, record.socialImageAssetId);
  }
  requirePublicationFields(
    "Profile",
    parsed.profile,
    ["summary", "avatarAssetId", "cvAssetId"],
    errors,
  );
  requirePublicationFields(
    "Navigation",
    parsed.navigation,
    ["routeKey", "iconAssetId"],
    errors,
  );
  requirePublicationFields(
    "Experience",
    parsed.experience,
    ["responsibilities", "technologies"],
    errors,
  );
  requirePublicationFields(
    "Education",
    parsed.education,
    ["name", "institutionOrIssuer", "completionContext"],
    errors,
  );
  requirePublicationFields(
    "Skill group",
    parsed.skills,
    ["label", "description", "tags", "exposure"],
    errors,
  );
  requirePublicationFields(
    "Case study",
    parsed.caseStudies,
    ["problem", "evidenceAssetIds"],
    errors,
  );
  requirePublicationFields(
    "Repository",
    parsed.repositories,
    ["description", "technologies", "repositoryUrl"],
    errors,
  );
  requirePublicationFields("Archive", parsed.archive, ["context"], errors);
  requirePublicationFields("SEO", parsed.seo, ["title", "description"], errors);
  requirePublicationFields(
    "Asset",
    parsed.assets,
    [
      "localPath",
      "origin",
      "creator",
      "license",
      "permission",
      "sanitization",
      "sanitizationNotes",
      "sourcePath",
      "outputPath",
      "sourceSha256",
      "outputSha256",
    ],
    errors,
  );
  for (const asset of parsed.assets.filter(isPublishable)) {
    if (!asset.decorative && !asset.alt)
      errors.push(`Asset ${asset.id} cannot publish without alt`);
  }
  const ownedRoutes = parsed.navigation.flatMap(({ routeKey }) =>
    routeKey ? [routeKey] : [],
  );
  if (new Set(ownedRoutes).size !== ownedRoutes.length)
    errors.push("Navigation contains duplicate route ownership");
  const seoRoutes = parsed.seo.map(({ routeKey }) => routeKey);
  if (new Set(seoRoutes).size !== seoRoutes.length)
    errors.push("SEO contains duplicate route ownership");
  if (errors.length) throw new ContentRelationshipError(errors.join("; "));

  return {
    all: parsed,
    published: Object.fromEntries(
      Object.entries(parsed).map(([name, entries]) => [
        name,
        entries
          .filter(isPublishable)
          .sort((a, b) =>
            "order" in a && "order" in b
              ? Number(a.order) - Number(b.order)
              : 0,
          ),
      ]),
    ) as { [K in keyof typeof parsed]: (typeof parsed)[K] },
  };
}

export const portfolioContent = normalizeContent();
