import type {
  FocusIntent,
  WindowDefinition,
  WindowManagerState,
  WindowRect,
} from "./state";
import { getMaximizedRect, type WorkspaceSize } from "./geometry";
import {
  getFocusCandidates,
  selectFocusCandidate,
  type FocusCandidate,
} from "../focus-policy";

type WindowElement = HTMLElement & {
  dataset: DOMStringMap & {
    appWindow: string;
    appPath: string;
    initialX: string;
    initialY: string;
    initialWidth: string;
    initialHeight: string;
    returnTarget: string;
  };
};

export type DesktopDomAdapter = {
  root: HTMLElement;
  initialWindowId: string;
  definitions: WindowDefinition[];
  applyState: (state: WindowManagerState) => void;
  getWorkspaceSize: () => WorkspaceSize;
  observeWorkspace: (listener: () => void) => () => void;
  focus: (intent: FocusIntent, state: WindowManagerState) => void;
  getAppIdForLink: (link: HTMLAnchorElement) => string | null;
  getReturnTargetId: (id: string) => string;
  markEnhanced: () => void;
};

export type DesktopDiscovery =
  { ok: true; adapter: DesktopDomAdapter } | { ok: false; reason: string };

const asNumber = (value: string | undefined) => {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
};

const readRect = (element: WindowElement): WindowRect | null => {
  const values = [
    asNumber(element.dataset.initialX),
    asNumber(element.dataset.initialY),
    asNumber(element.dataset.initialWidth),
    asNumber(element.dataset.initialHeight),
  ];
  if (values.some((value) => value === null)) return null;
  const [x, y, width, height] = values as number[];
  if (width <= 0 || height <= 0) return null;
  return { x, y, width, height };
};

const getMaximizedWindowBounds = (
  root: HTMLElement,
  taskbar: HTMLElement,
): WindowRect => {
  const desktopBounds = root.getBoundingClientRect();
  const taskbarBounds = taskbar.getBoundingClientRect();
  return {
    x: desktopBounds.left,
    y: desktopBounds.top,
    width: desktopBounds.width,
    height: Math.max(0, taskbarBounds.top - desktopBounds.top),
  };
};

export function discoverDesktop(document: Document): DesktopDiscovery {
  const roots = document.querySelectorAll<HTMLElement>("[data-desktop-root]");
  if (roots.length !== 1)
    return { ok: false, reason: "Expected one desktop root" };
  const root = roots[0];
  const workspace = root.querySelector<HTMLElement>("[data-window-workspace]");
  if (!workspace) return { ok: false, reason: "Missing window workspace" };
  const taskbar = root.querySelector<HTMLElement>("[data-desktop-taskbar]");
  if (!taskbar) return { ok: false, reason: "Missing desktop taskbar" };

  const windowElements = [
    ...root.querySelectorAll<WindowElement>("[data-app-window]"),
  ];
  const ids = windowElements.map(({ dataset }) => dataset.appWindow);
  if (!ids.length || ids.some((id) => !id) || new Set(ids).size !== ids.length)
    return { ok: false, reason: "Invalid window identifiers" };

  const initialWindowId = root.dataset.initialWindow;
  if (!initialWindowId || !ids.includes(initialWindowId))
    return { ok: false, reason: "Invalid initial window" };

  const windows = new Map(
    windowElements.map((element) => [element.dataset.appWindow, element]),
  );
  const taskbarItems = new Map(
    [...root.querySelectorAll<HTMLAnchorElement>("[data-taskbar-item]")].map(
      (element) => [element.dataset.taskbarItem ?? "", element],
    ),
  );
  if (ids.some((id) => !taskbarItems.has(id)))
    return { ok: false, reason: "A window has no taskbar item" };

  const rects = windowElements.map(readRect);
  if (rects.some((rect) => rect === null))
    return { ok: false, reason: "Invalid initial window geometry" };

  const paths = new Map(
    windowElements.map((element) => [
      element.dataset.appPath,
      element.dataset.appWindow,
    ]),
  );
  if (paths.size !== windowElements.length)
    return { ok: false, reason: "Invalid or duplicate app paths" };

  const adapter: DesktopDomAdapter = {
    root,
    initialWindowId,
    definitions: ids.map((id, index) => ({
      id,
      initialRect: rects[index] as WindowRect,
    })),
    getWorkspaceSize() {
      return { width: workspace.clientWidth, height: workspace.clientHeight };
    },
    observeWorkspace(listener) {
      const view = document.defaultView;
      const observer = view?.ResizeObserver
        ? new view.ResizeObserver(listener)
        : null;
      observer?.observe(workspace);
      observer?.observe(root);
      observer?.observe(taskbar);
      view?.addEventListener("resize", listener);
      return () => {
        observer?.disconnect();
        view?.removeEventListener("resize", listener);
      };
    },
    applyState(state) {
      const maximizedBounds = getMaximizedWindowBounds(root, taskbar);
      const maximizedRect = getMaximizedRect(maximizedBounds);
      const patches = state.order.map((id) => {
        const windowState = state.windows[id];
        const element = windows.get(id);
        const taskbarItem = taskbarItems.get(id);
        if (!element || !taskbarItem)
          throw new Error(`Lost required DOM hooks for ${id}`);
        return { windowState, element, taskbarItem };
      });

      for (const { windowState, element, taskbarItem } of patches) {
        const visible = windowState.lifecycle === "open";
        element.hidden = !visible;
        element.dataset.lifecycle = windowState.lifecycle;
        element.dataset.displayMode = windowState.displayMode;
        element.dataset.active = String(
          state.activeWindowId === windowState.id,
        );
        element.style.zIndex = String(windowState.zOrder ?? 0);
        if (windowState.displayMode === "maximized") {
          element.style.position = "fixed";
          element.style.left = `${maximizedBounds.x}px`;
          element.style.top = `${maximizedBounds.y}px`;
          element.style.transform = "none";
          element.style.width = `${maximizedRect.width}px`;
          element.style.height = `${maximizedRect.height}px`;
        } else {
          element.style.position = "absolute";
          element.style.left = "0px";
          element.style.top = "0px";
          element.style.transform = `translate3d(${windowState.currentRect.x}px, ${windowState.currentRect.y}px, 0)`;
          element.style.width = `${windowState.currentRect.width}px`;
          element.style.height = `${windowState.currentRect.height}px`;
        }

        taskbarItem.hidden = windowState.lifecycle === "closed";
        taskbarItem.dataset.lifecycle = windowState.lifecycle;
        if (state.activeWindowId === windowState.id)
          taskbarItem.setAttribute("aria-current", "true");
        else taskbarItem.removeAttribute("aria-current");

        const maximize = element.querySelector<HTMLButtonElement>(
          '[data-window-command="toggle-maximize"]',
        );
        const glyph = maximize?.querySelector<HTMLElement>(
          "[data-maximize-glyph]",
        );
        if (maximize) {
          const label =
            element.querySelector("h1")?.textContent?.trim() ?? windowState.id;
          maximize.setAttribute(
            "aria-label",
            `${windowState.displayMode === "maximized" ? "Restaurar" : "Maximizar"} ${label}`,
          );
        }
        if (glyph)
          glyph.textContent =
            windowState.displayMode === "maximized" ? "❐" : "□";
      }

      root.dataset.activeWindow = state.activeWindowId ?? "";
    },
    focus(intent, state) {
      const resolve = (candidate: FocusCandidate) => {
        if (candidate.type === "id")
          return document.getElementById(candidate.id);
        if (candidate.type === "active-window")
          return state.activeWindowId
            ? (windows.get(state.activeWindowId) ?? null)
            : null;
        if (candidate.type === "start-trigger")
          return root.querySelector<HTMLElement>("[data-start-trigger]");
        if (candidate.type === "desktop-launcher")
          return root.querySelector<HTMLElement>(
            ".desktop-icons [data-app-launcher]",
          );
        return root;
      };
      const target = selectFocusCandidate(
        getFocusCandidates(intent, state.activeWindowId),
        resolve,
        (element) =>
          element.isConnected &&
          !element.closest('[hidden], [inert], [aria-hidden="true"]'),
      );
      target?.focus({ preventScroll: true });
    },
    getAppIdForLink(link) {
      const path = new URL(link.href, document.baseURI).pathname;
      return paths.get(path) ?? null;
    },
    getReturnTargetId(id) {
      return windows.get(id)?.dataset.returnTarget ?? "desktop-icon-about";
    },
    markEnhanced() {
      root.dataset.enhanced = "true";
    },
  };

  return { ok: true, adapter };
}
