import {
  isValidWindowRect,
  recoverWindowRect,
  type WindowRect,
  type WorkspaceSize,
} from "./geometry";

export type { WindowRect } from "./geometry";

export type WindowLifecycle = "closed" | "open" | "minimized";
export type WindowDisplayMode = "normal" | "maximized";

export type WindowDefinition = {
  id: string;
  initialRect: WindowRect;
  canMaximize?: boolean;
};

export type WindowState = {
  id: string;
  lifecycle: WindowLifecycle;
  displayMode: WindowDisplayMode;
  zOrder: number | null;
  initialRect: WindowRect;
  currentRect: WindowRect;
  restoreRect: WindowRect | null;
  canMaximize: boolean;
};

export type WindowManagerState = {
  activeWindowId: string | null;
  order: string[];
  windows: Record<string, WindowState>;
};

export type WindowCommand =
  | { type: "open"; id: string; returnTargetId?: string }
  | { type: "focus"; id: string }
  | { type: "close"; id: string; returnTargetId?: string }
  | { type: "minimize"; id: string; returnTargetId?: string }
  | { type: "restore-from-taskbar"; id: string }
  | { type: "maximize"; id: string }
  | { type: "restore-size"; id: string }
  | { type: "set-rect"; id: string; rect: WindowRect }
  | { type: "recover-workspace"; workspace: WorkspaceSize };

export type FocusIntent =
  { type: "window"; targetId: string } | { type: "return"; targetId: string };

export type WindowCommandResult =
  | {
      status: "applied";
      command: WindowCommand["type"];
      focus: FocusIntent | null;
    }
  | {
      status: "noop";
      command: WindowCommand["type"];
      reason:
        | "already-active"
        | "already-closed"
        | "already-maximized"
        | "already-minimized"
        | "already-normal"
        | "geometry-unchanged"
        | "not-minimized";
      focus: null;
    }
  | {
      status: "rejected";
      command: WindowCommand["type"];
      reason:
        | "invalid-id"
        | "invalid-geometry"
        | "not-normal"
        | "not-visible"
        | "unsupported";
      focus: null;
    };

export type WindowTransition = {
  state: WindowManagerState;
  result: WindowCommandResult;
};

const copyRect = (rect: WindowRect): WindowRect => ({ ...rect });
const isVisible = (window: WindowState) => window.lifecycle === "open";

export function createWindowManagerState(
  definitions: WindowDefinition[],
  initiallyOpenId: string | null,
): WindowManagerState {
  const ids = definitions.map(({ id }) => id);
  if (new Set(ids).size !== ids.length)
    throw new Error("Window definitions contain duplicate identifiers");
  if (initiallyOpenId !== null && !ids.includes(initiallyOpenId))
    throw new Error(`Unknown initially open window: ${initiallyOpenId}`);

  return {
    activeWindowId: initiallyOpenId,
    order: ids,
    windows: Object.fromEntries(
      definitions.map((definition) => [
        definition.id,
        {
          id: definition.id,
          lifecycle: definition.id === initiallyOpenId ? "open" : "closed",
          displayMode: "normal",
          zOrder: definition.id === initiallyOpenId ? 1 : null,
          initialRect: copyRect(definition.initialRect),
          currentRect: copyRect(definition.initialRect),
          restoreRect: null,
          canMaximize: definition.canMaximize ?? true,
        },
      ]),
    ),
  };
}

function cloneState(state: WindowManagerState): WindowManagerState {
  return {
    activeWindowId: state.activeWindowId,
    order: [...state.order],
    windows: Object.fromEntries(
      state.order.map((id) => {
        const window = state.windows[id];
        return [
          id,
          {
            ...window,
            initialRect: copyRect(window.initialRect),
            currentRect: copyRect(window.currentRect),
            restoreRect: window.restoreRect
              ? copyRect(window.restoreRect)
              : null,
          },
        ];
      }),
    ),
  };
}

function normalizedVisibleIds(state: WindowManagerState) {
  return state.order
    .filter((id) => isVisible(state.windows[id]))
    .sort((left, right) => {
      const zDifference =
        (state.windows[left].zOrder ?? 0) - (state.windows[right].zOrder ?? 0);
      return (
        zDifference || state.order.indexOf(left) - state.order.indexOf(right)
      );
    });
}

function normalizeZOrder(state: WindowManagerState) {
  const visibleIds = normalizedVisibleIds(state);
  visibleIds.forEach((id, index) => {
    state.windows[id].zOrder = index + 1;
  });
  state.order
    .filter((id) => !isVisible(state.windows[id]))
    .forEach((id) => {
      state.windows[id].zOrder = null;
    });
}

function raise(state: WindowManagerState, id: string) {
  const highest = Math.max(
    0,
    ...state.order.map((candidate) => state.windows[candidate].zOrder ?? 0),
  );
  state.windows[id].zOrder = highest + 1;
  state.activeWindowId = id;
  normalizeZOrder(state);
}

function selectNextActive(state: WindowManagerState) {
  normalizeZOrder(state);
  state.activeWindowId = normalizedVisibleIds(state).at(-1) ?? null;
}

const applied = (
  command: WindowCommand["type"],
  focus: FocusIntent | null,
): WindowCommandResult => ({ status: "applied", command, focus });

const noop = (
  command: WindowCommand["type"],
  reason: Extract<WindowCommandResult, { status: "noop" }>["reason"],
): WindowCommandResult => ({ status: "noop", command, reason, focus: null });

const rejected = (
  command: WindowCommand["type"],
  reason: Extract<WindowCommandResult, { status: "rejected" }>["reason"],
): WindowCommandResult => ({
  status: "rejected",
  command,
  reason,
  focus: null,
});

export function reduceWindowCommand(
  state: WindowManagerState,
  command: WindowCommand,
): WindowTransition {
  if (command.type === "recover-workspace") {
    const next = cloneState(state);
    let changed = false;
    for (const id of next.order) {
      const window = next.windows[id];
      const currentRect = recoverWindowRect(
        window.currentRect,
        command.workspace,
      );
      const restoreRect = window.restoreRect
        ? recoverWindowRect(window.restoreRect, command.workspace)
        : null;
      if (!rectsEqual(currentRect, window.currentRect)) changed = true;
      if (
        restoreRect &&
        window.restoreRect &&
        !rectsEqual(restoreRect, window.restoreRect)
      )
        changed = true;
      window.currentRect = currentRect;
      window.restoreRect = restoreRect;
    }
    return changed
      ? { state: next, result: applied(command.type, null) }
      : { state, result: noop(command.type, "geometry-unchanged") };
  }

  const current = state.windows[command.id];
  if (!current) return { state, result: rejected(command.type, "invalid-id") };

  if (command.type === "open") {
    if (current.lifecycle === "open" && state.activeWindowId === current.id)
      return { state, result: noop(command.type, "already-active") };
    const next = cloneState(state);
    const window = next.windows[command.id];
    if (window.lifecycle === "closed") {
      window.lifecycle = "open";
      window.displayMode = "normal";
      window.restoreRect = null;
    } else if (window.lifecycle === "minimized") {
      window.lifecycle = "open";
    }
    raise(next, command.id);
    return {
      state: next,
      result: applied(command.type, { type: "window", targetId: command.id }),
    };
  }

  if (command.type === "focus") {
    if (!isVisible(current))
      return { state, result: rejected(command.type, "not-visible") };
    if (state.activeWindowId === current.id)
      return { state, result: noop(command.type, "already-active") };
    const next = cloneState(state);
    raise(next, command.id);
    return {
      state: next,
      result: applied(command.type, { type: "window", targetId: command.id }),
    };
  }

  if (command.type === "close") {
    if (current.lifecycle === "closed")
      return { state, result: noop(command.type, "already-closed") };
    const next = cloneState(state);
    const window = next.windows[command.id];
    window.lifecycle = "closed";
    window.displayMode = "normal";
    window.currentRect = copyRect(window.initialRect);
    window.restoreRect = null;
    if (state.activeWindowId === command.id) selectNextActive(next);
    else normalizeZOrder(next);
    return {
      state: next,
      result: applied(
        command.type,
        command.returnTargetId
          ? { type: "return", targetId: command.returnTargetId }
          : null,
      ),
    };
  }

  if (command.type === "minimize") {
    if (current.lifecycle === "minimized")
      return { state, result: noop(command.type, "already-minimized") };
    if (current.lifecycle === "closed")
      return { state, result: rejected(command.type, "not-visible") };
    const next = cloneState(state);
    next.windows[command.id].lifecycle = "minimized";
    if (state.activeWindowId === command.id) selectNextActive(next);
    else normalizeZOrder(next);
    return {
      state: next,
      result: applied(
        command.type,
        command.returnTargetId
          ? { type: "return", targetId: command.returnTargetId }
          : null,
      ),
    };
  }

  if (command.type === "restore-from-taskbar") {
    if (current.lifecycle !== "minimized")
      return { state, result: noop(command.type, "not-minimized") };
    const next = cloneState(state);
    next.windows[command.id].lifecycle = "open";
    raise(next, command.id);
    return {
      state: next,
      result: applied(command.type, { type: "window", targetId: command.id }),
    };
  }

  if (!isVisible(current))
    return { state, result: rejected(command.type, "not-visible") };

  if (command.type === "set-rect") {
    if (current.displayMode !== "normal")
      return { state, result: rejected(command.type, "not-normal") };
    if (!isValidWindowRect(command.rect))
      return { state, result: rejected(command.type, "invalid-geometry") };
    if (rectsEqual(current.currentRect, command.rect))
      return { state, result: noop(command.type, "geometry-unchanged") };
    const next = cloneState(state);
    next.windows[command.id].currentRect = copyRect(command.rect);
    return { state: next, result: applied(command.type, null) };
  }

  if (!current.canMaximize)
    return { state, result: rejected(command.type, "unsupported") };

  if (command.type === "maximize") {
    if (current.displayMode === "maximized")
      return { state, result: noop(command.type, "already-maximized") };
    const next = cloneState(state);
    const window = next.windows[command.id];
    window.restoreRect = copyRect(window.currentRect);
    window.displayMode = "maximized";
    return { state: next, result: applied(command.type, null) };
  }

  if (current.displayMode === "normal")
    return { state, result: noop(command.type, "already-normal") };
  const next = cloneState(state);
  const window = next.windows[command.id];
  window.currentRect = copyRect(window.restoreRect ?? window.initialRect);
  window.restoreRect = null;
  window.displayMode = "normal";
  return { state: next, result: applied(command.type, null) };
}

function rectsEqual(left: WindowRect, right: WindowRect) {
  return (
    left.x === right.x &&
    left.y === right.y &&
    left.width === right.width &&
    left.height === right.height
  );
}

export function getWindowManagerInvariantErrors(
  state: WindowManagerState,
): string[] {
  const errors: string[] = [];
  if (new Set(state.order).size !== state.order.length)
    errors.push("Window order contains duplicate identifiers");
  if (
    state.order.some((id) => !state.windows[id]) ||
    Object.keys(state.windows).some((id) => !state.order.includes(id))
  )
    errors.push("Window registry and order do not match");

  const visible = state.order.filter((id) => isVisible(state.windows[id]));
  const zOrders = visible.map((id) => state.windows[id].zOrder);
  if (zOrders.some((value) => value === null))
    errors.push("A visible window has no z-order");
  if (new Set(zOrders).size !== zOrders.length)
    errors.push("Visible z-order values are not unique");
  if (
    [...(zOrders as number[])]
      .sort((a, b) => a - b)
      .some((value, index) => value !== index + 1)
  )
    errors.push("Visible z-order values are not normalized");
  if (
    state.order.some(
      (id) =>
        !isVisible(state.windows[id]) && state.windows[id].zOrder !== null,
    )
  )
    errors.push("A hidden window participates in z-order");
  if (state.activeWindowId !== null && !visible.includes(state.activeWindowId))
    errors.push("The active window is not visible");
  if (visible.length > 0 && state.activeWindowId === null)
    errors.push("Visible windows exist without an active window");
  if (visible.length === 0 && state.activeWindowId !== null)
    errors.push("An active window exists without a visible window");
  if (
    state.order.some((id) => {
      const window = state.windows[id];
      return (
        !isValidWindowRect(window.initialRect) ||
        !isValidWindowRect(window.currentRect) ||
        (window.restoreRect !== null && !isValidWindowRect(window.restoreRect))
      );
    })
  )
    errors.push("A window contains invalid geometry");
  return errors;
}
