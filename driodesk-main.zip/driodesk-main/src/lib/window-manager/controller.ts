import type { DesktopDomAdapter } from "./dom-adapter";
import { moveWindowRect, resizeWindowRect, type ResizeEdge } from "./geometry";
import {
  createWindowManagerState,
  reduceWindowCommand,
  type WindowCommand,
} from "./state";

export function startDesktopController(adapter: DesktopDomAdapter) {
  let state = createWindowManagerState(
    adapter.definitions,
    adapter.initialWindowId,
  );
  let gesture:
    | {
        pointerId: number;
        id: string;
        kind: "move" | ResizeEdge;
        startX: number;
        startY: number;
        captureTarget: HTMLElement;
        startRect: (typeof state.windows)[string]["currentRect"];
      }
    | undefined;
  const returnTargets = new Map(
    adapter.definitions.map(({ id }) => [id, adapter.getReturnTargetId(id)]),
  );

  const dispatch = (command: WindowCommand, applyFocus = true) => {
    const transition = reduceWindowCommand(state, command);
    if (transition.result.status !== "applied") return transition.result;
    adapter.applyState(transition.state);
    state = transition.state;
    if (applyFocus && transition.result.focus)
      adapter.focus(transition.result.focus, state);
    return transition.result;
  };

  const onClick = (event: MouseEvent) => {
    if (
      event.defaultPrevented ||
      event.button !== 0 ||
      event.metaKey ||
      event.ctrlKey ||
      event.shiftKey ||
      event.altKey
    )
      return;
    const target = event.target;
    if (!(target instanceof Element)) return;

    const control = target.closest<HTMLButtonElement>("[data-window-command]");
    if (control && adapter.root.contains(control)) {
      const windowElement = control.closest<HTMLElement>("[data-app-window]");
      const id = windowElement?.dataset.appWindow;
      if (!id) return;
      const action = control.dataset.windowCommand;
      if (action === "minimize")
        dispatch({
          type: "minimize",
          id,
          returnTargetId: `taskbar-${id}`,
        });
      else if (action === "close")
        dispatch({
          type: "close",
          id,
          returnTargetId: returnTargets.get(id),
        });
      else if (action === "toggle-maximize")
        dispatch({
          type:
            state.windows[id]?.displayMode === "maximized"
              ? "restore-size"
              : "maximize",
          id,
        });
      return;
    }

    const link = target.closest<HTMLAnchorElement>("a[data-app-link]");
    if (!link || !adapter.root.contains(link) || link.target || link.download)
      return;
    const id = adapter.getAppIdForLink(link);
    if (!id) return;
    event.preventDefault();
    if (link.id && !link.dataset.taskbarItem) returnTargets.set(id, link.id);
    const command: WindowCommand =
      link.dataset.taskbarItem && state.windows[id]?.lifecycle === "minimized"
        ? { type: "restore-from-taskbar", id }
        : { type: "open", id, returnTargetId: link.id || undefined };
    const result = dispatch(command);
    if (result.status === "noop" && result.reason === "already-active")
      adapter.focus({ type: "window", targetId: id }, state);
  };

  const onKeyDown = (event: KeyboardEvent) => {
    if (event.defaultPrevented || event.key !== " ") return;
    const target = event.target;
    if (!(target instanceof Element)) return;
    const link = target.closest<HTMLAnchorElement>("a[data-app-link]");
    if (!link || !adapter.root.contains(link) || !adapter.getAppIdForLink(link))
      return;
    event.preventDefault();
    link.click();
  };

  const onPointerDown = (event: PointerEvent) => {
    const target = event.target;
    if (!(target instanceof Element)) return;
    const windowElement = target.closest<HTMLElement>("[data-app-window]");
    const id = windowElement?.dataset.appWindow;
    if (!id || state.windows[id]?.lifecycle !== "open") return;
    dispatch({ type: "focus", id }, false);

    if (gesture || event.button !== 0) return;
    const resizeHandle = target.closest<HTMLElement>("[data-window-resize]");
    const dragHandle = target.closest<HTMLElement>("[data-window-drag-handle]");
    if (
      (!resizeHandle && !dragHandle) ||
      target.closest("[data-window-controls]") ||
      state.windows[id].displayMode !== "normal"
    )
      return;

    const kind = resizeHandle?.dataset.windowResize as ResizeEdge | undefined;
    if (resizeHandle && !isResizeEdge(kind)) return;
    const captureTarget = resizeHandle ?? dragHandle;
    if (!captureTarget) return;
    event.preventDefault();
    try {
      captureTarget.setPointerCapture(event.pointerId);
    } catch {
      return;
    }
    gesture = {
      pointerId: event.pointerId,
      id,
      kind: kind ?? "move",
      startX: event.clientX,
      startY: event.clientY,
      captureTarget,
      startRect: { ...state.windows[id].currentRect },
    };
  };

  const onPointerMove = (event: PointerEvent) => {
    if (!gesture || event.pointerId !== gesture.pointerId) return;
    const workspace = adapter.getWorkspaceSize();
    const delta = {
      x: event.clientX - gesture.startX,
      y: event.clientY - gesture.startY,
    };
    const rect =
      gesture.kind === "move"
        ? moveWindowRect(gesture.startRect, delta, workspace)
        : resizeWindowRect(gesture.startRect, gesture.kind, delta, workspace);
    dispatch({ type: "set-rect", id: gesture.id, rect }, false);
    event.preventDefault();
  };

  const finishGesture = (pointerId: number, release: boolean) => {
    if (!gesture || pointerId !== gesture.pointerId) return;
    const finished = gesture;
    gesture = undefined;
    if (release && finished.captureTarget.hasPointerCapture(pointerId)) {
      try {
        finished.captureTarget.releasePointerCapture(pointerId);
      } catch {
        // Capture may already have been released by the browser.
      }
    }
  };

  const onPointerUp = (event: PointerEvent) =>
    finishGesture(event.pointerId, true);
  const onPointerCancel = (event: PointerEvent) =>
    finishGesture(event.pointerId, true);
  const onLostPointerCapture = (event: PointerEvent) =>
    finishGesture(event.pointerId, false);

  const onFocusIn = (event: FocusEvent) => {
    const target = event.target;
    if (!(target instanceof Element)) return;
    const id =
      target.closest<HTMLElement>("[data-app-window]")?.dataset.appWindow;
    if (id && state.windows[id]?.lifecycle === "open")
      dispatch({ type: "focus", id }, false);
  };

  const recoverWorkspace = () => {
    if (gesture) finishGesture(gesture.pointerId, true);
    const result = dispatch(
      { type: "recover-workspace", workspace: adapter.getWorkspaceSize() },
      false,
    );
    if (result.status !== "applied") adapter.applyState(state);
  };

  recoverWorkspace();
  adapter.root.addEventListener("click", onClick);
  adapter.root.addEventListener("pointerdown", onPointerDown);
  adapter.root.addEventListener("pointermove", onPointerMove);
  adapter.root.addEventListener("pointerup", onPointerUp);
  adapter.root.addEventListener("pointercancel", onPointerCancel);
  adapter.root.addEventListener("lostpointercapture", onLostPointerCapture);
  adapter.root.addEventListener("focusin", onFocusIn);
  adapter.root.addEventListener("keydown", onKeyDown);
  const stopObservingWorkspace = adapter.observeWorkspace(recoverWorkspace);
  return {
    getState: () => state,
    destroy() {
      if (gesture) finishGesture(gesture.pointerId, true);
      stopObservingWorkspace();
      adapter.root.removeEventListener("click", onClick);
      adapter.root.removeEventListener("pointerdown", onPointerDown);
      adapter.root.removeEventListener("pointermove", onPointerMove);
      adapter.root.removeEventListener("pointerup", onPointerUp);
      adapter.root.removeEventListener("pointercancel", onPointerCancel);
      adapter.root.removeEventListener(
        "lostpointercapture",
        onLostPointerCapture,
      );
      adapter.root.removeEventListener("focusin", onFocusIn);
      adapter.root.removeEventListener("keydown", onKeyDown);
    },
  };
}

const resizeEdges = new Set<ResizeEdge>([
  "n",
  "ne",
  "e",
  "se",
  "s",
  "sw",
  "w",
  "nw",
]);

function isResizeEdge(value: string | undefined): value is ResizeEdge {
  return Boolean(value && resizeEdges.has(value as ResizeEdge));
}
