export type WindowRect = {
  x: number;
  y: number;
  width: number;
  height: number;
};

export type WorkspaceSize = {
  width: number;
  height: number;
};

export type ResizeEdge = "n" | "ne" | "e" | "se" | "s" | "sw" | "w" | "nw";

export type GeometryConstraints = {
  minWidth: number;
  minHeight: number;
  titleBarHeight: number;
  reachableControlWidth: number;
};

export const defaultGeometryConstraints: GeometryConstraints = {
  minWidth: 320,
  minHeight: 180,
  titleBarHeight: 44,
  reachableControlWidth: 132,
};

const clamp = (value: number, minimum: number, maximum: number) =>
  Math.min(Math.max(value, minimum), maximum);

const finiteOr = (value: number, fallback: number) =>
  Number.isFinite(value) ? value : fallback;

export const isValidWindowRect = (rect: WindowRect) =>
  [rect.x, rect.y, rect.width, rect.height].every(Number.isFinite) &&
  rect.width > 0 &&
  rect.height > 0;

export function recoverWindowRect(
  rect: WindowRect,
  workspace: WorkspaceSize,
  constraints: GeometryConstraints = defaultGeometryConstraints,
): WindowRect {
  const workspaceWidth = Math.max(0, finiteOr(workspace.width, 0));
  const workspaceHeight = Math.max(0, finiteOr(workspace.height, 0));
  const width = clamp(
    finiteOr(rect.width, constraints.minWidth),
    constraints.minWidth,
    Math.max(constraints.minWidth, workspaceWidth),
  );
  const height = clamp(
    finiteOr(rect.height, constraints.minHeight),
    constraints.minHeight,
    Math.max(constraints.minHeight, workspaceHeight),
  );
  const reachableWidth = Math.min(
    constraints.reachableControlWidth,
    workspaceWidth,
  );
  const minimumX = width > workspaceWidth ? reachableWidth - width : 0;
  const maximumX = Math.max(minimumX, workspaceWidth - width);
  const maximumY = Math.max(
    0,
    Math.min(
      workspaceHeight - constraints.titleBarHeight,
      workspaceHeight - height,
    ),
  );

  return {
    x: clamp(finiteOr(rect.x, 0), minimumX, maximumX),
    y: clamp(finiteOr(rect.y, 0), 0, maximumY),
    width,
    height,
  };
}

export function moveWindowRect(
  start: WindowRect,
  delta: { x: number; y: number },
  workspace: WorkspaceSize,
  constraints: GeometryConstraints = defaultGeometryConstraints,
) {
  const recovered = recoverWindowRect(start, workspace, constraints);
  return recoverWindowRect(
    {
      ...recovered,
      x: recovered.x + finiteOr(delta.x, 0),
      y: recovered.y + finiteOr(delta.y, 0),
    },
    workspace,
    constraints,
  );
}

export function resizeWindowRect(
  start: WindowRect,
  edge: ResizeEdge,
  delta: { x: number; y: number },
  workspace: WorkspaceSize,
  constraints: GeometryConstraints = defaultGeometryConstraints,
) {
  const rect = recoverWindowRect(start, workspace, constraints);
  const right = rect.x + rect.width;
  const bottom = rect.y + rect.height;
  let left = rect.x;
  let top = rect.y;
  let nextRight = right;
  let nextBottom = bottom;

  if (edge.includes("w"))
    left = clamp(
      rect.x + finiteOr(delta.x, 0),
      0,
      right - constraints.minWidth,
    );
  if (edge.includes("e"))
    nextRight = clamp(
      right + finiteOr(delta.x, 0),
      rect.x + constraints.minWidth,
      Math.max(rect.x + constraints.minWidth, workspace.width),
    );
  if (edge.includes("n"))
    top = clamp(
      rect.y + finiteOr(delta.y, 0),
      0,
      bottom - constraints.minHeight,
    );
  if (edge.includes("s"))
    nextBottom = clamp(
      bottom + finiteOr(delta.y, 0),
      rect.y + constraints.minHeight,
      Math.max(rect.y + constraints.minHeight, workspace.height),
    );

  return recoverWindowRect(
    {
      x: left,
      y: top,
      width: nextRight - left,
      height: nextBottom - top,
    },
    workspace,
    constraints,
  );
}

export const getMaximizedRect = (workspace: WorkspaceSize): WindowRect => ({
  x: 0,
  y: 0,
  width: Math.max(0, finiteOr(workspace.width, 0)),
  height: Math.max(0, finiteOr(workspace.height, 0)),
});

export const restoreWindowRect = (
  restoreRect: WindowRect | null,
  fallbackRect: WindowRect,
  workspace: WorkspaceSize,
  constraints: GeometryConstraints = defaultGeometryConstraints,
) => recoverWindowRect(restoreRect ?? fallbackRect, workspace, constraints);
