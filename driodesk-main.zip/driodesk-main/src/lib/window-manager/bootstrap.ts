import { startDesktopController } from "./controller";
import { discoverDesktop } from "./dom-adapter";
import { startStartMenuController } from "../start-menu/controller";
import { discoverStartMenu } from "../start-menu/dom-adapter";

export function initializeDesktop(document: Document) {
  const discovery = discoverDesktop(document);
  const startMenuDiscovery = discoverStartMenu(document);
  if (!discovery.ok || !startMenuDiscovery.ok) return false;
  if (discovery.adapter.root.dataset.desktopInitialized === "true") return true;

  let desktopController: ReturnType<typeof startDesktopController> | undefined;
  let startMenuController:
    ReturnType<typeof startStartMenuController> | undefined;
  try {
    desktopController = startDesktopController(discovery.adapter);
    startMenuController = startStartMenuController(startMenuDiscovery.adapter);
    discovery.adapter.markEnhanced();
    startMenuDiscovery.adapter.markEnhanced();
    discovery.adapter.root.dataset.desktopInitialized = "true";
    return true;
  } catch {
    startMenuController?.destroy();
    desktopController?.destroy();
    delete discovery.adapter.root.dataset.enhanced;
    delete discovery.adapter.root.dataset.desktopInitialized;
    return false;
  }
}

initializeDesktop(document);
